<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
	$bulan=date("Y-m");
	if($_SESSION['USR_NAME']=='') $_SESSION['USR_NAME']=$_SERVER['REMOTE_ADDR'];

	//merah;
	$queryM=mysql_query("select * from log_imel where 1 and ket='M' and tglnotif like '$bulan%'");
	$cekM=mysql_num_rows($queryM);
	if($cekM!=1){
		$exec = mysql_query("insert into log_imel (idlog,tglnotif,notifer,ket) values ('', '".date("Y-m-d")."', '$_SESSION[USR_NAME]', 'M')");
		
		$two1="stk.ru2@pertamina.com";
		$lalye="select *,(datediff(current_date(), tglBerlaku )/365) As umur,(date_add(tglBerlaku, interval 1095 day)) As expired,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen A left join fungsibaru B on bagian_id=idfungsi where kadaluarsa!=1 Order By bagian_id Asc";
		$queryM=mysql_query("select * from ($lalye) Z where 1 and color='M'"); $cekM=mysql_num_rows($queryM);
		$quereM=mysql_query("select email from ($lalye) Z where 1 and color='M' group by email");
		while($roweM=mysql_fetch_assoc($quereM)){$two1.=",".$roweM[email];}

		$to1 = $two1;
		$subject1 = "Laporan Dokumen STK expired";
			$headers1 = "From: Admin STK Online RU II <stk.ru2@pertamina.com>";
			$headers1.= "X-Mailer: PHP/" . phpversion()."\r\n";
			$headers1.= "MIME-Version: 1.0" . "\r\n";
			$headers1.= "Content-type: text/html; charset=iso-8859-1\r\n";

		$message1 = "<html><body><font face='Verdana' size='2'>
					Ada $cekM Dokumen STK yang sudah expired pada bulan ini, termasuk STK dari Fungsi Bapak/Ibu.
					<br>Silahkan check link berikut setelah Bapak/Ibu login ke aplikasi <a href='http://ptmru2prodphp02.pertamina.com/stk/home.php?color=M'>STK Online</a>.
					</br></br>
					Salam,</br>
					STK Online Administrator</br>
					<hr>
					Email ini dikirim otomatis dari sistem sebagai informasi.</br>
					Mohon tidak membalas ke alamat email ini.
					</font></body></html>";

		mail($to1, $subject1, $message1, $headers1);
	}

	//kuning;
	$queryK=mysql_query("select * from log_imel where 1 and ket='K' and tglnotif like '$bulan%'");
	$cekK=mysql_num_rows($queryK);
	if($cekK!=1){
		$exec = mysql_query("insert into log_imel (idlog,tglnotif,notifer,ket) values ('', '".date("Y-m-d")."', '$_SESSION[USR_NAME]', 'K')");
		
		$two2="stk.ru2@pertamina.com";
		$lalyo="select *,(datediff(current_date(), tglBerlaku )/365) As umur,(date_add(tglBerlaku, interval 1095 day)) As expired,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen A left join fungsibaru B on bagian_id=idfungsi where kadaluarsa!=1 Order By bagian_id Asc";
		$queryK=mysql_query("select * from ($lalyo) Z where 1 and color='K'"); $cekK=mysql_num_rows($queryK);
		$quereK=mysql_query("select email from ($lalye) Z where 1 and color='K' group by email");
		while($roweK=mysql_fetch_assoc($quereK)){$two2.=",".$roweK[email];}

		$to2 = $two2;
		$subject2 = "Laporan Dokumen STK hampir-expired";
			$headers2 = "From: Admin STK Online RU II <stk.ru2@pertamina.com>";
			$headers2.= "X-Mailer: PHP/" . phpversion()."\r\n";
			$headers2.= "MIME-Version: 1.0" . "\r\n";
			$headers2.= "Content-type: text/html; charset=iso-8859-1\r\n";

		$message2 = "<html><body><font face='Verdana' size='2'>
					Ada $cekK Dokumen STK yang mendekati-expired pada bulan ini, termasuk STK dari Fungsi Bapak/Ibu.
					<br>Silahkan check link berikut setelah Bapak/Ibu login ke aplikasi <a href='http://ptmru2prodphp02.pertamina.com/stk/home.php?color=K'>STK Online</a>.
					</br></br>
					Salam,</br>
					STK Online Administrator</br>
					<hr>
					Email ini dikirim otomatis dari sistem sebagai informasi.</br>
					Mohon tidak membalas ke alamat email ini.
					</font></body></html>";
		
		mail($to2, $subject2, $message2, $headers2);

	}//else{echo "iko";}
?>

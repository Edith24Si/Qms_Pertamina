<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "notif.php";
include "head.php";
include "menu.php";

$cari='';
	$color = $_GET['color'];$colar=$color[0].$color[1].$color[2];
	$coor = $_GET['corporate']; 
	$jenis = $_GET['jenis'];
	$fungsi_id = $_GET['fungsi_id'];

		if ($colar=='HKM') $cari .= " AND (color='H' OR color='K' OR color='M')";
		if ($colar=='HK')  $cari .= " AND (color='H' OR color='K')";
		if ($colar=='HM')  $cari .= " AND (color='H' OR color='M')";
		if ($colar=='KM')  $cari .= " AND (color='K' OR color='M')";
		if ($colar=='H')   $cari .= " AND color='H'";
		if ($colar=='K')   $cari .= " AND color='K'";
		if ($colar=='M')   $cari .= " AND color='M'";

		if ($coor=='C')   $cari .= " AND fungsi_id != '20'";
		if($jenis != '')   $cari .= " AND jenis = '$jenis'";
		if($fungsi_id!='') $cari .= " AND fungsi_id = '$fungsi_id'";
	$lalye="select *,(datediff(current_date(), tglBerlaku )/365) As umur,(date_add(tglBerlaku, interval 1095 day)) As expired,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen A left join bagian B on bagian_id=idbagian where kadaluarsa=1 Order By bagian_id Asc";
	$query=mysql_query("select * from ($lalye) Z where 1 $cari order by jenis,noDokumen");
?>
	<!--//main awl//-->
<script type="text/javascript" class="init">
$(document).ready(function() {
    $('#example').DataTable(	{
	lengthMenu: [ [15, 30, 50, -1], [15, 30, 50, "All"] ]
	,language: {paginate: {previous: '&#9668;',next: '&#9658;'}, search: '&#128270;'
		,searchPlaceholder: 'Search all..', info: 'Total Dokumen : _TOTAL_'
		,infoEmpty: '', infoFiltered: '', zeroRecords: 'Dokumen tidak ditemukan..'}
	,dom: '<"top"if>rt<"bottom"p><"clear">'
    }	);
} );
/*{paging: false,scrollY: 400}*/
</script>
<h3>Arsip Dokumen</h3>
	<form name="form1" method="get" action="">
	<div style="float:right">
	<span style="background:#cccccc;" title='Dokumen include/tidak dengan Corporate'><input type="checkbox" name="corporate" value="C" <?php if($coor=='C') echo "checked" ?> onchange="this.form.submit()"></span>Non-Corporate
	<span style="background:#45E910;" title='Dokumen baru / kurang dari 2,5 tahun'><input type="checkbox" name="color[]" value="H" <?php if(($colar=='H')||($colar=='HK')||($colar=='HM')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<span style="background:#FFF225;" title='Dokumen antara 2,5 sampai 3 tahun'><input type="checkbox" name="color[]" value="K" <?php if(($colar=='K')||($colar=='KM')||($colar=='HK')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<span style="background:#FE361E;" title='Dokumen sudah lebih dari 3 tahun'><input type="checkbox" name="color[]" value="M" <?php if(($colar=='M')||($colar=='HM')||($colar=='KM')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<select name="jenis" onchange="this.form.submit()">
		<option value="">---semua jenis---</option>
		<option <?php if($_GET[jenis]=='Pedoman') echo "selected" ?>>Pedoman</option>
		<option <?php if($_GET[jenis]=='TKO') echo "selected" ?>>TKO</option>
		<option <?php if($_GET[jenis]=='TKI') echo "selected" ?>>TKI</option>
		<option <?php if($_GET[jenis]=='TKPA') echo "selected" ?>>TKPA</option>
	</select>
	<select name="fungsi_id" onchange="this.form.submit()">
		<option value="">---semua fungsi---</option>
	<?php
	$sql = mysql_query("select * from fungsi");
	while($fungsi = mysql_fetch_assoc($sql)){
	?>
		<option value="<?= $fungsi['idFungsi'] ?>" <? if($_GET[fungsi_id]==$fungsi['idFungsi']) echo "selected" ?>><?= $fungsi['namaFungsi'] ?></option>
	<?php } ?>
	</select>
	</div>
	</form>

<table id="example" class="cell-border compact hover order-column row-border stripe" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Bagian</th>
                <th>Jenis</th>
                <th width="13%">No Dokumen</th>
                <th>&nbsp;</th>
                <th>Judul</th>
                <th>Rev</th>
                <th width="7%">Tmt Berlaku</th>
                <th width="7%">Expired</th>
<? 
	if ($_SESSION['USR_TYP']>3) {
?>
                <th>Actions</th>
<? 
	}
?>
            </tr>
        </thead>
        <tbody>
<?php
$merah	="<img src='inc/images/3.png' title='Dokumen sudah lebih dari 3 tahun'>";
$kuning ="<img src='inc/images/2.png' title='Dokumen antara 2,5 sampai 3 tahun'>";
$hijau	="<img src='inc/images/1.png' title='Dokumen baru / kurang dari 2,5 tahun'>";
$i = 0;
while($row = mysql_fetch_array($query)){
	$i=$i+1;
?>
            <tr>
                <td align="center"><?=$i?></td>
                <td><?=$row['bagian']?></td>
                <td><?=$row['jenis']?></td>
                <td align="center"><? if($row['file']=='') echo "$row[noDokumen]";else echo "<a href='pdf.php?file=$row[file]&user=$_SESSION[USR_NAME]'>$row[noDokumen]</a>";?></td>
                <td align="center">
				<? 
					if($row['color']=='M') echo $merah;
					elseif($row['color']=='K') echo $kuning;
					else echo $hijau;
				?>
				</td>
                <td><?=$row['judul']?></td>
                <td align="center"><?=$row['rev']?></td>
                <td align="center"><?=date('d-m-Y', strtotime($row[tglBerlaku]))?></td>
                <td align="center"><?=date('d-m-Y', strtotime($row[expired]))?></td>
<? 
	if ($_SESSION['USR_TYP']>3) {
?>
                <td align="center">
					<a href='update.php?bes=ed&id=<?=$row['idDokumen']?>'><img src='inc/images/edit.gif' title=Edit></a>
					<a href='update.php?bes=ex&id=<?=$row['idDokumen']?>&file=<?=$row['file']?>' onClick='return confirm (\"Anda yakin akan menghapus dokumen ini?\")'><img src='inc/images/del.gif' title=Hapus></a>&nbsp
				</td>
<? 
	}
?>
            </tr>
<?php } ?>
        </tbody>
    </table>
	<!--//main end//-->
<?php
include "foot.php";
?>
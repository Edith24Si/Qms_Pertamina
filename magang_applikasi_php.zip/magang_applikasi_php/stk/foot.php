<!--//head&foot//-->
		  </td>
		</tr>
	  </table>
	</td>
  </tr>
  <tr>
    <td height="40" class="foot"><div><hr><b>PT. PERTAMINA PATRA NIAGA - REFINERY UNIT DUMAI</b><br/>Copyright &copy; 2018 by IT Dumai</div></td>
  </tr>
</table>
</body>
</html>




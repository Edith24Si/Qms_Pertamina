	<!--//menu awl//-->
  <tr>
    <td>
<div style="background-color:#FFF; padding-top:0px; padding-bottom:0px; width:100%;">
	<ul>
<?php error_reporting (E_ALL ^ E_NOTICE);?>
<?php session_start();
	if ($_SESSION['USR_TYP']>0) {
	$a = mysql_query("SELECT * FROM menu ORDER BY idmenu ASC");
	while($rowa = mysql_fetch_array($a)) {
?>
		<li>
		<a href="<? echo $rowa['link']; ?>"><? echo $rowa['menu']; ?></a>
		</li>
<? 
	} }
	if ($_SESSION['USR_TYP']>1) {
?>
		<li>
		<a href="stkarsip.php" >Dokumen Kadaluarsa</a>
		</li>
		<li>
		<a href="stkpic.php" >PIC /Fungsi</a>
		</li>
		<li>
		<a href="stktoxls.php" >Download to xls</a>
		</li>
		<!-- <li>
		<a href="stkemail.php?color=M" >Reminder</a>
		</li> -->
		<?if ($_SESSION['USR_USM'] = 'mk.delsi.safari') {?>
		<?}?>
<?
	}
	if ($_SESSION['USR_TYP']>0) {
?>
		<li style="float:right">
		<a href="logout.php" >Logout</a>
		</li>
<? 
	}else{
?>
		<li style="float:right">
		<a href="login.php" >Login</a>
		</li>
<? 
	}
?>
		<li style="float:right">
		<a href="" class="top_linkindex"><?=$_SESSION['USR_NAME']?></a>
		</li>
	</ul>
</div>
	</td>
  </tr>
	<!--//menu end//-->
	</td>
  </tr>
  <tr>
    <td>
	  <table align="center" width="1200" border="0" cellpadding="0" cellspacing="0">
		<tr>
		  <td>

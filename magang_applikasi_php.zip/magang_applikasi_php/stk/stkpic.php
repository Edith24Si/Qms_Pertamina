<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "head.php";

include "menu.php";

	$query=mysql_query("SELECT * FROM fungsibaru WHERE 1 order by urut asc");
?>
	<!--//main awl//-->
<script type="text/javascript" class="init">
$(document).ready(function() {
    $('#example').DataTable(	{
	lengthMenu: [ [15, 30, 50, -1], [15, 30, 50, "All"] ]
	,language: {paginate: {previous: '&#9668;',next: '&#9658;'}, search: '&#128270;'
		,searchPlaceholder: 'Search all..', info: 'Total Dokumen : _TOTAL_'
		,infoEmpty: '', infoFiltered: '', zeroRecords: 'Dokumen tidak ditemukan..'}
	,dom: '<"top"if>rt<"bottom"p><"clear">'
    }	);
} );
/*{paging: false,scrollY: 400}*/
</script>
<h3>Person In Charge (PIC) Dokumen per Bagian</h3>
<table id="example" class="cell-border compact hover order-column row-border stripe" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th width="25%">Fungsi</th>
                <th>PIC</th>
<? 
	if ($_SESSION['USR_TYP']>1) {
?>
                <th width="3%">Actions</th>
<? 
	}
?>
            </tr>
        </thead>
        <tbody>
<?php
$i = 0;
while($row = mysql_fetch_array($query)){
$i=$i+1;
?>
            <tr>
                <td align="center"><?=$i?></td>
                <td><? if($row['ket']!='') echo "&nbsp;&nbsp;&nbsp;&#8212;&nbsp;";?><?=$row['fungsi']?></td>
                <td><?=$row['email']?></td>
<? 
	if ($_SESSION['USR_TYP']>1) {
?>
                <td align="center">
					<a href='updatebag.php?bes=ed&id=<?=$row['idfungsi']?>'><img src='inc/images/edit.gif' title='Edit'></a>
				</td>
<? 
	}
?>
            </tr>
<?php } ?>
        </tbody>
    </table>
	<!--//main end//-->
<?php
include "foot.php";
?>
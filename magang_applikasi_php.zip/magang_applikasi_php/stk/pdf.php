<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
//include "db.php";

date_default_timezone_set("Asia/Jakarta");

require_once('inc/pdf/fpdf/fpdf.php');
require_once('inc/pdf/fpdi/fpdi.php');

function DateToIndo($date){  
		$BulanIndo = array("Januari", "Februari", "Maret",  
						   "April", "Mei", "Juni",  
						   "Juli", "Agustus", "September",  
						   "Oktober", "November", "Desember");  
	  
		$tahun = substr($date, 0, 4);  
		$bulan = substr($date, 5, 2);
		$tgl   = substr($date, 8, 2);  
		  
		$result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;       
		return($result);  
}  

$file = $_GET['file'];

$username = $_GET['user'];
$tglawal = DateToIndo(date('Y-m-d'));
$jam = date('H:i');
$tglakhir = strtotime('+7 day', strtotime(date('Y-m-d'))) ;
$tglakhir = DateToIndo(date('Y-m-d', $tglakhir));
	
$text1 = "Dicetak oleh ".$username.", pada tanggal ".$tglawal." jam ".$jam." berlaku sampai tanggal ".$tglakhir;
$text2 = "Q-RU II";

$pdf = new FPDI(); 

//Set the source PDF file
$pagecount = $pdf->setSourceFile('file_upload/'.$file);

for($i = 1; $i <= $pagecount; $i++)
{
    $pdf->addPage();
	$tpl = $pdf->importPage($i);
	$pdf->useTemplate($tpl);

	$pdf->SetFont('Times', 'I', 8);
    $pdf->SetTextColor(0,0,205);
    $pdf->SetY(-25);
	$pdf->MultiCell(0,3,$text1, 0, 'C');
//$pdf->SetAlpha(0.2); 
	$pdf->Image('inc/images/qru2.gif',50,125,120,52);
//$pdf->SetAlpha(1); 
//	$pdf->SetFont('Arial', 'I', 60);
//    $pdf->SetTextColor(192,255,192);
//    $pdf->SetAlpha(0.2);
//    $pdf->SetY(-170);
//	$pdf->MultiCell(0,3,$text2, 0, 'C');
	
}

$pdf->Output('inc/file_upload/'.$file, 'I');

//header('Content-type: application/pdf');
//header('Content-Disposition: attachment; filename="downloaded.pdf"');

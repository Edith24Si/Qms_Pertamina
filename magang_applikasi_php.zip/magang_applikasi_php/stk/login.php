<?php
include "inc/db.php";
include "head.php";

include "menu.php";
?>
	<!--//main awl//-->
	<img src="inc/images/banner.png" />
	<div class="trs" onCLick="history.back()"></div><div class="trs2">
<script>
	function validate() {
		errfound = false;
		if (trim_str(document.form_login.usrname.value)=='')
		error("Username harus diisi", document.form_login.usrname, true, false);
		if (trim_str(document.form_login.passwd.value)=='')
		error("Password harus diisi", document.form_login.passwd, true, false);
		return !errfound;
	}
</script>
	<form name="form_login" method="post" action="vallogin.php" onSubmit="return validate();">
	<!--<input type="button" value="x"  style="float:right;margin-top:-40px;" onCLick="history.back()" />-->

	<table width="290" border="0" align="center" style="margin-top:40px;" bgcolor=#875D67>
	<tr><td>
		<table width="290" border="0" align="center" cellpadding="5" cellspacing="5" bgcolor=#ffffff>
		  <tr><td colspan=2><noscript><font color="#FF0000">(Aktifkan JavaScript Browser Anda)</font></noscript></td></tr>
		  <tr><td>Username</td><td title="isikan dengan user email Bapak/Ibu.."><input type="text" name="usrname" id="usrname" class="textbox" autocomplete=off style="height:22px"/></td></tr>
		  <tr><td>Password</td><td title="isikan dengan password email Bapak/Ibu.."><input type="password" name="passwd" id="passwd" class="textbox" autocomplete=off style="height:22px"/></td></tr>
		  <tr><td></td><td align=right><input type="submit" name="button" id="button" value="     Login     " /></td></tr>
		</table>
	</td></tr>
	</table>

	</form>
	</div>
	<!--//main end//-->
<?php
include "foot.php";
?>
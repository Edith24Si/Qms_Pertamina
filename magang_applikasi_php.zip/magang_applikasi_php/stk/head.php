<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $title;?></title>
<link rel="shortcut icon" href="inc/images/favicon.gif" type="image/gif">
<link rel="stylesheet" type="text/css" href="inc/css/style.css">
<link rel="stylesheet" type="text/css" href="inc/css/datatables.min.css">
<link rel="stylesheet" type="text/css" href="inc/calendar/tcal.css" />
<script type="text/javascript" src="inc/calendar/tcal.js"></script>
<script type="text/javascript" language="javascript" src="inc/js/jquery-3.3.1.js"></script>
<script type="text/javascript" charset="utf8" src="inc/js/datatables.min.js"></script>

</head>
<body>
<table align="center" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="60">
	  <table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
		  <td><a href="index.php" style="text-decoration:none"><span class="blck">STK ONLINE </span><span class="tred">RU DUMAI</span></a></td>
		  <td width=300></td>
		  <td align="right"><img src="inc/images/pertamina.png" width="175" height="50" /></td>
		</tr>
	  </table>
	</td>
  </tr>
  <tr>
    <td>
<!--//head&foot//-->

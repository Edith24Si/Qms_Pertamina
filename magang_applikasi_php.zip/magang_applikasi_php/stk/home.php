<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
//include "notif.php";
include "head.php";
include "menu.php";

$cari='';
	$color = $_GET['color'];$colar=$color[0].$color[1].$color[2];
	$jenis = $_GET['jenis'];
	$fung  = $_GET['fung'];

		if ($colar=='HKM') $cari .= " AND (color='H' OR color='K' OR color='M')";
		if ($colar=='HK')  $cari .= " AND (color='H' OR color='K')";
		if ($colar=='HM')  $cari .= " AND (color='H' OR color='M')";
		if ($colar=='KM')  $cari .= " AND (color='K' OR color='M')";
		if ($colar=='H')   $cari .= " AND color='H'";
		if ($colar=='K')   $cari .= " AND color='K'";
		if ($colar=='M')   $cari .= " AND color='M'";

		if($jenis != '')   $cari .= " AND jenis = '$jenis'";
		if($fung  != '')   $cari .= " AND bagian_id = '$fung'";
	$lalye="select *,(datediff(current_date(), tglBerlaku )/365) As umur,(date_add(tglBerlaku, interval 1095 day)) As expired,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen A left join fungsibaru B on bagian_id=idfungsi where kadaluarsa!=1 ";
	$query=mysql_query("select * from ($lalye) Z where 1 AND bagian_id != '100' $cari order by bagian_id,jenis,noDokumen");
?>
	<!--//main awl//-->
<script type="text/javascript" class="init">
$(document).ready(function() {
    $('#example').DataTable(	{
	lengthMenu: [ [15, 30, 50, -1], [15, 30, 50, "All"] ]
	,language: {paginate: {previous: '&#9668;',next: '&#9658;'}, search: '&#128270;'
		,searchPlaceholder: 'Search all..', info: 'Total Dokumen : _TOTAL_'
		,infoEmpty: '', infoFiltered: '', zeroRecords: 'Dokumen tidak ditemukan..'}
	,dom: '<"top"if>rt<"bottom"p><"clear">'
    }	);
} );
/*{paging: false,scrollY: 400}*/
</script>
<h3>Dokumen STK</h3>
	<form name="form1" method="get" action="">
<? 
	if ($_SESSION['USR_TYP']>1) {
?>
	<a href="update.php"><img src='inc/images/add.png' title='Tambah Dokumen'></a> Add Dokumen
<? 
	}
?>
	<div style="float:right">
	<span style="background:#45E910;" title='Dokumen baru / kurang dari 2,5 tahun'><input type="checkbox" name="color[]" value="H" <?php if(($colar=='H')||($colar=='HK')||($colar=='HM')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<span style="background:#FFF225;" title='Dokumen antara 2,5 sampai 3 tahun'><input type="checkbox" name="color[]" value="K" <?php if(($colar=='K')||($colar=='KM')||($colar=='HK')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<span style="background:#FE361E;" title='Dokumen sudah lebih dari 3 tahun'><input type="checkbox" name="color[]" value="M" <?php if(($colar=='M')||($colar=='HM')||($colar=='KM')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<select name="jenis" onchange="this.form.submit()">
		<option value="">---semua jenis---</option>
		<option <?php if($_GET[jenis]=='Pedoman') echo "selected" ?>>Pedoman</option>
		<option <?php if($_GET[jenis]=='TKO') echo "selected" ?>>TKO</option>
		<option <?php if($_GET[jenis]=='TKI') echo "selected" ?>>TKI</option>
		<option <?php if($_GET[jenis]=='TKPA') echo "selected" ?>>TKPA</option>
		<option <?php if($_GET[jenis]=='Video') echo "selected" ?>>Video</option>
	</select>
	<select name="fung" onchange="this.form.submit()">
		<option value="">---semua fungsi---</option>
	<?php
	$sql = mysql_query("select * from fungsibaru where idfungsi!='100' order by urut asc");
	while($fungsi = mysql_fetch_assoc($sql)){
	?>
		<option value="<?= $fungsi['idfungsi'] ?>" <? if($_GET[fung]==$fungsi['idfungsi']) echo "selected" ?>><?if ($fungsi['ket']!='') echo"&nbsp;&nbsp;&nbsp;";?><?= $fungsi['fungsi'] ?></option>
	<?php } ?>
	</select>
	</div>
	</form>

<table id="example" class="cell-border compact hover order-column row-border stripe" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Fungsi</th>
                <th>Bagian</th>
                <th>Jenis</th>
                <th width="13%">No Dokumen</th>
                <th>&nbsp;</th>
                <th>Judul</th>
                <th>Rev</th>
                <th width="7%">Tmt Berlaku</th>
                <th width="7%">Expired</th>
                <th width="9%">Keterangan</th>
<? 
	if ($_SESSION['USR_TYP']>1) {
?>
                <th width="5%">Actions</th>
<? 
	}
?>
            </tr>
        </thead>
        <tbody>
<?php
$merah	="<img src='inc/images/3.png' title='Dokumen sudah lebih dari 3 tahun'>";
$kuning ="<img src='inc/images/2.png' title='Dokumen antara 2,5 sampai 3 tahun'>";
$hijau	="<img src='inc/images/1.png' title='Dokumen baru / kurang dari 2,5 tahun'>";
$i = 0;
while($row = mysql_fetch_array($query)){
	$i=$i+1;
?>
            <tr>
                <td align="center"><?=$i?></td>
                <td><? if (in_array($row['idfungsi'], [1,2,3,10,17,21,26,32,33,37,41,44,49,54,57,60,63,64,65,67,98,99])) echo $row['fungsi']; else echo ""; ?></td>
                <td><? if (in_array($row['idfungsi'], [1,2,3,10,17,21,26,32,33,37,41,44,49,54,57,60,63,64,65,67,98,99])) echo "-"; else echo $row['fungsi']; ?></td>
                <td><?=$row['jenis']?></td>
                <td align="center"><nobr><? if($row['file']=='') echo "$row[noDokumen]";else echo "<a href='pdf.php?file=$row[file]&user=$_SESSION[USR_NAME]'>$row[noDokumen]</a>";?></nobr></td>
                <td align="center">
				<? 
					if($row['color']=='M') echo $merah;
					elseif($row['color']=='K') echo $kuning;
					else echo $hijau;
				?>
				</td>
                <td><?=$row['judul']?></td>
                <td align="center"><?=$row['rev']?></td>
                <td align="center"><?=date('d-m-Y', strtotime($row[tglBerlaku]))?></td>
                <td align="center"><?=date('d-m-Y', strtotime($row[expired]))?></td>
                <td><?=$row['keterangan']?></td>
<? 
	if ($_SESSION['USR_TYP']>1) {
?>
                <td align="center">
					<a href='update.php?bes=ex&id=<?=$row['idDokumen']?>' onClick='return confirm (\"Dokumen ini akan dikadaluarsakan, oke?\")'><img src='inc/images/false.gif' title='Kadaluarsakan'></a>
					<a href='update.php?bes=ed&id=<?=$row['idDokumen']?>'><img src='inc/images/edit.gif' title='Edit'></a>
					<a href='update.php?bes=de&id=<?=$row['idDokumen']?>&file=<?=$row['file']?>' onClick='return confirm (\"Dokumen ini akan dihapus.., yakin?\")'><img src='inc/images/trash.gif' title='Hapus'></a>
				</td>
<? 
	}
?>
            </tr>
<?php } ?>
        </tbody>
    </table>
	<!--//main end//-->
<?php
include "foot.php";
?>
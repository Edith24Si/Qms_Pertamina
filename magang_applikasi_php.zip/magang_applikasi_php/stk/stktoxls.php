<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";

if(!$_SESSION['USR_TYP']>1){
	header("location:logout.php");
}

header("Content-Disposition: attachment; filename=\"Dokumen_STK_".date("Ymd").".xls\""); 
header("Content-Type: application/vnd.ms-excel"); 
?>
<b>DOKUMEN STK ONLINE PT. PERTAMINA PATRA NIAGA RU DUMAI<br/>
TAHUN <?= date("Y") ?></b><br/>
<table width="100%" border="1">
	<thead>
	<tr>
		<th>NO</th>
		<th>FUNGSI</th>
		<th>JENIS STK</th>
		<th>NO DOKUMEN</th>
		<th>JUDUL</th>
		<th>REV KE</th>
		<th>TMT BERLAKU</th>
		<th>EXPIRED</th>
		<th>STATUS</th>
		<th>KETERANGAN</th>
	</tr>
	</thead>
	<tbody>
	<?php
	$no=1;
	$lalye="select *,(datediff(current_date(), tglBerlaku )/365) As umur,(date_add(tglBerlaku, interval 1095 day)) As expired,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen A left join fungsibaru B on bagian_id=idfungsi where kadaluarsa!=1 and idfungsi!=100";
	$lalyo="select * from ($lalye) Z where 1 order by urut,jenis,noDokumen";

	//$sql_stk = "select * from (select *,CASE WHEN umur >3 THEN 'M' WHEN umur >2.5 and umur <=3 THEN 'K' WHEN umur <=2.5 THEN 'H' END As color from (select *,(DATEDIFF(CURRENT_DATE(), tglBerlaku )/365) As umur,(DATE_ADD(tglBerlaku, INTERVAL 1095 DAY)) As expired FROM dokumen, bagian WHERE dokumen.bagian_id=bagian.idBagian AND kadaluarsa='0')A)B where 1 Order by bagian_id asc";
	//echo $lalye."<hr>".$lalyo;break;

	$jmldata = mysql_num_rows(mysql_query($lalye));
	$query = mysql_query($lalyo);
	
	while($stk = mysql_fetch_assoc($query)){ ?>
		<tr>
			<td><?= $no++ ?></td>
			<td><?= $stk['fungsi'] ?></td>
			<td><?= $stk['jenis'] ?></td>
			<td><?= $stk['noDokumen'] ?></td>
			<td><?= $stk['judul'] ?></td>
			<td><?= $stk['rev'] ?></td>
			<td><?= $stk['tglBerlaku'] ?></td>
			<td><?= $stk['expired'] ?></td>
			<?
			if($stk['color']=='M') echo "<td bgcolor='#FF0000'>$stk[color]</td>";
			if($stk['color']=='K') echo "<td bgcolor='#FFFF00'>$stk[color]</td>";
			if($stk['color']=='H') echo "<td bgcolor='#00FF00'>$stk[color]</td>";
			?>
			<td><?= $stk['keterangan'] ?></td>
		</tr>
	<? } ?>
	</tbody>
</table>
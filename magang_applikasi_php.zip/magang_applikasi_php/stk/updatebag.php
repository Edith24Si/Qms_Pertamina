<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "head.php";

include "menu.php";
if(!$_GET['id']) $judul="Tambah Data / PIC Fungsi"; else $judul="Edit Data / PIC Fungsi";

if(($_POST['Submit'] == 'Simpan')&&($_GET['id'])) {
    $exec = mysql_query("UPDATE `fungsibaru` SET `email` = '$_POST[email]' WHERE idfungsi = '$_GET[id]'");
	if($exec) $pesan = "Email telah di Edit"; else $pesan = "Email gagal di Edit";
	print "<script>alert('$pesan');location.href='stkpic.php';</script>";		
}

$sql = mysql_query("select * from fungsibaru where idfungsi='$_GET[id]'");
$data = mysql_fetch_assoc($sql);

?>

<br>
<h2><?=$judul?></h2>
<fieldset>
<form name="form1" action="" enctype="multipart/form-data" method="post" id="myForm" onsubmit="return validate()">
<table width="100%">
<tr>
	<td width="100px">Fungsi</td>
	<td><b><?=$data['fungsi']?></b></td>
</tr>
<tr>
	<td>PIC</td>
	<td><input type="text" name="email" class="required" title="" value="<?=$data[email]?>" size="42"/></td>
</tr>
<tr>
	<td></td>
	<td><br/><input type="submit" name="Submit" value="Simpan"> 
	<input type="button" value="Batal" onClick="history.go(-1);return true;"></td>
</tr>

</table>
</form>
</fieldset>

<?php
include "foot.php";
?>
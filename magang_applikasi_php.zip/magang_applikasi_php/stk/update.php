<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "head.php";

include "menu.php";
if(!$_GET['id']) $judul="Tambah Dokumen STK"; else $judul="Edit Dokumen STK";

if(($_GET['bes']=='ex')&&($_GET['id'])) {
		$query = mysql_query("update dokumen set kadaluarsa='1' where idDokumen='$_GET[id]'");
		$pesan = "Dokumen telah dipindahkan ke Dokumen Kadaluarsa";

		print "<script>alert('$pesan');location.href='home.php';</script>";		
}
if(($_GET['bes']=='ak')&&($_GET['id'])) {
		$query = mysql_query("update dokumen set kadaluarsa='0' where idDokumen='$_GET[id]'");
		$pesan = "Dokumen telah diaktifkan kembali";

		print "<script>alert('$pesan');location.href='stkarsip.php';</script>";		
}
if(($_GET['bes']=='de')&&($_GET['id'])) {
		$query = mysql_query("delete from dokumen where idDokumen='$_GET[id]'");
		unlink("file_upload/".$file);
		$pesan = "Dokumen telah dihapus";

		print "<script>alert('$pesan');location.href='home.php';</script>";		
}
if(($_POST['Submit'] == 'Simpan')&&(!$_GET['id'])) {
    $bagian_id = $_POST['bagian_id'];
    $jenis = $_POST['jenis'];
    $noDokumen = $_POST['noDokumen'];
    $judul = $_POST['judul'];
    $rev = $_POST['rev'];
    $tglBerlaku = $_POST['tglBerlaku'];
    $keterangan = $_POST['keterangan'];
    $modified = date("Y-m-d H:i:s");
    $user_id = $_SESSION['USERID_SES'];
    
    $qry=mysql_query("select noDokumen from dokumen where noDokumen='$_POST[noDokumen]'");
	$cek=mysql_num_rows($qry);
	if($cek==1){
        print "<script>alert('No Dokumen sudah ada');window.history.back(1);</script>";
	}else{
    $exec = mysql_query("INSERT INTO `dokumen`(`bagian_id`, `jenis`, `noDokumen`, `judul`, `rev`, `tglBerlaku`, `keterangan`, `modified`, `user_id`) VALUES
					   ('$bagian_id', '$jenis', '$noDokumen', '$judul', '$rev', '$tglBerlaku', '$keterangan', '$modified', '$user_id')");

    $query1 = mysql_query("SELECT max( idDokumen ) AS id FROM dokumen");
	$id_m = mysql_result($query1, 0);
    $id_hasil = $id_m;
    
    $query2 = mysql_query("SELECT noDokumen FROM dokumen where idDokumen ='$id_hasil'");
	$dok = mysql_result($query2, 0);
    $nama_dok = $dok;
    
    $dok_hasil = str_replace("/", "_", $nama_dok);
    $file = $_FILES['file']['name'];
    $type_file = end(explode('.', strtolower($file)));         
	
	if ($_FILES['file']['name'] != "") 
	{
        $sUploadDir = "file_upload/";
		$sUploadedFile = $sUploadDir . basename($_FILES['file']['name']);

		if (move_uploaded_file($_FILES['file']['tmp_name'], $sUploadedFile))
		{
		//	$sThumbnail = $_FILES['file']['name'];
			$sThumbnail = $dok_hasil.".".$type_file;
			$sFileName = ($sThumbnail);
			if (file_exists(($sUploadDir.$_FILES['file']['name'])))
				rename(($sUploadDir.$_FILES['file']['name']), ($sUploadDir.$sFileName));
		}
		mysql_query("UPDATE dokumen SET file='$dok_hasil.$type_file' where idDokumen='$id_hasil'");
	}
    
	if($exec) $pesan = "Data Telah Disimpan";
	else $pesan = "Data Gagal Disimpan";
	
	print "<script>alert('$pesan');location.href='home.php';</script>";		
    }
}
if(($_POST['Submit'] == 'Simpan')&&($_GET['id'])) {
    $idDokumen = $_GET['id'];
	$query = mysql_query("SELECT * FROM dokumen where idDokumen='$idDokumen'");
	$data = mysql_fetch_assoc($query);

    $bagian_id = $_POST['bagian_id'];
    $jenis = $_POST['jenis'];
    $noDokumen = $_POST['noDokumen'];
    $judul = $_POST['judul'];
    $rev = $_POST['rev'];
    $tglBerlaku = $_POST['tglBerlaku'];
    $keterangan = $_POST['keterangan'];
    $modified = date("Y-m-d H:i:s");
    $user_id = $_SESSION['USERID_SES'];
    
    $exec = mysql_query("UPDATE `dokumen` SET `bagian_id` = '$bagian_id', `jenis` = '$jenis', `noDokumen` = '$noDokumen', 
						`judul` = '$judul', `rev` = '$rev', `tglBerlaku` = '$tglBerlaku', `keterangan` = '$keterangan', 
						`modified` = '$modified', `user_id` = '$user_id', `kadaluarsa` = '0' WHERE idDokumen = '$idDokumen'");

    $dok_hasil = str_replace("/", "_", $noDokumen);
    $file = $_FILES['file']['name'];
    $type_file = end(explode('.', strtolower($file)));         
	
	if ($_FILES['file']['name'] != "") 
	{
        if ($data[file] !=='' ) unlink( "file_upload/".$data[file]);

		$sUploadDir = "file_upload/";
		$sUploadedFile = $sUploadDir . basename($_FILES['file']['name']);

		if (move_uploaded_file($_FILES['file']['tmp_name'], $sUploadedFile))
		{
		//	$sThumbnail = $_FILES['file']['name'];
			$sThumbnail = $dok_hasil.".".$type_file;
			$sFileName = ($sThumbnail);
			if (file_exists(($sUploadDir.$_FILES['file']['name'])))
				rename(($sUploadDir.$_FILES['file']['name']), ($sUploadDir.$sFileName));			
		}
		mysql_query("UPDATE dokumen SET file='$dok_hasil.$type_file' where idDokumen='$idDokumen'");
	}
    
	if($exec) $pesan = "Data Telah di Edit";
	else $pesan = "Data Gagal di Edit";
	
	print "<script>alert('$pesan');location.href='home.php';</script>";		
}


$sql = mysql_query("select * from dokumen, fungsibaru where bagian_id=idfungsi and idDokumen='$_GET[id]'");
$data = mysql_fetch_assoc($sql);

?>

<br>
<h2><?=$judul?></h2>
<fieldset>
<form name="form1" action="" enctype="multipart/form-data" method="post" id="myForm" onsubmit="return validate()">
<table width="100%">
<tr>
	<td width="100px">Fungsi</td>
	<td>
		<select name="bagian_id" id="bagian_id" onchange="email()">
			<option></option>
			<?php
			$sql = mysql_query("select * from fungsibaru order by urut asc");
			while($fungsi = mysql_fetch_assoc($sql)){
			?>
				<option value="<?= $fungsi['idfungsi'] ?>" <? if($data['bagian_id']==$fungsi['idfungsi']) echo "selected" ?>><?if ($fungsi['ket']!='') echo"&nbsp;&nbsp;&nbsp;";?><? echo $fungsi['fungsi'];$iko.="','".$fungsi['email']; ?></option>
			<?php } ?>
		</select>
		PIC : <span id="mel" title="Email PIC Bagian"><input value="<? if($data['bagian_id']!='') echo $data[email]; else echo "email@pertamina.com";?>" readonly size=40></span> 		
<script>
	function email(){
		var maru=Array('<?=$iko?>');
		
		var bag=document.getElementById("bagian_id")
		var ind=bag.selectedIndex;
		document.getElementById("mel").innerHTML="<input value='"+maru[ind]+"' readonly size=40>";
		//document.write("Javascript itu keren!");
  	}
</script>
	</td>
</tr>
<tr>
	<td>Jenis</td>
	<td>
	<select name="jenis">
		<option <? if($data[jenis]=='Pedoman') echo "selected" ?>>Pedoman</option>
		<option <? if($data[jenis]=='TKO') echo "selected" ?>>TKO</option>
		<option <? if($data[jenis]=='TKI') echo "selected" ?>>TKI</option>
		<option <? if($data[jenis]=='TKPA') echo "selected" ?>>TKPA</option>
		<option <? if($data[jenis]=='Video') echo "selected" ?>>Video</option>
	</select>
	</td>
</tr>
<tr>
	<td>No Dokumen</td>
	<td><input type="text" name="noDokumen" class="required" title=" ( No Dokumen belum diisi )" value="<?=$data[noDokumen]?>" size="30"/></td>
</tr>
<tr>
	<td>Judul</td>
	<td><input type="text" name="judul" class="required" title=" ( Judul belum diisi )" value="<?=$data[judul]?>" size="50"/></td>
</tr>
<tr>
	<td>Rev. ke</td>
	<td><input type="text" name="rev" class="required" title=" ( Revisi belum diisi )" value="<?=$data[rev]?>" size="3"/></td>
</tr>
<tr>
	<td>TMT Berlaku</td>
	<td><input name="tglBerlaku" type="text" class="tcal" value="<?=$data[tglBerlaku];?>" readonly><br>
	<script>DateInput('tglBerlaku', true, 'YYYY-MM-DD','<?php echo $data[tglBerlaku]; ?>')</script></td>
</tr>
<tr>
	<td>Keterangan</td>
	<td><input type="text" name="keterangan" value="<?=$data[keterangan]?>" size="50"/></td>
</tr>
<tr>
	<td>Upload File</td>
	<td><input type="file" name="file" /> * Khusus Dokumen PDF</td>
</tr>
<?
if($_GET['id']){
?>
<tr>
	<td>&nbsp;</td>
    <td>File Saat Ini : 
	<a target="_blank" href="file_upload/<?=$data[file]?>"><? if ( file_exists( "file_upload/$data[file]" ) ) echo $data[file] ?></a>
    <? if ($data[file] == '') { echo "-"; }
	else { ?> &raquo; <a href="a_del.php?id=<?=$data[idDokumen]?>&file=<?=$data[file]?>" onClick= "return confirm ('Apakah Anda Yakin Akan Menghapus Dokumen Ini?')">Hapus</a> <? } ?>
	<? if ($data[kadaluarsa] != '0') {echo "<br>** Dokumen Kadaluarsa yang di Edit akan menjadi Aktif.";} ?>
	</td>
</tr>
<?
}
?>
<tr>
	<td></td>
	<td><br/><input type="submit" name="Submit" value="Simpan"> 
	<input type="button" value="Batal" onClick="history.go(-1);return true;"></td>
</tr>
</tr>
</table>
</form>
</fieldset>

<?php
include "foot.php";
?>
<?php
include "inc/db.php";
include "head.php";
//echo "";
include "menu.php";
?>
	<!--//main awl//-->
	<img src="inc/images/banner.png" />
	<!--//main end//-->
<?php
include "foot.php";
?>
	<select name='bag' id='bag' onchange="email()">
		<option id='0' value='0'>*** none ***</option>
		<option id='1' value='1'>Machine 1</option>
		<option id='2' value='2'>Machine 2</option>
		<option id='3' value='3'>Machine 3</option>
		<option id='4' value='4'>Machine 4</option>
		<option id='5' value='5'>Machine 5</option>
	</select>
	<input type="text" name="mel" id="mel" readonly> 
	
  	</form>
<script>
	function email(){
		var big=document.getElementById("bag")
		document.getElementById("mel").value=big.options[big.selectedIndex].text;
  	}
</script>

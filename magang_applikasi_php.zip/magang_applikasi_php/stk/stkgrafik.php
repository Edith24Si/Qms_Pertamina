<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "head.php";

include "menu.php";

$cari='';$caro='';$coor ='';
	//$coorp = $_GET['corporate']; 
	$jenis = $_GET['jenis'];
	$fungsi_id = $_GET['fungsi_id'];

		if($jenis != '')   $cari = " AND jenis = '$jenis'";
		if($fungsi_id!='') $caro = " AND Aa.idfungsi = '$fungsi_id'";
		//if($coorp=='C')	   $cr = " AND C.idfungsi != '100'";

	$query1="select Aa.idfungsi,fungsi,hijau,kuning,merah,jum from
						fungsibaru Aa left join (select idfungsi,ifnull(sum(jum),0) As Hijau from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100' group by idfungsi) Bb on Aa.idfungsi=Bb.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Kuning  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='K')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100' group by idfungsi) Cc on Aa.idfungsi=Cc.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Merah   from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='M')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100' group by idfungsi) Ee on Aa.idfungsi=Ee.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Jum     from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H' or color='K' or color='M')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100' group by idfungsi) Ff on Aa.idfungsi=Ff.idfungsi where 1 
						$caro";
	$hasil1=mysql_query($query1);$row =mysql_fetch_array($hasil1);
	$queryT=mysql_query("select Aa.idfungsi,fungsi,hijau,kuning,merah,jum from
						fungsibaru Aa left join (select idfungsi,ifnull(sum(jum),0) As Hijau from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100') Bb on Aa.idfungsi=Bb.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Kuning  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='K')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100') Cc on Aa.idfungsi=Cc.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Merah   from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='M')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100') Ee on Aa.idfungsi=Ee.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Jum     from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H' or color='K' or color='M')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 AND C.idfungsi != '100') Ff on Aa.idfungsi=Ff.idfungsi where 1 
						");
						$rowt = mysql_fetch_array($queryT);
	
	//echo $query1;
	//$jumData=$data1['jumData'];

?>
<script src="inc/js/amcharts.js" type="text/javascript"></script>
<script src="inc/js/pie.js" type="text/javascript"></script>
	<form name="form1" method="get" action="">
	<div>
	<!-- <span style="background:#cccccc;" title='Dokumen include/tidak dengan Corporate'><input type="checkbox" name="corporate" value="C" <?php if($coorp=='C') echo "checked" ?> onchange="this.form.submit()"></span>Non-Corporate -->
	<select name="jenis" onchange="this.form.submit()">
		<option value="">---semua jenis---</option>
		<option <?php if($_GET[jenis]=='Pedoman') echo "selected" ?>>Pedoman</option>
		<option <?php if($_GET[jenis]=='TKO') echo "selected" ?>>TKO</option>
		<option <?php if($_GET[jenis]=='TKI') echo "selected" ?>>TKI</option>
		<option <?php if($_GET[jenis]=='TKPA') echo "selected" ?>>TKPA</option>
		<option <?php if($_GET[jenis]=='Video') echo "selected" ?>>Video</option>
	</select>
	<select name="fungsi_id" onchange="this.form.submit()">
		<option value="">---semua fungsi---</option>
	<?php
	$sql = mysql_query("select * from fungsibaru where idfungsi!='100' order by urut asc");
	while($fungsi = mysql_fetch_assoc($sql)){
	?>
		<option value="<?= $fungsi['idfungsi'] ?>" <? if($_GET[fungsi_id]==$fungsi['idfungsi']) echo "selected" ?>><?if ($fungsi['ket']!='') echo"&nbsp;&nbsp;&nbsp;";?><?= $fungsi['fungsi'] ?></option>
	<?php } ?>
	</select>
	</div>
	</form>

        <script>
            var chart;
            var legend;

<? if($fungsi_id!='') { ?>
            var chartData = [
				{"country": "Dokumen < 2\275 tahun","value": <?= $row[hijau]?>},
                {"country": "Dokumen 2\275 - 3 tahun","value": <?= $row[kuning]?>},
                {"country": "Dokumen > 3 tahun","value": <?= $row[merah]?>}
            ];
<? } else { ?>
            var chartData = [
				{"country": "Dokumen < 2\275 tahun","value": <?= $rowt[hijau]?>},
                {"country": "Dokumen 2\275 - 3 tahun","value": <?= $rowt[kuning]?>},
                {"country": "Dokumen > 3 tahun","value": <?= $rowt[merah]?>}
            ];
<? } ?>

            AmCharts.ready(function () {
                // PIE CHART
                chart = new AmCharts.AmPieChart();
                chart.dataProvider = chartData;
                chart.titleField = "country";
                chart.valueField = "value";
                chart.outlineColor = "#FFFFFF";
                chart.outlineAlpha = 0.7;
                chart.outlineThickness = 2;
                chart.balloonText = "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>";
                // this makes the chart 3D
                chart.depth3D = 25;
                chart.angle = 33;

                // WRITE
                chart.write("chartdiv");
            });
        </script>
		
<? if($fungsi_id!='') { ?>
	<div style="text-align: center;"><h3>Grafik Dokumen STK Fungsi <?= $row[fungsi]?><br>
	<?if($_GET[jenis]!='') echo " Jenis $_GET[jenis] ";?>(<?= $row[jum]?> Dokumen)</h3></div>
<? } else { ?>
	<div style="text-align: center;"><h3>Grafik Dokumen STK<?if($_GET[jenis]!='') echo " Jenis $_GET[jenis]";if($coorp=='C') echo " Non-Corporate";?><br>
	(Total <?= $rowt[jum]?> Dokumen)</h3></div>
<? } ?>

<div style="position: absolute;width: 400px;right: 0;">
	<img src='inc/images/1.png' title='Dokumen baru / kurang dari 2,5 tahun'> <span style="color:#45E910;">Dokumen baru / kurang dari 2&#189; tahun</span><br>
	<img src='inc/images/2.png' title='Dokumen antara 2,5 sampai 3 tahun'> <span style="color:#FFF225;">Dokumen antara 2&#189; sampai 3 tahun</span><br>
	<img src='inc/images/3.png' title='Dokumen sudah lebih dari 3 tahun'> <span style="color:#FE361E;">Dokumen sudah lebih dari 3 tahun</span>
</div>


<? if($fungsi_id!='') { ?>
<? if(($row[jum]!='0')) {?>
<div id="chartdiv" style="width: 100%; height: 400px;"></div>
<? }else{ ?>
<div class="blank" style="width: 100%; height: 400px;"></div>
<? } } else {?>
<div id="chartdiv" style="width: 100%; height: 400px;"></div>
<? } ?>

<?php
include "foot.php";
?>
<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "head.php";

include "menu.php";

$colar = $_GET['color'];//isset($_GET['color'])?$colar:'M';
$fung  = $_GET['fung'];
	if($fung!='')	$cari=" AND bagian_id = '$fung'";$clink="&fung=$fung";
$tgl=date("l, d-m-Y H:i:s");

if($_POST['submit']=='Send Email') {
	$headers = "From: Admin STK Online RU II <stk.ru2@pertamina.com>";
	$headers.= "X-Mailer: PHP/" . phpversion()."\r\n";
	$headers.= "MIME-Version: 1.0" . "\r\n";
	$headers.= "Content-type: text/html; charset=iso-8859-1\r\n";
	$tw= $_POST[to].",teguh.hse@pertamina.com, ilham.hr@pertamina.com, o2ep.ru2@pertamina.com, arief.irsyad@pertamina.com";

	$exec = mysql_query("insert into log_imelfungsi (idlog,idfungsi,tglnotif,notifer,ket) values ('', '$_POST[idfung]', '".date("Y-m-d")."', '$_SESSION[USR_NAME]', '$_POST[warna]');");
	mail($tw, $_POST[subjek], $_POST[pesan], $headers);
	
	if ($exec) {
		die("<script>alert('Pesan terkirim..');location.href='stkemail.php?color=$_POST[warna]&fung=$_POST[idfung]';</script>");
	}

}

//----
		$two1="stk.ru2@pertamina.com";
		$lalye="select *,(datediff(current_date(), tglBerlaku )/365) As umur,(date_add(tglBerlaku, interval 1095 day)) As expired,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen A left join fungsibaru B on bagian_id=idfungsi where kadaluarsa!=1 AND bagian_id != '100' Order By bagian_id Asc";

		if ($colar=='M') {
			//merah;
			$queryM=mysql_query("select * from ($lalye) Z where 1 and color='M' $cari"); $cekM=mysql_num_rows($queryM);
			$quereM=mysql_query("select email,fungsi from ($lalye) Z where 1 and color='M' $cari group by email");
			while($roweM=mysql_fetch_assoc($quereM)){$two1.=", ".$roweM[email];$bagian.="<li>".$roweM[fungsi]."</li><br>";}
			$subject = "Laporan Dokumen STK expired";
			$message = "<html><body><font face='Verdana' size='2'>
						Ada $cekM Dokumen STK yang sudah expired pada bulan ini, termasuk STK dari Fungsi Bapak/Ibu.
						<br>Silahkan check link berikut setelah Bapak/Ibu login ke aplikasi <a href='http://ptmru2prodphp02.pertamina.com/stk/home.php?color=M$clink'>STK Online</a>.
						<br>Fungsi yang dimaksud antara lain :<br>$bagian
						</br>
						Salam,</br>
						STK Online Administrator</br>
						<hr>
						Email ini dikirim otomatis dari sistem sebagai informasi.</br>
						Mohon tidak membalas ke alamat email ini.
						</font></body></html>";
		}else{
			//kuning;
			$queryK=mysql_query("select * from ($lalye) Z where 1 and color='K' $cari"); $cekK=mysql_num_rows($queryK);
			$quereK=mysql_query("select email,fungsi from ($lalye) Z where 1 and color='K' $cari group by email");
			while($roweK=mysql_fetch_assoc($quereK)){$two1.=", ".$roweK[email];$bagian.="<li>".$roweK[fungsi]."</li><br>";}
			$subject = "Laporan Dokumen STK hampir-expired";
			$message = "<html><body><font face='Verdana' size='2'>
						Ada $cekK Dokumen STK yang mendekati-expired pada bulan ini, termasuk STK dari Fungsi Bapak/Ibu.
						<br>Silahkan check link berikut setelah Bapak/Ibu login ke aplikasi <a href='http://ptmru2prodphp02.pertamina.com/stk/home.php?color=K$clink'>STK Online</a>.
						<br>Fungsi yang dimaksud antara lain :<br>$bagian
						</br>
						Salam,</br>
						STK Online Administrator</br>
						<hr>
						Email ini dikirim otomatis dari sistem sebagai informasi.</br>
						Mohon tidak membalas ke alamat email ini.
						</font></body></html>";
		}
//====
?>
	<!--//main awl//-->
<h3>Reminder Manual</h3>
	<form name="form1" method="get" action="">
	<div>
	<span style="background:#FFF225;" title='Dokumen antara 2,5 sampai 3 tahun'><input type="radio" name="color" value="K" <?php if($colar=='K') echo "checked" ?> onchange="this.form.submit()"></span>
	<span style="background:#FE361E;" title='Dokumen sudah lebih dari 3 tahun'><input type="radio" name="color" value="M" <?php if($colar=='M') echo "checked" ?> onchange="this.form.submit()"></span>
	<select name="fung" onchange="this.form.submit()">
		<option value="">---semua fungsi---</option>
	<?php
	$sql = mysql_query("select * from fungsibaru where idfungsi!='100' order by urut asc");
	while($fungsi = mysql_fetch_assoc($sql)){
	?>
		<option value="<?= $fungsi['idfungsi'] ?>" <? if($_GET[fung]==$fungsi['idfungsi']) echo "selected" ?>><?if ($fungsi['ket']!='') echo"&nbsp;&nbsp;&nbsp;";?><?= $fungsi['fungsi'] ?></option>
	<?php } ?>
	</select>
	</div>
	</form>
	<br>
	<table border=1 <? if($colar=='M') echo "bgcolor=#FFC0C0"; else echo "bgcolor=#FFFFC0";?>>
	  <tr valign=top><td colspan=3>log email sebelumnya..</td></tr>
	  <tr valign=top bgcolor="#ddd"><td>No.</td><td>Tanggal</td><td>Sender</td></tr>
	<?php
	if($fung!='') {
		$sql = mysql_query("select * from log_imelfungsi where idfungsi='$fung' and ket='$colar' order by idlog desc limit 0,3");$i=1;
		while($logm = mysql_fetch_assoc($sql)){
	?>
		<tr valign=top><td><?=$i?></td><td><?=date("d-m-Y", strtotime($logm[tglnotif]))?></td><td><?=$logm[notifer]?></td></tr>
	<?php 
		$i++; } 
	}else{
		$sql = mysql_query("select * from log_imel order by idlog desc limit 0,3");$i=1;
		while($logm = mysql_fetch_assoc($sql)){
	?>
		<tr valign=top><td><?=$i?></td><td><?=date("d-m-Y", strtotime($logm[tglnotif]))?></td><td><?=$logm[notifer]?></td></tr>
	<?php $i++; } } ?>
	</table>
	
	<br><br>
	<table width=700 bgcolor="#ddd">
	<? if (($cekM=='0')||($cekK=='0')){ echo"<tr><td colspan=3><h3>kosong..</h3></td></tr>";}else{ ?>
	  <tr valign=top><td><b>Send</b></td><td>:</td><td><?=$tgl?></td></tr>
	  <tr valign=top><td><b>From</b></td><td>:</td><td>Admin STK Online RU II &lt;stk.ru2@pertamina.com&gt;<br>X-Mailer: PHP/<?=phpversion()?><br>MIME-Version: 1.0<br>Content-type: text/html; charset=iso-8859-1</td></tr>
	  <tr valign=top><td><b>To</b></td><td>:</td><td><?=$two1; ?></td></tr>
	  <tr valign=top><td><b>Subject</b></td><td>:</td><td><b><?=$subject;?></b></td></tr>
	  <tr valign=top><td></td><td></td><td></td></tr>
	  <tr valign=top><td></td><td></td><td><?=$message;?></td></tr>
	<? } ?>
	</table>
	<br><br>
	
	<form name="form2" method="post" action="">
		<input type="hidden" name="idfung" value="<?=$fung; ?>">
		<input type="hidden" name="warna" value="<?=$colar; ?>">
		<input type="hidden" name="to" value="<?=$two1; ?>">
		<input type="hidden" name="subjek" value="<?=$subject; ?>">
		<input type="hidden" name="pesan" value="<?=$message; ?>">
		<input type="submit" name="submit" value="Send Email">
	</form>
	<br><br>
	

	<!--//main end//-->
<?php
include "foot.php";
?>
<?php
$o_con=mysql_connect("localhost","root","") or die("idle to server");
mysql_select_db("db_stk") or die("idle to database");

$title="STK Online";

function encrypss($str) { $key = '979a218e0632dferfert45dfg98d47956c7';
    for ($i = 0; $i < strlen($str); $i++) {
        $cractr = substr($str, $i, 1);
        $keycractr = substr($key, ($i % strlen($key))-1, 1);
        $cractr = chr(ord($cractr)+ord($keycractr));
        $done .= $cractr; 
	} return urlencode(base64_encode($done)); 
}
		
function max_id($table,$field) {
	$record=mysql_query("Select max($field)+1 as new_id from $table");
   	while($row=mysql_fetch_array($record)) {
		$new_id = $row[new_id];
	}
	if (!isset($new_id)){$new_id = 1;}
  	return $new_id;
}

function listtbl($table,$field) {
	$record=mysql_query("Select $field from $table");
	$list[]='idell';
	while($row=mysql_fetch_assoc($record)){
		$list[] = $row[$field];
	}
	return $list;
}

function opt_bag() {
	$bag=listtbl(tbagian,nmFungsi);
	$con= count($bag);
	for($i=1;$i<$con;$i++) {
//		if ((substr($bag[$i],0,7)=='Section')||(substr($bag[$i],0,7)=='Lead Of')) {$bag[$i]='--'.$bag[$i];}
		if ((!preg_match('/Manager/i', $bag[$i]))&&(!preg_match('/GM/i', $bag[$i]))&&(!preg_match('/Quality/i', $bag[$i]))&&(!preg_match('/Director/i', $bag[$i]))) {$bag[$i]='--'.$bag[$i];}
		$opsibag .= '<option value='.$i.'>'.$bag[$i].'</option>';
	}
	echo $opsibag;
}		
		
function llis() {
	
				  $k_kej=listtbl(tbagian,nmFungsi);
				  $con= count($k_kej);
					for($i=1;$i<$con;$i++) {
					  $listkejA .= $i.'## '.$k_kej[$i].'<br>';
					}
				  echo $listkejA;
}




?>
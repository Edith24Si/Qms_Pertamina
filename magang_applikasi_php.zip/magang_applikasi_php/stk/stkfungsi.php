<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "head.php";

include "menu.php";

$cari='';
$coor='';
	$color = $_GET['color'];$colar=$color[0].$color[1].$color[2];
	$coorp = $_GET['corporate']; 

		if ($colar=='HKM') $cari .= " AND (color='H' OR color='K' OR color='M')";
		if ($colar=='HK')  $cari .= " AND (color='H' OR color='K')";
		if ($colar=='HM')  $cari .= " AND (color='H' OR color='M')";
		if ($colar=='KM')  $cari .= " AND (color='K' OR color='M')";
		if ($colar=='H')   $cari .= " AND color='H'";
		if ($colar=='K')   $cari .= " AND color='K'";
		if ($colar=='M')   $cari .= " AND color='M'";

		if($coorp=='C')	   {$coor = " AND bagian_id != '100'"; $cr=" and Aa.idfungsi!='100'";}

	$query=mysql_query("select Aa.idfungsi,fungsi,pedoman,tko,tki,tkpa,jum,ket,urut from
						fungsibaru Aa left join (select idfungsi,ifnull(sum(jum),0) As Pedoman from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='Pedoman')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor group by idfungsi) Bb on Aa.idfungsi=Bb.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As TKO  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='TKO')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor group by idfungsi) Cc on Aa.idfungsi=Cc.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As TKI  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='TKI')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor group by idfungsi) Dd on Aa.idfungsi=Dd.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As TKPA from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='TKPA')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor group by idfungsi) Ee on Aa.idfungsi=Ee.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Jum  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='Pedoman' or jenis='TKO' or jenis='TKI' or jenis='TKPA')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor group by idfungsi) Ff on Aa.idfungsi=Ff.idfungsi where 1 $cr order by urut asc
						");
	$queryT=mysql_query("select Aa.idfungsi,fungsi,pedoman,tko,tki,tkpa,jum from
						fungsibaru Aa left join (select idfungsi,ifnull(sum(jum),0) As Pedoman from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='Pedoman')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor) Bb on Aa.idfungsi=Bb.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As TKO  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='TKO')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor) Cc on Aa.idfungsi=Cc.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As TKI  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='TKI')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor) Dd on Aa.idfungsi=Dd.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As TKPA from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='TKPA')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor) Ee on Aa.idfungsi=Ee.idfungsi left join (select idfungsi,ifnull(sum(jum),0) As Jum  from fungsibaru C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (jenis='Pedoman' or jenis='TKO' or jenis='TKI' or jenis='TKPA')
						$cari group by bagian_id) B on bagian_id=idfungsi where 1 $coor) Ff on Aa.idfungsi=Ff.idfungsi where 1
						");
						$rowt = mysql_fetch_array($queryT);
					
					
?>
	<!--//main awl//-->
<script type="text/javascript" class="init">
$(document).ready(function() {
    $('#example').DataTable(	{
	lengthMenu: [ [100, -1], [100, "All"] ]
	,language: {paginate: {previous: '&#9668;',next: '&#9658;'}, search: '&#128270;'
		,searchPlaceholder: 'Search all..', info: 'Total Dokumen : _TOTAL_'
		,infoEmpty: '', infoFiltered: '', zeroRecords: 'Dokumen tidak ditemukan..'}
	,dom: '<"top">rt<"clear">'
    }	);
} );
/*{paging: false,scrollY: 400}*/
</script>
<h3>Rekap Dokumen</h3>
	<form name="form1" method="get" action="">
<?
$hijau	=" <img src='inc/images/1.png' title='Dokumen baru / kurang dari 2,5 tahun'>";
$kuning =" <img src='inc/images/2.png' title='Dokumen antara 2,5 sampai 3 tahun'>";
$merah	=" <img src='inc/images/3.png' title='Dokumen sudah lebih dari 3 tahun'>";
echo "Rekapitulasi All Dokumen";
if($coorp=='C') echo " (kecuali Fungsi Corporate)";
if(($colar=='H')||($colar=='HK')||($colar=='HM')||($colar=='HKM')) echo $hijau;
if(($colar=='K')||($colar=='KM')||($colar=='HK')||($colar=='HKM')) echo $kuning;
if(($colar=='M')||($colar=='HM')||($colar=='KM')||($colar=='HKM')) echo $merah;
?>
	<div style="float:right">
	<span style="background:#cccccc;" title='Dokumen include/tidak dengan Corporate'><input type="checkbox" name="corporate" value="C" <?php if($coorp=='C') echo "checked" ?> onchange="this.form.submit()"></span>Non-Corporate
	<span style="background:#45E910;" title='Dokumen baru / kurang dari 2,5 tahun'><input type="checkbox" name="color[]" value="H" <?php if(($colar=='H')||($colar=='HK')||($colar=='HM')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<span style="background:#FFF225;" title='Dokumen antara 2,5 sampai 3 tahun'><input type="checkbox" name="color[]" value="K" <?php if(($colar=='K')||($colar=='KM')||($colar=='HK')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	<span style="background:#FE361E;" title='Dokumen sudah lebih dari 3 tahun'><input type="checkbox" name="color[]" value="M" <?php if(($colar=='M')||($colar=='HM')||($colar=='KM')||($colar=='HKM')) echo "checked" ?> onchange="this.form.submit()"></span>
	</div>
	</form>

<table id="example" class="cell-border compact hover order-column row-border stripe" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th width="200px">Fungsi</th>
                <th>Bagian</th>
                <th width="80px">Pedoman</th>
                <th width="80px">TKO</th>
                <th width="80px">TKI</th>
                <th width="80px">TKPA</th>
                <th width="80px">Jumlah</th>
<? 
	if ($_SESSION['USR_TYP']>9) {
?>
                <th>Actions</th>
<? 
	}
?>
            </tr>
        </thead>
        <tbody>
<?php
$merah	="<img src='inc/images/3.png' title='Dokumen sudah lebih dari 3 tahun'>";
$kuning ="<img src='inc/images/2.png' title='Dokumen antara 2,5 sampai 3 tahun'>";
$hijau	="<img src='inc/images/1.png' title='Dokumen baru / kurang dari 2,5 tahun'>";
$i = 0;
while($row = mysql_fetch_array($query)){
	$i=$i+1;
?>
            <tr>
                <td align="center"><?=$i?></td>
                <td><? if (in_array($row['idfungsi'], [1,2,3,10,17,21,26,32,33,37,41,44,49,54,57,60,63,64,65,67,98,99,100])) echo $row['fungsi']; else echo ""; ?></td>
                <td><? if (in_array($row['idfungsi'], [1,2,3,10,17,21,26,32,33,37,41,44,49,54,57,60,63,64,65,67,98,99,100])) echo ""; else echo $row['fungsi']; ?></td>
                <!--<td><? /* if($row['ket']!='') echo "&nbsp;&nbsp;&nbsp;&#8212;&nbsp;";?><?=$row['fungsi']; */?></td> -->
                <td align="center"><? if($row['pedoman']!='0') { ?><a href='home.php?jenis=Pedoman&fung=<?=$row['idfungsi']?>'><?=$row['pedoman']?></a><? }else echo "0"; ?></td>
                <td align="center"><? if($row['tko']!='0') { ?><a href='home.php?jenis=TKO&fung=<?=$row['idfungsi']?>'><?=$row['tko']?></a><? }else echo "0"; ?></td>
                <td align="center"><? if($row['tki']!='0') { ?><a href='home.php?jenis=TKI&fung=<?=$row['idfungsi']?>'><?=$row['tki']?></a><? }else echo "0"; ?></td>
                <td align="center"><? if($row['tkpa']!='0') { ?><a href='home.php?jenis=TKPA&fung=<?=$row['idfungsi']?>'><?=$row['tkpa']?></a><? }else echo "0"; ?></td>
                <td align="center"><? if($row['jum']!='0') { ?><a href='home.php?jenis=&fung=<?=$row['idfungsi']?>'><?=$row['jum']?></a><? }else echo "0"; ?></td>
<? 
	if ($_SESSION['USR_TYP']>9) {
?>
                <td align="center">
					<a href='update.php?bes=ed&id=<?=$row['idDokumen']?>'><img src='inc/images/edit.gif' title=Edit></a>
					<a href='update.php?bes=ex&id=<?=$row['idDokumen']?>&file=<?=$row['idDokumen']?>' onClick='return confirm (\"Anda yakin akan menghapus dokumen ini?\")'><img src='inc/images/del.gif' title=Hapus></a>&nbsp
				</td>
<? 
	}
?>
            </tr>
	 <?php } ?>
        </tbody>
        <tfoot>
            <tr>
                <th align="center" style="background-color:#CDCBCB;color:#CDCBCB;">.</th>
                <th align="right"  style="background-color:#CDCBCB;" colspan="2">=== Jumlah ===</th>
                <th align="center" style="background-color:#CDCBCB;"><?=$rowt['pedoman']?></td>
                <th align="center" style="background-color:#CDCBCB;"><?=$rowt['tko']?></td>
                <th align="center" style="background-color:#CDCBCB;"><?=$rowt['tki']?></td>
                <th align="center" style="background-color:#CDCBCB;"><?=$rowt['tkpa']?></td>
                <th align="center" style="background-color:#CDCBCB;" title="Jumlah Total"><?=$rowt['jum']?></td>
<? 
	if ($_SESSION['USR_TYP']>9) {
?>
                <th align="center" style="background-color:#CDCBCB;color:#CDCBCB;">.</th>
<? 
	}
?>
            </tr>
        </tfoot>
    </table>
	<!--//main end//-->
<?php
include "foot.php";
?>
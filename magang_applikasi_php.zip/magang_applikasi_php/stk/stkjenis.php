<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
include "inc/db.php";
include "head.php";

include "menu.php";

$cari='';
$coor='';
	$jenis = $_GET['jenis'];
	$coorp = $_GET['corporate']; 

		if($jenis != '')   $cari .= " AND jenis = '$jenis'";
		if($coorp=='C')	   {$coor = " AND fungsi_id != '20'"; $cr=" and idfungsi!='20'";}

	$query=mysql_query("select idfungsi,namafungsi,hijau,kuning,merah,jum from
						fungsi Aa left join (select fungsi_id,ifnull(sum(jum),0) As Hijau from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor group by fungsi_id) Bb on Aa.idfungsi=Bb.fungsi_id left join (select fungsi_id,ifnull(sum(jum),0) As Kuning  from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='K')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor group by fungsi_id) Cc on Aa.idfungsi=Cc.fungsi_id left join (select fungsi_id,ifnull(sum(jum),0) As Merah   from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='M')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor group by fungsi_id) Ee on Aa.idfungsi=Ee.fungsi_id left join (select fungsi_id,ifnull(sum(jum),0) As Jum     from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H' or color='K' or color='M')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor group by fungsi_id) Ff on Aa.idfungsi=Ff.fungsi_id where 1 $cr
						");
	$queryT=mysql_query("select idfungsi,namafungsi,hijau,kuning,merah,jum from
						fungsi Aa left join (select fungsi_id,ifnull(sum(jum),0) As Hijau from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor) Bb on Aa.idfungsi=Bb.fungsi_id left join (select fungsi_id,ifnull(sum(jum),0) As Kuning  from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='K')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor) Cc on Aa.idfungsi=Cc.fungsi_id left join (select fungsi_id,ifnull(sum(jum),0) As Merah   from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='M')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor) Ee on Aa.idfungsi=Ee.fungsi_id left join (select fungsi_id,ifnull(sum(jum),0) As Jum     from bagian C left join (select bagian_id,count(bagian_id) As jum from (select bagian_id,jenis,CASE when (datediff(current_date(), tglBerlaku )/365)>3 then 'M' when (datediff(current_date(), tglBerlaku )/365)>2.5 and (datediff(current_date(), tglBerlaku )/365)<=3 then 'K' when (datediff(current_date(), tglBerlaku )/365)<=2.5 then'H' END As color from dokumen where kadaluarsa!=1) A where 1 and (color='H' or color='K' or color='M')
						$cari group by bagian_id) B on bagian_id=idbagian where 1 $coor) Ff on Aa.idfungsi=Ff.fungsi_id where 1 and idfungsi='1' 
						");
						$rowt = mysql_fetch_array($queryT);
						
						
						
						
?>
	<!--//main awl//-->
<script type="text/javascript" class="init">
$(document).ready(function() {
    $('#example').DataTable(	{
	lengthMenu: [ [100, -1], [100, "All"] ]
	,language: {paginate: {previous: '&#9668;',next: '&#9658;'}, search: '&#128270;'
		,searchPlaceholder: 'Search all..', info: 'Total Dokumen : _TOTAL_'
		,infoEmpty: '', infoFiltered: '', zeroRecords: 'Dokumen tidak ditemukan..'}
	,dom: '<"top">rt<"clear">'
    }	);
} );
/*{paging: false,scrollY: 400}*/
</script>
<br>
	<form name="form1" method="get" action="">
<?
$hijau	=" <img src='inc/images/1.png' title='Dokumen baru / kurang dari 2,5 tahun'>";
$kuning =" <img src='inc/images/2.png' title='Dokumen antara 2,5 sampai 3 tahun'>";
$merah	=" <img src='inc/images/3.png' title='Dokumen sudah lebih dari 3 tahun'>";
echo "Rekapitulasi All Dokumen";
if($coorp=='C') echo " (kecuali Fungsi Corporate)";
if(($colar=='H')||($colar=='HK')||($colar=='HM')||($colar=='HKM')) echo $hijau;
if(($colar=='K')||($colar=='KM')||($colar=='HK')||($colar=='HKM')) echo $kuning;
if(($colar=='M')||($colar=='HM')||($colar=='KM')||($colar=='HKM')) echo $merah;
?>
	<div style="float:right">
	<span style="background:#cccccc;" title='Dokumen include/tidak dengan Corporate'><input type="checkbox" name="corporate" value="C" <?php if($coorp=='C') echo "checked" ?> onchange="this.form.submit()"></span>Non-Corporate
	<select name="jenis" onchange="this.form.submit()">
		<option value="">---semua jenis---</option>
		<option <?php if($_GET[jenis]=='Pedoman') echo "selected" ?>>Pedoman</option>
		<option <?php if($_GET[jenis]=='TKO') echo "selected" ?>>TKO</option>
		<option <?php if($_GET[jenis]=='TKI') echo "selected" ?>>TKI</option>
		<option <?php if($_GET[jenis]=='TKPA') echo "selected" ?>>TKPA</option>
	</select>
	</div>
	</form>

<table id="example" class="cell-border compact hover order-column row-border stripe" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Fungsi</th>
                <th width="80px"><?=$hijau?></th>
                <th width="80px"><?=$kuning?></th>
                <th width="80px"><?=$merah?></th>
                <th width="80px"><?=$hijau.$kuning.$merah?></th>
<? 
	if ($_SESSION['USR_TYP']>9) {
?>
                <th>Actions</th>
<? 
	}
?>
            </tr>
        </thead>
        <tbody>
<?php
$merah	="<img src='inc/images/3.png' title='Dokumen sudah lebih dari 3 tahun'>";
$kuning ="<img src='inc/images/2.png' title='Dokumen antara 2,5 sampai 3 tahun'>";
$hijau	="<img src='inc/images/1.png' title='Dokumen baru / kurang dari 2,5 tahun'>";
$i = 0;
while($row = mysql_fetch_array($query)){
	$i=$i+1;
?>
            <tr>
                <td align="center"><?=$i?></td>
                <td><?=$row['namafungsi'];?></td>
                <td align="center"><a href='home.php?jenis=Pedoman&fungsi_id=<?=$row['idfungsi']?>'><?=$row['hijau']?></a></td>
                <td align="center"><a href='home.php?jenis=TKO&fungsi_id=<?=$row['idfungsi']?>'><?=$row['kuning']?></a></td>
                <td align="center"><a href='home.php?jenis=TKI&fungsi_id=<?=$row['idfungsi']?>'><?=$row['merah']?></a></td>
                <td align="center"><a href='home.php?jenis=&fungsi_id=<?=$row['idfungsi']?>'><?=$row['jum']?></a></td>
<? 
	if ($_SESSION['USR_TYP']>9) {
?>
                <td align="center">
					<a href='update.php?bes=ed&id=<?=$row['idDokumen']?>'><img src='inc/images/edit.gif' title=Edit></a>
					<a href='update.php?bes=ex&id=<?=$row['idDokumen']?>&file=<?=$row['idDokumen']?>' onClick='return confirm (\"Anda yakin akan menghapus dokumen ini?\")'><img src='inc/images/del.gif' title=Hapus></a>&nbsp
				</td>
<? 
	}
?>
            </tr>
	 <?php } ?>
        </tbody>
        <tfoot>
            <tr>
                <th align="center" style="background-color:#CDCBCB;color:#CDCBCB;">.</th>
                <th align="right"  style="background-color:#CDCBCB;">=== Jumlah ===</th>
                <th align="center" style="background-color:#CDCBCB;"><?=$rowt['hijau']?></td>
                <th align="center" style="background-color:#CDCBCB;"><?=$rowt['kuning']?></td>
                <th align="center" style="background-color:#CDCBCB;"><?=$rowt['merah']?></td>
                <th align="center" style="background-color:#CDCBCB;" title="Jumlah Total"><?=$rowt['jum']?></td>
<? 
	if ($_SESSION['USR_TYP']>9) {
?>
                <th align="center" style="background-color:#CDCBCB;color:#CDCBCB;">.</th>
<? 
	}
?>
            </tr>
        </tfoot>
    </table>
	<!--//main end//-->
<?php
include "foot.php";
?>
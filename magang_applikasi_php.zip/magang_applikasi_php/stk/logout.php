<?php
session_start();
if(!isset($_SESSION['sttrekomendasi']))	{
	header("location:index.php");
}
//include "inc/db.php";
//$nopek = $_SESSION['USR_NPK'];
//$sql   = "update t_user set  stat=1,online=0,online_time='".date('Y-m-d H:i:s')."' where userid = '".$_SESSION['USR_USM']."'";
//$query = mysql_query($sql);
	unset($_SESSION['sttrekomendasi']);
	unset($_SESSION['USR_IDM']);
	unset($_SESSION['USR_USM']);
	unset($_SESSION['USR_NPK']);
	unset($_SESSION['USR_TYP']);
	unset($_SESSION['USR_NAME']);
	
header("location:index.php");
?>

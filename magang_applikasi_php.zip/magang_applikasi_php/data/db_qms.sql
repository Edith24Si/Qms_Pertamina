-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2026 at 05:00 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_qms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_comment`
--

CREATE TABLE `tb_comment` (
  `comment_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `no_peg` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `ket` varchar(20) NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_comment`
--

INSERT INTO `tb_comment` (`comment_id`, `username`, `no_peg`, `email`, `title`, `comment`, `ket`, `status`) VALUES
(1, 'abrory salman', 123, 'imantenshi@yahoo.co.id', 'Kurang UF', 'sistemnya kurang UF', 'reset', 'Y'),
(2, 'iman', 4321, 'imantenshi@gmail.com', 'Sangat Inteaktif dan Responsive di segala device', 'sistem yang ditawarkan sangat menarik dan responsive di segala device min.', '', ''),
(3, 'abrory', 14045, 'abrory.salman@yahoo.com', 'Test Pagi Ini', 'test dengan laptop crash', '', ''),
(4, 'pesan', 92745, 'pean@gmail.com', 'coba pesan', 'pesan dicoba', '', ''),
(5, 'Abrory Salman', 123, 'abrory.salman@yahoo.com', '', 'Tolong reset kembali password dengan nomor pegawai : 123, Terimakasih!', 'reset', 'Y'),
(6, 'iman', 2948365, 'iman@gmail.com', 'judul coba kirim gan', 'coba mencoba', '', ''),
(19, 'Neni Sri Wahyuni', 1234, 'test@yahoo.com', '', 'Tolong reset kembali password dengan nomor pegawai : 1234, Terimakasih!', 'reset', 'N'),
(20, 'coba', 12345, 'coba@gmail.com', '', 'Tolong reset kembali password dengan nomor pegawai : 12345, Terimakasih!', 'reset', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `tb_employee`
--

CREATE TABLE `tb_employee` (
  `no_peg` int(11) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `reset_pswd` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_employee`
--

INSERT INTO `tb_employee` (`no_peg`, `emp_name`, `password`, `reset_pswd`, `email`) VALUES
(112, 'Putri Afrisya Silvia', 'b80cdb16523bb342f10eb39e872c3634', 'b80cdb16523bb342f10eb39e872c3634', 'mk.putri.silvia@mitrakerja.pertamina.com');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gugus`
--

CREATE TABLE `tb_gugus` (
  `id_gugus` int(11) NOT NULL,
  `creator` varchar(100) NOT NULL,
  `category_gugus` varchar(100) NOT NULL,
  `nama_gugus` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `telp` varchar(16) NOT NULL,
  `acc` enum('Y','N') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gugus`
--

INSERT INTO `tb_gugus` (`id_gugus`, `creator`, `category_gugus`, `nama_gugus`, `title`, `telp`, `acc`) VALUES
(15, 'Abrory Salman', 'PKM', 'Bimasakti', 'Penerapan Metode DOM', '082171862626', 'Y'),
(16, 'Abrory Salman', 'SS', 'Splater', 'Penggunaan Teknik Splat dalam GCM', '085669153315', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE `tb_member` (
  `id_member` int(11) NOT NULL,
  `id_gugus` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `no_peg` varchar(20) DEFAULT NULL,
  `bagian` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`id_member`, `id_gugus`, `fullname`, `no_peg`, `bagian`, `status`) VALUES
(20, 15, 'Neni Sri Wahyuni', '1234', 'IT RU', 'Anggota'),
(19, 15, 'Abrory Salman', '123', 'IT RU', 'Ketua'),
(21, 16, 'Budiansyah', '789', 'HR', 'Ketua'),
(22, 16, 'Nur Aisyah', '900', 'HR', 'Anggota');

-- --------------------------------------------------------

--
-- Table structure for table `tb_menu`
--

CREATE TABLE `tb_menu` (
  `menu_id` int(11) NOT NULL,
  `menu` varchar(65) NOT NULL,
  `submenu` varchar(65) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_menu`
--

INSERT INTO `tb_menu` (`menu_id`, `menu`, `submenu`) VALUES
(17, 'CIP', 'Panduan CIP'),
(18, 'CIP', 'Contoh CIP - PKM'),
(19, 'CIP', 'Contoh CIP - GKM'),
(20, 'CIP', 'Contoh CIP - SS'),
(21, 'CIP', 'Klinik CIP'),
(22, 'CIP', 'Calendar of Event'),
(23, 'CIP', 'Gugus - List Gugus'),
(24, 'CIP', 'Gugus - Add Gugus'),
(25, 'Sistem Manajemen', 'Kebijakan Sistem Manajemen'),
(26, 'Sistem Manajemen', 'Requirement - 9001'),
(27, 'Sistem Manajemen', 'Requirement - 14001'),
(28, 'Sistem Manajemen', 'Requirement - 18001'),
(29, 'Sistem Manajemen', 'Requirement - SMP'),
(30, 'Sistem Manajemen', 'Requirement - MKP'),
(31, 'Sistem Manajemen', 'Internal Audit - Temuan 2025'),
(32, 'Sistem Manajemen', 'Internal Audit - Temuan 2026'),
(33, 'Sistem Manajemen', 'Internal Audit - Temuan 2027'),
(34, 'Sistem Manajemen', 'Internal Audit - Tindak Lanjut 2025'),
(35, 'Sistem Manajemen', 'Internal Audit - Tindak Lanjut 2026'),
(36, 'Sistem Manajemen', 'Internal Audit - Tindak Lanjut 2027'),
(37, 'Sistem Manajemen', 'Surveillance Audit - Temuan 2025'),
(38, 'Sistem Manajemen', 'Surveillance Audit - Temuan 2026'),
(39, 'Sistem Manajemen', 'Surveillance Audit - Temuan 2027'),
(40, 'Sistem Manajemen', 'Surveillance Audit - Tindak Lanjut 2025'),
(41, 'Sistem Manajemen', 'Surveillance Audit - Tindak Lanjut 2026'),
(42, 'Sistem Manajemen', 'Surveillance Audit - Tindak Lanjut 2027'),
(43, 'Sistem Manajemen', 'HIRADC'),
(44, 'Sistem Manajemen', 'Daftar Catatan/Rekaman Fungsi'),
(45, 'Sistem Manajemen', 'Rapat Tinjauan Manajemen'),
(46, 'Sistem Manajemen', 'Proses Bisnis'),
(47, 'STK', 'Form Standar TKO'),
(48, 'STK', 'Form Standar TKI'),
(49, 'STK', 'Form Standar Lainnya'),
(50, 'STK', 'STK Online'),
(51, 'KKEP - PQA', '2020'),
(52, 'KKEP - PQA', '2021'),
(53, 'KKEP - PQA', '2022'),
(54, 'KOMET', 'Contoh KOMET'),
(55, 'KOMET', 'Expert Form'),
(56, 'KOMET', 'Discussion Form'),
(57, 'KOMET', 'CoP'),
(58, 'KOMET', 'Converence Expert Interview'),
(59, 'KOMET', 'Asset Pengetahuan'),
(60, 'SP & SK', 'SP 2020 (dan sebelumnya)'),
(61, 'SP & SK', 'SP 2021'),
(62, 'SP & SK', 'SP 2022'),
(63, 'SP & SK', 'SP 2023'),
(64, 'SP & SK', 'SP 2024'),
(65, 'PPP', ''),
(66, 'SP & SK', 'SK 2020 (dan sebelumnya)'),
(67, 'SP & SK', 'SK 2021'),
(68, 'SP & SK', 'SK 2022'),
(69, 'SP & SK', 'SK 2023'),
(70, 'SP & SK', 'SK 2024'),
(71, 'SP & SK', 'SP 2025'),
(72, 'SP & SK', 'SK 2025'),
(73, 'SP & SK', 'SP 2026'),
(74, 'SP & SK', 'SK 2026');

-- --------------------------------------------------------

--
-- Table structure for table `tb_news`
--

CREATE TABLE `tb_news` (
  `id_news` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `creator` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `day` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `pictures` varchar(150) NOT NULL,
  `read` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_news`
--

INSERT INTO `tb_news` (`id_news`, `category`, `creator`, `title`, `content`, `day`, `date`, `time`, `pictures`, `read`) VALUES
(1, 'test', '', 'Aku Ingin Mencoba', 'test adkjfadfakdbfak dfdkfbn adofi adfpj adfpjod fad fqpoerj pqer paojfad fapdofj test adkjfadfakdbfak dfdkfbn adofi adfpj adfpjod fad fqpoerj pqer paojfad fapdofj test adkjfadfakdbfak dfdkfbn adofi adfpj adfpjod fad fqpoerj pqer paojfad fapdofj test adkjfadfakdbfak dfdkfbn adofi adfpj adfpjod fad fqpoerj pqer paojfad fapdofj test adkjfadfakdbfak dfdkfbn adofi adfpj adfpjod fad fqpoerj pqer paojfad fapdofj test adkjfadfakdbfak dfdkfbn adofi adfpj adfpjod fad fqpoerj pqer paojfad fapdofj test adkjfadfakdbfak dfdkfbn adofi adfpj adfpjod fad fqpoerj pqer paojfad fapdofj ', 'Jumat', '2014-07-04', '09:19:04', '../assets/img/news_dir/100_0798.jpg100_0798.jpg', 0),
(2, 'aa', 'admin', 'Aku Ingin Mencoba Dulu', 'test', 'Jumat', '2014-07-04', '09:22:42', '../assets/img/news_dir/oilrefinery_01.jpgoilrefinery_01.jpg', 0),
(3, 'coba', 'admin', 'mencoba 1', 'coba', 'Sabtu', '2014-07-05', '07:26:37', '../assets/img/news_dir/kilang_minyak_100827052449.jpg', 0),
(4, 'adfa', '', 'adf adfkdfn', 'adafdfad adfad adfad f', 'Jumat', '2014-07-18', '10:25:33', '../assets/img/news_dir/Chrysanthemum.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_upload`
--

CREATE TABLE `tb_upload` (
  `upload_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `creator` varchar(100) NOT NULL,
  `file_name` varchar(150) NOT NULL,
  `file_dir` varchar(150) NOT NULL,
  `size` varchar(10) NOT NULL,
  `type` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_upload`
--

INSERT INTO `tb_upload` (`upload_id`, `menu_id`, `creator`, `file_name`, `file_dir`, `size`, `type`) VALUES
(1, 63, 'admin', '087___SP_BAPOR.pdf', '../document/087___SP_BAPOR.pdf', '1401368', 'application/pdf'),
(2, 60, 'idell', 'test.pdf', '../document/test.pdf', '186273', 'application/pdf'),
(87, 64, 'admin', '004___SP_Panitia_Pencegahan_dan_Penanggulangan_HIV_AIDS_Ditempat_Kerja__Panitia_P2_HIV_AIDS_.pdf', '../document/004___SP_Panitia_Pencegahan_dan_Penanggulangan_HIV_AIDS_Ditempat_Kerja__Panitia_P2_HIV_AIDS_.pdf', '774147', 'application/pdf'),
(3, 64, 'admin', '002___SP_Internal_Audit_dan_RTM.pdf', '../document/002___SP_Internal_Audit_dan_RTM.pdf', '1237179', 'application/pdf'),
(4, 64, 'admin', '003___SP_Tim_Juri_Audit_Klinik_PIC_CIP.pdf', '../document/003___SP_Tim_Juri_Audit_Klinik_PIC_CIP.pdf', '1751013', 'application/pdf'),
(5, 64, 'admin', '005___SP_Tim_Task_Force_Follow_Up___Full_Risk_Survey_Asuransi.pdf', '../document/005___SP_Tim_Task_Force_Follow_Up___Full_Risk_Survey_Asuransi.pdf', '1373645', 'application/pdf'),
(32, 63, 'admin', 'No._063_SP___KPI45000_2023_S0__SP_TFGD_.pdf', '../document/No._063_SP___KPI45000_2023_S0__SP_TFGD_.pdf', '4754168', 'application/pdf'),
(6, 25, 'admin', 'KEBIJAKAN_SMT_GM.pdf', '../document/KEBIJAKAN_SMT_GM.pdf', '1820615', 'application/pdf'),
(68, 63, 'admin', 'No._006_SP_Team_Task_Fors_Risk_Register_2024__2_.pdf', '../document/No._006_SP_Team_Task_Fors_Risk_Register_2024__2_.pdf', '3136503', 'application/pdf'),
(31, 63, 'admin', 'No._030_SP___KPI45000_2023_S0__SP_Tim_Tender_2023___2_.pdf', '../document/No._030_SP___KPI45000_2023_S0__SP_Tim_Tender_2023___2_.pdf', '4203021', 'application/pdf'),
(7, 63, 'admin', 'N0._080_KPI_45000_2023_S0__SP_AEA_.pdf', '../document/N0._080_KPI_45000_2023_S0__SP_AEA_.pdf', '1353132', 'application/pdf'),
(8, 62, 'admin', 'No._002__SP_TBKD.pdf', '../document/No._002__SP_TBKD.pdf', '2776345', 'application/pdf'),
(30, 63, 'admin', 'No._003_KPI45000_2023_S0___SP_OTS_HCU__1_.pdf', '../document/No._003_KPI45000_2023_S0___SP_OTS_HCU__1_.pdf', '3278065', 'application/pdf'),
(28, 62, 'admin', 'No._076_SP_Audit_Lingkungan_2022.pdf', '../document/No._076_SP_Audit_Lingkungan_2022.pdf', '3735244', 'application/pdf'),
(29, 63, 'admin', 'No._082_SP___KPI_45000_2023_S0__SP_TTF__FG___RKAP_2024_.pdf', '../document/No._082_SP___KPI_45000_2023_S0__SP_TTF__FG___RKAP_2024_.pdf', '2951617', 'application/pdf'),
(27, 62, 'admin', 'No._063_SP_TBKD_SPK_2022.pdf', '../document/No._063_SP_TBKD_SPK_2022.pdf', '1924349', 'application/pdf'),
(25, 61, 'admin', 'No._060_SP_SMP.pdf', '../document/No._060_SP_SMP.pdf', '2520029', 'application/pdf'),
(26, 63, 'admin', 'No._061_SP___KPI45000_2023_S0___SP_Pemeriksaan_Fisik_HBM.pdf', '../document/No._061_SP___KPI45000_2023_S0___SP_Pemeriksaan_Fisik_HBM.pdf', '5118448', 'application/pdf'),
(23, 62, 'admin', 'No._058_SP_RBI.pdf', '../document/No._058_SP_RBI.pdf', '4697106', 'application/pdf'),
(24, 63, 'admin', 'No._060_SP___KPI45000_2023_S0___SP_Risk_Survey_Asuransi_.pdf', '../document/No._060_SP___KPI45000_2023_S0___SP_Risk_Survey_Asuransi_.pdf', '3753612', 'application/pdf'),
(21, 61, 'admin', 'No._051_SP_Supreme.pdf', '../document/No._051_SP_Supreme.pdf', '6132544', 'application/pdf'),
(22, 63, 'admin', 'No._054_SP___KPI45000_2023_S0__SP_PSAIMS_.pdf', '../document/No._054_SP___KPI45000_2023_S0__SP_PSAIMS_.pdf', '4320199', 'application/pdf'),
(19, 62, 'admin', 'No._034_SP_Audit_SMT.pdf', '../document/No._034_SP_Audit_SMT.pdf', '2482894', 'application/pdf'),
(20, 63, 'admin', 'No._046_SP___KPI_45000_2023_S0___SP_PS___COC__202_.pdf', '../document/No._046_SP___KPI_45000_2023_S0___SP_PS___COC__202_.pdf', '8632202', 'application/pdf'),
(9, 62, 'admin', 'No._002_KPI45000_2022_S0___SP_HIV_AIDS___2_.pdf', '../document/No._002_KPI45000_2022_S0___SP_HIV_AIDS___2_.pdf', '1460488', 'application/pdf'),
(18, 61, 'admin', 'No._028__SP_SMAP_RU_II.pdf', '../document/No._028__SP_SMAP_RU_II.pdf', '283560', 'application/pdf'),
(10, 63, 'admin', 'No._016_SP_PROPER__1_.pdf', '../document/No._016_SP_PROPER__1_.pdf', '4833317', 'application/pdf'),
(17, 63, 'admin', 'No._026_SP___KPI45000_2023_S0__SP_K3_.pdf', '../document/No._026_SP___KPI45000_2023_S0__SP_K3_.pdf', '7359052', 'application/pdf'),
(11, 63, 'admin', 'No._057_SP___KPI45000_2023_S0__SPPeremajaan_Pipa_di_OM_.pdf', '../document/No._057_SP___KPI45000_2023_S0__SPPeremajaan_Pipa_di_OM_.pdf', '3145253', 'application/pdf'),
(12, 63, 'admin', 'No._062_SP___KPI45000_2023_S0___Effisiensi_Listrik___Air_RDP_.pdf', '../document/No._062_SP___KPI45000_2023_S0___Effisiensi_Listrik___Air_RDP_.pdf', '1755613', 'application/pdf'),
(16, 62, 'admin', 'No._009._SP_Validasi_Data_RBI.pdf', '../document/No._009._SP_Validasi_Data_RBI.pdf', '4262765', 'application/pdf'),
(13, 63, 'admin', 'No._072_SP___KPI_45000_2023_S0__SP_Aviation_Inspector___4_.pdf', '../document/No._072_SP___KPI_45000_2023_S0__SP_Aviation_Inspector___4_.pdf', '2074801', 'application/pdf'),
(15, 62, 'admin', 'No._007_SP_ISRS_LVL_920220413045105_01.pdf', '../document/No._007_SP_ISRS_LVL_920220413045105_01.pdf', '8638605', 'application/pdf'),
(14, 63, 'admin', 'No._058_SP___KPI45000_2023_S0___SP_PPR____PKSR___2_.pdf', '../document/No._058_SP___KPI45000_2023_S0___SP_PPR____PKSR___2_.pdf', '4915731', 'application/pdf'),
(69, 63, 'admin', 'No._012_SP_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_2023__1_.pdf', '../document/No._012_SP_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_2023__1_.pdf', '2908036', 'application/pdf'),
(33, 63, 'admin', 'No._056_SP___KPI45000_2023_S0__SP_TRK_.pdf', '../document/No._056_SP___KPI45000_2023_S0__SP_TRK_.pdf', '2898796', 'application/pdf'),
(70, 63, 'admin', 'No._018_SP__KPI45000_2023_S0___Idea_Generation_Value_Creation___1_.pdf', '../document/No._018_SP__KPI45000_2023_S0___Idea_Generation_Value_Creation___1_.pdf', '8901033', 'application/pdf'),
(34, 66, 'admin', 'SK_TRK_2020_Rev..pdf', '../document/SK_TRK_2020_Rev..pdf', '6629103', 'application/pdf'),
(35, 63, 'admin', 'SP_08520231227091428_01.pdf', '../document/SP_08520231227091428_01.pdf', '7426157', 'application/pdf'),
(36, 62, 'admin', 'SP_078_KPI45000_2022_S0___SP_Risk_Survey_Asuransi_.pdf', '../document/SP_078_KPI45000_2022_S0___SP_Risk_Survey_Asuransi_.pdf', '2774028', 'application/pdf'),
(37, 61, 'admin', 'SP_Gas_External__Team_Task_Force_.pdf', '../document/SP_Gas_External__Team_Task_Force_.pdf', '4074404', 'application/pdf'),
(38, 62, 'admin', 'No._008_SP_Bazzma.pdf', '../document/No._008_SP_Bazzma.pdf', '2236743', 'application/pdf'),
(39, 62, 'admin', 'No._012_SPPersediaan_Minyak_Mentah.pdf', '../document/No._012_SPPersediaan_Minyak_Mentah.pdf', '3220895', 'application/pdf'),
(40, 62, 'admin', 'No._013_SP_TL_Rekom_Temuan_Asuransi.pdf', '../document/No._013_SP_TL_Rekom_Temuan_Asuransi.pdf', '2625308', 'application/pdf'),
(41, 62, 'admin', 'No._014_SP_Proper_2022.pdf', '../document/No._014_SP_Proper_2022.pdf', '4293775', 'application/pdf'),
(42, 62, 'admin', 'No._016_SP_Dewan_Mutu.pdf', '../document/No._016_SP_Dewan_Mutu.pdf', '3812558', 'application/pdf'),
(43, 62, 'admin', 'No._017_SP_Value_Creation.pdf', '../document/No._017_SP_Value_Creation.pdf', '8038595', 'application/pdf'),
(44, 68, 'admin', 'No._019_SK_Fas._Perusahaan.pdf', '../document/No._019_SK_Fas._Perusahaan.pdf', '3813325', 'application/pdf'),
(45, 68, 'admin', 'No._022_SK_CIP_2022.pdf', '../document/No._022_SK_CIP_2022.pdf', '3305961', 'application/pdf'),
(46, 62, 'admin', 'No._023_SP_Tim_Juri_Audit_Klinik___PIC_CIP_2022_RU_II_Rev.pdf', '../document/No._023_SP_Tim_Juri_Audit_Klinik___PIC_CIP_2022_RU_II_Rev.pdf', '4042728', 'application/pdf'),
(47, 62, 'admin', 'No._024_SP_KOMET_2022.pdf', '../document/No._024_SP_KOMET_2022.pdf', '3598130', 'application/pdf'),
(48, 62, 'admin', 'No._026_SP_Satgas_RAFI_2022.pdf', '../document/No._026_SP_Satgas_RAFI_2022.pdf', '2027607', 'application/pdf'),
(49, 62, 'admin', 'No._028_SP_Validasi_Data___Pemeriksaan_Fisik_HBM.pdf', '../document/No._028_SP_Validasi_Data___Pemeriksaan_Fisik_HBM.pdf', '2130994', 'application/pdf'),
(50, 62, 'admin', 'NO._030_SP_RJPP_2022.pdf', '../document/NO._030_SP_RJPP_2022.pdf', '2604447', 'application/pdf'),
(51, 62, 'admin', 'No._031_SP_BAPOR_2022___2023.pdf', '../document/No._031_SP_BAPOR_2022___2023.pdf', '3917013', 'application/pdf'),
(52, 62, 'admin', 'No._032_SP_ES14_Revisi.pdf', '../document/No._032_SP_ES14_Revisi.pdf', '3679339', 'application/pdf'),
(53, 62, 'admin', 'No._035_SP_ECA_FSCA_2022.pdf', '../document/No._035_SP_ECA_FSCA_2022.pdf', '3744979', 'application/pdf'),
(54, 62, 'admin', 'No._036_SP_HIRADC_2022.pdf', '../document/No._036_SP_HIRADC_2022.pdf', '4165955', 'application/pdf'),
(55, 62, 'admin', 'No._039_SP_ABP2022.pdf', '../document/No._039_SP_ABP2022.pdf', '2977977', 'application/pdf'),
(56, 62, 'admin', 'No._040_SP_ISO___37001.pdf', '../document/No._040_SP_ISO___37001.pdf', '3200931', 'application/pdf'),
(57, 62, 'admin', 'No._041_SP_SMP_2022.pdf', '../document/No._041_SP_SMP_2022.pdf', '4666187', 'application/pdf'),
(58, 62, 'admin', 'No._042_SP_MRS_2022.pdf', '../document/No._042_SP_MRS_2022.pdf', '3138224', 'application/pdf'),
(59, 62, 'admin', 'No._043._SP__DKE.pdf', '../document/No._043._SP__DKE.pdf', '2966975', 'application/pdf'),
(60, 62, 'admin', 'No._045_SP_STK.pdf', '../document/No._045_SP_STK.pdf', '1713650', 'application/pdf'),
(61, 62, 'admin', 'No._047_SP_Fas._TK_Short_Residue.pdf', '../document/No._047_SP_Fas._TK_Short_Residue.pdf', '4009246', 'application/pdf'),
(62, 62, 'admin', 'No._050._SP_Tim_Improvement_Supply_Loss_RU_II.pdf', '../document/No._050._SP_Tim_Improvement_Supply_Loss_RU_II.pdf', '4250838', 'application/pdf'),
(63, 62, 'admin', 'No._051._SP_TFT_Akselerasi_Pemanfaatan_RKA_Pemeliharaan_2022.pdf', '../document/No._051._SP_TFT_Akselerasi_Pemanfaatan_RKA_Pemeliharaan_2022.pdf', '2291079', 'application/pdf'),
(64, 62, 'admin', 'No._052._SP_Nitrogen_Plant_Kap_500_NM3.pdf', '../document/No._052._SP_Nitrogen_Plant_Kap_500_NM3.pdf', '2771927', 'application/pdf'),
(65, 62, 'admin', 'No._053_SP_PSSR_2022_2023.pdf', '../document/No._053_SP_PSSR_2022_2023.pdf', '4750718', 'application/pdf'),
(66, 62, 'admin', 'No._054_SP_Penggantian_Driver_Pompa_S._Rokan.pdf', '../document/No._054_SP_Penggantian_Driver_Pompa_S._Rokan.pdf', '3247636', 'application/pdf'),
(86, 64, 'admin', '010__SP_Tim_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_dan_Produk.pdf', '../document/010__SP_Tim_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_dan_Produk.pdf', '1450256', 'application/pdf'),
(67, 64, 'admin', '006___SP_Tim_Pengelola_Knowledge_Management__KOMET_.pdf', '../document/006___SP_Tim_Pengelola_Knowledge_Management__KOMET_.pdf', '1552507', 'application/pdf'),
(71, 63, 'admin', 'No._028_SP___KPI45000_2023_S0__SP_PROPER_SPK___2_.pdf', '../document/No._028_SP___KPI45000_2023_S0__SP_PROPER_SPK___2_.pdf', '4196757', 'application/pdf'),
(72, 63, 'admin', 'No._034_SP___KPI45000_2023_S0___SP_Tim_Pelaksanan_Implementasi_SMP_SPK_.pdf', '../document/No._034_SP___KPI45000_2023_S0___SP_Tim_Pelaksanan_Implementasi_SMP_SPK_.pdf', '2635375', 'application/pdf'),
(73, 63, 'admin', 'No._035_SP___KPI45000_2023_S0___SP_RDP___1_.pdf', '../document/No._035_SP___KPI45000_2023_S0___SP_RDP___1_.pdf', '2370324', 'application/pdf'),
(74, 63, 'admin', 'No._040_SP___KPI_45000_2023_S0__SP_BDI_2023___2025___1_.pdf', '../document/No._040_SP___KPI_45000_2023_S0__SP_BDI_2023___2025___1_.pdf', '2106335', 'application/pdf'),
(75, 63, 'admin', 'No._045_SP___KPI45000_2023___S0___SP_AOC___3_.pdf', '../document/No._045_SP___KPI45000_2023___S0___SP_AOC___3_.pdf', '4892532', 'application/pdf'),
(76, 63, 'admin', 'No._048___KPI45000_2023_S0___SP_BUFFER_ZONE___1_.pdf', '../document/No._048___KPI45000_2023_S0___SP_BUFFER_ZONE___1_.pdf', '2806079', 'application/pdf'),
(77, 63, 'admin', 'No._052_SP___KPI45000_2023_S0___SP_HIRADC___1_.pdf', '../document/No._052_SP___KPI45000_2023_S0___SP_HIRADC___1_.pdf', '3570521', 'application/pdf'),
(78, 63, 'admin', 'No._075_SP___KPI45000_2023_S0_TFT_Pengukuran_Stock_Inventory_Green_Coke__3_.pdf', '../document/No._075_SP___KPI45000_2023_S0_TFT_Pengukuran_Stock_Inventory_Green_Coke__3_.pdf', '2853094', 'application/pdf'),
(82, 69, 'admin', 'No._074_SK___KPI45000_2023_S0___SK_TRK_2023_.pdf', '../document/No._074_SK___KPI45000_2023_S0___SK_TRK_2023_.pdf', '22616990', 'application/pdf'),
(79, 63, 'admin', 'No._021_SP___KPI_45000_2023_S0___Firts_Aider_.pdf', '../document/No._021_SP___KPI_45000_2023_S0___Firts_Aider_.pdf', '4814261', 'application/pdf'),
(80, 63, 'admin', 'SP_026_P2K320230824094319_01.pdf', '../document/SP_026_P2K320230824094319_01.pdf', '7223677', 'application/pdf'),
(81, 63, 'admin', 'SP_Satgas_RAFI_1444_H.pdf', '../document/SP_Satgas_RAFI_1444_H.pdf', '1536209', 'application/pdf'),
(83, 69, 'admin', 'No._083_SK___KPI45000_2023_S0___SK_Hasil_Penilaian_Juri_CIP__.pdf', '../document/No._083_SK___KPI45000_2023_S0___SK_Hasil_Penilaian_Juri_CIP__.pdf', '2707050', 'application/pdf'),
(85, 64, 'admin', '009___SP_Tim_Task_Force_Percepatan_Perbaikan_Tanki_Timbun_Spk.pdf', '../document/009___SP_Tim_Task_Force_Percepatan_Perbaikan_Tanki_Timbun_Spk.pdf', '409017', 'application/pdf'),
(84, 64, 'admin', '008___SP_Dewan_Mutu_dan_Produktivitas_RU_II.pdf', '../document/008___SP_Dewan_Mutu_dan_Produktivitas_RU_II.pdf', '601929', 'application/pdf'),
(88, 62, 'admin', 'No._064_SP_HRA_HSSE_2022.pdf', '../document/No._064_SP_HRA_HSSE_2022.pdf', '2114123', 'application/pdf'),
(89, 64, 'admin', '001___SP_Tim_Pelaksana_Implementasi_Audit_SMP___IADRP.pdf', '../document/001___SP_Tim_Pelaksana_Implementasi_Audit_SMP___IADRP.pdf', '1927174', 'application/pdf'),
(200, 64, 'admin', '024___SP_Tim_Penyusun_Dokumen_Kinerja_Ekselen__DKE__RU_II.pdf', '../document/024___SP_Tim_Penyusun_Dokumen_Kinerja_Ekselen__DKE__RU_II.pdf', '1418567', 'application/pdf'),
(90, 64, 'admin', '011___SP_Panitia_Bulan_Keselamatan_dan_Kesehatan_Kerja__K3_.pdf', '../document/011___SP_Panitia_Bulan_Keselamatan_dan_Kesehatan_Kerja__K3_.pdf', '1796698', 'application/pdf'),
(91, 64, 'admin', '013___SP_Tim_Task_Force_Pelaksana_Project_Reformulasi_Product_Costing_di_Lingkungan_Refinery_Unit_II.pdf', '../document/013___SP_Tim_Task_Force_Pelaksana_Project_Reformulasi_Product_Costing_di_Lingkungan_Refinery_Unit_II.pdf', '1387990', 'application/pdf'),
(198, 64, 'admin', '014___SP_Tim_Penerapan_dan_Sertifikasi_ISO_37001_2016_Sistem_Manajemen_Anti_Penyuapan__SMAP__Refinery_Unit_II.pdf', '../document/014___SP_Tim_Penerapan_dan_Sertifikasi_ISO_37001_2016_Sistem_Manajemen_Anti_Penyuapan__SMAP__Refinery_Unit_II.pdf', '1778801', 'application/pdf'),
(201, 64, 'admin', '018___SP_Tim_Audit_Sistem_Tata_Kerja_Pertamina_RU_II_PT_Kilang_Pertamina_Internasional_Tahun_2024.pdf', '../document/018___SP_Tim_Audit_Sistem_Tata_Kerja_Pertamina_RU_II_PT_Kilang_Pertamina_Internasional_Tahun_2024.pdf', '2493302', 'application/pdf'),
(92, 19, 'admin', 'RIS___RU_II___FTP_FIRGON___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___FTP_FIRGON___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '7109113', 'application/pdf'),
(93, 18, 'admin', 'RIS___RU_II_PCP_TANKER___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II_PCP_TANKER___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '4308631', 'application/pdf'),
(94, 18, 'admin', 'RIS___RU_II___PCP_MINION___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___PCP_MINION___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '15348955', 'application/pdf'),
(95, 18, 'admin', 'RIS___RU_II___PCP_Keris_Semar___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___PCP_Keris_Semar___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '7334788', 'application/pdf'),
(96, 18, 'admin', 'RIS___RU_II___PCP_METHAVERS___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___PCP_METHAVERS___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '12868390', 'application/pdf'),
(97, 18, 'admin', 'RIS___RU_II___RTP_TG_Ranger_Pro___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___RTP_TG_Ranger_Pro___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '3340411', 'application/pdf'),
(98, 18, 'admin', 'RIS___RU_II___PCP_ALL_FOR_ONE___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___PCP_ALL_FOR_ONE___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '7673707', 'application/pdf'),
(99, 18, 'admin', 'RIS___RU_II___PCP_SEAS___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___PCP_SEAS___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '5600499', 'application/pdf'),
(100, 18, 'admin', 'RIS___RU_II___PCP_RI_CO___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___PCP_RI_CO___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '13281997', 'application/pdf'),
(101, 19, 'admin', 'RU_II___FTP_DigtiLeak___RISALAH_FINAL_FORUM_PT.KPI_2022.pdf', '../document/RU_II___FTP_DigtiLeak___RISALAH_FINAL_FORUM_PT.KPI_2022.pdf', '7387348', 'application/pdf'),
(102, 20, 'admin', 'RIS___RU_II___IP_ADIGUNA___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '../document/RIS___RU_II___IP_ADIGUNA___RISALAH_FINAL_FORUM_PT._KPI_2022.pdf', '7990449', 'application/pdf'),
(103, 17, 'admin', 'TEMPLATE_Risalah_2024.pdf', '../document/TEMPLATE_Risalah_2024.pdf', '1632780', 'application/pdf'),
(104, 20, 'admin', '1._I_Prove_BORDESK.pdf', '../document/1._I_Prove_BORDESK.pdf', '1285788', 'application/pdf'),
(105, 20, 'admin', '2._I_Prove_MOT.pdf', '../document/2._I_Prove_MOT.pdf', '1398835', 'application/pdf'),
(106, 18, 'admin', '3._PC_Prove_RESONANCE.pdf', '../document/3._PC_Prove_RESONANCE.pdf', '1827949', 'application/pdf'),
(107, 20, 'admin', '4._I_Prove__RIDO_RIZKY.pdf', '../document/4._I_Prove__RIDO_RIZKY.pdf', '1545028', 'application/pdf'),
(108, 20, 'admin', '5._I_Prove_SR.pdf', '../document/5._I_Prove_SR.pdf', '1356875', 'application/pdf'),
(109, 20, 'admin', '6._I_Prove_JA_IM.pdf', '../document/6._I_Prove_JA_IM.pdf', '1587044', 'application/pdf'),
(114, 20, 'admin', '1._I_Prove_ENJOY_MOMENT_1.pdf', '../document/1._I_Prove_ENJOY_MOMENT_1.pdf', '1419081', 'application/pdf'),
(110, 20, 'admin', '7._I_Prove_DARAH_MUDA.pdf', '../document/7._I_Prove_DARAH_MUDA.pdf', '1353627', 'application/pdf'),
(113, 20, 'admin', '11._I_Prove_BORAK.pdf', '../document/11._I_Prove_BORAK.pdf', '1369794', 'application/pdf'),
(112, 20, 'admin', '10.__I_Prove_ADUK.pdf', '../document/10.__I_Prove_ADUK.pdf', '1291850', 'application/pdf'),
(111, 20, 'admin', '9.__I_Prove_LUNA_2.0.pdf', '../document/9.__I_Prove_LUNA_2.0.pdf', '1817072', 'application/pdf'),
(115, 20, 'admin', '2._I_Prove_ENJOY_MOMENT_2.pdf', '../document/2._I_Prove_ENJOY_MOMENT_2.pdf', '1394645', 'application/pdf'),
(116, 20, 'admin', '3._I_Prove_RIVER.pdf', '../document/3._I_Prove_RIVER.pdf', '1145110', 'application/pdf'),
(117, 20, 'admin', '4._I_Prove_BISOL.pdf', '../document/4._I_Prove_BISOL.pdf', '1062315', 'application/pdf'),
(118, 20, 'admin', '5._I_Prove_LAGU_IMUT.pdf', '../document/5._I_Prove_LAGU_IMUT.pdf', '1787351', 'application/pdf'),
(119, 20, 'admin', '6._I_Prove_DOUBLE_FEEDER_1.pdf', '../document/6._I_Prove_DOUBLE_FEEDER_1.pdf', '1337163', 'application/pdf'),
(120, 20, 'admin', '7._I_Prove_DOUBLE_FEEDER_2.pdf', '../document/7._I_Prove_DOUBLE_FEEDER_2.pdf', '1322188', 'application/pdf'),
(121, 20, 'admin', '8._I__Prove_DOUBLE_FEEDER_3.pdf', '../document/8._I__Prove_DOUBLE_FEEDER_3.pdf', '1339327', 'application/pdf'),
(122, 20, 'admin', '8._I__Prove_DOUBLE_FEEDER_3.pdf', '../document/8._I__Prove_DOUBLE_FEEDER_3.pdf', '1339327', 'application/pdf'),
(123, 20, 'admin', '9._I_Prove_BEDELAU.pdf', '../document/9._I_Prove_BEDELAU.pdf', '4323000', 'application/pdf'),
(124, 20, 'admin', '10._I_Prove_AA.pdf', '../document/10._I_Prove_AA.pdf', '1146697', 'application/pdf'),
(125, 20, 'admin', '11._I_Prove_520.pdf', '../document/11._I_Prove_520.pdf', '1517179', 'application/pdf'),
(126, 20, 'admin', '12_._I_Prove_601.pdf', '../document/12_._I_Prove_601.pdf', '1293805', 'application/pdf'),
(127, 20, 'admin', '1._I_Prove_AUGOS.pdf', '../document/1._I_Prove_AUGOS.pdf', '1724968', 'application/pdf'),
(128, 20, 'admin', '2_._I_Prove_KATROS.pdf', '../document/2_._I_Prove_KATROS.pdf', '1528709', 'application/pdf'),
(129, 20, 'admin', '3._I_Prove_POP.pdf', '../document/3._I_Prove_POP.pdf', '2502200', 'application/pdf'),
(130, 20, 'admin', '4._I_Prove__BOCOR.pdf', '../document/4._I_Prove__BOCOR.pdf', '3877546', 'application/pdf'),
(131, 20, 'admin', '5_._I_Prove_ENJOY_MOMENT_3.pdf', '../document/5_._I_Prove_ENJOY_MOMENT_3.pdf', '1388692', 'application/pdf'),
(132, 20, 'admin', '6_._I_Prove_ENJOY_MOMENT_4.pdf', '../document/6_._I_Prove_ENJOY_MOMENT_4.pdf', '1454628', 'application/pdf'),
(133, 19, 'admin', '7._FT_Prove_FIRGON.pdf', '../document/7._FT_Prove_FIRGON.pdf', '2448123', 'application/pdf'),
(134, 20, 'admin', '8._I_Prove_E_A.pdf', '../document/8._I_Prove_E_A.pdf', '2113559', 'application/pdf'),
(135, 20, 'admin', '9._I_Prove_CLEARATOR.pdf', '../document/9._I_Prove_CLEARATOR.pdf', '1821198', 'application/pdf'),
(136, 20, 'admin', '10._I_Prove_EASY_MAN.pdf', '../document/10._I_Prove_EASY_MAN.pdf', '1131362', 'application/pdf'),
(137, 20, 'admin', '11._I_Prove_ALUMINIUM.pdf', '../document/11._I_Prove_ALUMINIUM.pdf', '1100264', 'application/pdf'),
(150, 20, 'admin', '1._I_PROVE_AA.pdf', '../document/1._I_PROVE_AA.pdf', '1685493', 'application/pdf'),
(138, 20, 'admin', '12._I_Prove__PUMP.pdf', '../document/12._I_Prove__PUMP.pdf', '1540228', 'application/pdf'),
(139, 20, 'admin', '1._I_Prove_RE_CORD.pdf', '../document/1._I_Prove_RE_CORD.pdf', '1429847', 'application/pdf'),
(140, 20, 'admin', '2_._I_Prove_BS.pdf', '../document/2_._I_Prove_BS.pdf', '1396948', 'application/pdf'),
(141, 20, 'admin', '3._I_Prove_FLAME.pdf', '../document/3._I_Prove_FLAME.pdf', '1509054', 'application/pdf'),
(142, 20, 'admin', '4._I_Prove_BAROCK.pdf', '../document/4._I_Prove_BAROCK.pdf', '1216043', 'application/pdf'),
(143, 20, 'admin', '5._I_Prove_BOILER_HURA.pdf', '../document/5._I_Prove_BOILER_HURA.pdf', '1324002', 'application/pdf'),
(144, 20, 'admin', '6._I_Prove_OPERATOR_HURA.pdf', '../document/6._I_Prove_OPERATOR_HURA.pdf', '1365065', 'application/pdf'),
(145, 20, 'admin', '7._I_Prove__SEDAP_MANTAP.pdf', '../document/7._I_Prove__SEDAP_MANTAP.pdf', '1886155', 'application/pdf'),
(146, 20, 'admin', '8._I_Prove_BAYU__ANDRIANTO_1.pdf', '../document/8._I_Prove_BAYU__ANDRIANTO_1.pdf', '1658304', 'application/pdf'),
(147, 20, 'admin', '9._I_Prove_BAYU_ANDRIANTO_2.pdf', '../document/9._I_Prove_BAYU_ANDRIANTO_2.pdf', '1701430', 'application/pdf'),
(148, 20, 'admin', '10_._I_Prove_DD_1.0.pdf', '../document/10_._I_Prove_DD_1.0.pdf', '1836888', 'application/pdf'),
(149, 20, 'admin', '11._I_Prove_IRZAL_VICRY.pdf', '../document/11._I_Prove_IRZAL_VICRY.pdf', '1631793', 'application/pdf'),
(151, 19, 'admin', '2._FT_PROVE_DCU_RANGERS.pdf', '../document/2._FT_PROVE_DCU_RANGERS.pdf', '2884626', 'application/pdf'),
(159, 19, 'admin', '11._FT_PROVE_FLAME_ON.pdf', '../document/11._FT_PROVE_FLAME_ON.pdf', '1341703', 'application/pdf'),
(152, 20, 'admin', '4._I_PROVE_D_H.pdf', '../document/4._I_PROVE_D_H.pdf', '3019103', 'application/pdf'),
(153, 19, 'admin', '5._FT_PROVE_NOZFLOK.pdf', '../document/5._FT_PROVE_NOZFLOK.pdf', '1733911', 'application/pdf'),
(154, 20, 'admin', '6._I_PROVE_MA_4_ROT.pdf', '../document/6._I_PROVE_MA_4_ROT.pdf', '1971442', 'application/pdf'),
(155, 19, 'admin', '7._FT_PROVE_VACUUM.pdf', '../document/7._FT_PROVE_VACUUM.pdf', '10237366', 'application/pdf'),
(173, 20, 'admin', '2._I_PROVE_UP_OI.pdf', '../document/2._I_PROVE_UP_OI.pdf', '1622278', 'application/pdf'),
(160, 19, 'admin', '1._FT_PROVE_ROCOAT.pdf', '../document/1._FT_PROVE_ROCOAT.pdf', '1907666', 'application/pdf'),
(156, 20, 'admin', '8._I_Prove__SEDAP_MANTAP.pdf', '../document/8._I_Prove__SEDAP_MANTAP.pdf', '1842263', 'application/pdf'),
(157, 18, 'admin', '9._PC_PROVE_ECO_ENERGY.pdf', '../document/9._PC_PROVE_ECO_ENERGY.pdf', '4010942', 'application/pdf'),
(158, 19, 'admin', '10._FT_PROVE_INSTRUMENTKAN.pdf', '../document/10._FT_PROVE_INSTRUMENTKAN.pdf', '1394618', 'application/pdf'),
(161, 20, 'admin', '2._I_PROVE_EXISTENCE.pdf', '../document/2._I_PROVE_EXISTENCE.pdf', '1381954', 'application/pdf'),
(162, 18, 'admin', '3._PC_PROVE_CESAR.pdf', '../document/3._PC_PROVE_CESAR.pdf', '2727613', 'application/pdf'),
(163, 20, 'admin', '4._I_PROVE_GASTOM.pdf', '../document/4._I_PROVE_GASTOM.pdf', '2429232', 'application/pdf'),
(164, 20, 'admin', '5.__I_PROVE__AM.pdf', '../document/5.__I_PROVE__AM.pdf', '1902021', 'application/pdf'),
(172, 20, 'admin', '1._I_PROVE_AW.pdf', '../document/1._I_PROVE_AW.pdf', '2149154', 'application/pdf'),
(165, 20, 'admin', '6._I_PROVE_AVATAR_1.pdf', '../document/6._I_PROVE_AVATAR_1.pdf', '407508', 'application/pdf'),
(166, 19, 'admin', '7._FT_PROVE_DIGTI_LEAK.pdf', '../document/7._FT_PROVE_DIGTI_LEAK.pdf', '7029896', 'application/pdf'),
(167, 20, 'admin', '8._I_PROVE_FLOWCOMB.pdf', '../document/8._I_PROVE_FLOWCOMB.pdf', '1139258', 'application/pdf'),
(168, 19, 'admin', '9._FT_PROVE__SINICUI.pdf', '../document/9._FT_PROVE__SINICUI.pdf', '2457243', 'application/pdf'),
(169, 20, 'admin', '10._I_Prove_DOUBLE_FEEDER_1.pdf', '../document/10._I_Prove_DOUBLE_FEEDER_1.pdf', '1338144', 'application/pdf'),
(170, 20, 'admin', '11._I_PROVE_FLAMEON.pdf', '../document/11._I_PROVE_FLAMEON.pdf', '1548992', 'application/pdf'),
(171, 20, 'admin', '12._I_PROVE_PRENPUMP.pdf', '../document/12._I_PROVE_PRENPUMP.pdf', '1439711', 'application/pdf'),
(174, 20, 'admin', '3._I_Prove_POP.pdf', '../document/3._I_Prove_POP.pdf', '2568667', 'application/pdf'),
(175, 20, 'admin', '4._I_PROVE__BOCOR.pdf', '../document/4._I_PROVE__BOCOR.pdf', '3880923', 'application/pdf'),
(176, 18, 'admin', '5._PC_PROVE_THE_TRACER.pdf', '../document/5._PC_PROVE_THE_TRACER.pdf', '2242643', 'application/pdf'),
(177, 20, 'admin', '6._I_PROVE_140_TA.pdf', '../document/6._I_PROVE_140_TA.pdf', '641146', 'application/pdf'),
(178, 20, 'admin', '8._I_PROVE_AVATAR_3.pdf', '../document/8._I_PROVE_AVATAR_3.pdf', '478163', 'application/pdf'),
(179, 19, 'admin', '9._FT__PROVE_PDTL_CREW_1.pdf', '../document/9._FT__PROVE_PDTL_CREW_1.pdf', '1574553', 'application/pdf'),
(180, 20, 'admin', '10._I_PROVE_PDTL_CREW_2.pdf', '../document/10._I_PROVE_PDTL_CREW_2.pdf', '1492950', 'application/pdf'),
(181, 20, 'admin', '11._I_PROVE_ELIT.pdf', '../document/11._I_PROVE_ELIT.pdf', '1614721', 'application/pdf'),
(182, 20, 'admin', '12._I_Prove_LUNA_2.0.pdf', '../document/12._I_Prove_LUNA_2.0.pdf', '1809911', 'application/pdf'),
(183, 19, 'admin', '1._FT_PROVE__RE_CORD.pdf', '../document/1._FT_PROVE__RE_CORD.pdf', '1412683', 'application/pdf'),
(184, 19, 'admin', '2._FT__PROVE_SATGASSUS_ELECTRICAL_MA4_A.pdf', '../document/2._FT__PROVE_SATGASSUS_ELECTRICAL_MA4_A.pdf', '2379722', 'application/pdf'),
(185, 19, 'admin', '3._FT_PROVE_SATGASSUS_ELECTRICAL_MA4_B.pdf', '../document/3._FT_PROVE_SATGASSUS_ELECTRICAL_MA4_B.pdf', '1681573', 'application/pdf'),
(186, 19, 'admin', '4._FT_PROVE__AUTO_WATER.pdf', '../document/4._FT_PROVE__AUTO_WATER.pdf', '1582212', 'application/pdf'),
(187, 20, 'admin', '5._I_PROVE_He.pdf', '../document/5._I_PROVE_He.pdf', '1649053', 'application/pdf'),
(188, 20, 'admin', '6._I_PROVE_SS_DSI.pdf', '../document/6._I_PROVE_SS_DSI.pdf', '10746319', 'application/pdf'),
(189, 18, 'admin', '7._PC_PROVE_PMI.pdf', '../document/7._PC_PROVE_PMI.pdf', '2346729', 'application/pdf'),
(190, 20, 'admin', '8._I_Prove_OPERATOR_HURA.pdf', '../document/8._I_Prove_OPERATOR_HURA.pdf', '1371139', 'application/pdf'),
(191, 18, 'admin', '9._PC_PROVE__VIT_C.pdf', '../document/9._PC_PROVE__VIT_C.pdf', '1521522', 'application/pdf'),
(192, 20, 'admin', '10._I_Prove_AA.pdf', '../document/10._I_Prove_AA.pdf', '1142478', 'application/pdf'),
(193, 20, 'admin', '11._I_Prove_DOUBLE_FEEDER_2.pdf', '../document/11._I_Prove_DOUBLE_FEEDER_2.pdf', '1320901', 'application/pdf'),
(194, 20, 'admin', '12._PCP_THE_BIDDERS.pdf', '../document/12._PCP_THE_BIDDERS.pdf', '384922', 'application/pdf'),
(195, 20, 'admin', '13._I__Prove_DOUBLE_FEEDER_3.pdf', '../document/13._I__Prove_DOUBLE_FEEDER_3.pdf', '1336759', 'application/pdf'),
(197, 64, 'admin', '017___SP_Susunan_Pengurus_Badan_Koordinasi_Umat_Kristen__BAKOR_UMKRIS__RU_II_Dumai_PT_KPI_Periode_Tahun_2024_2026.pdf', '../document/017___SP_Susunan_Pengurus_Badan_Koordinasi_Umat_Kristen__BAKOR_UMKRIS__RU_II_Dumai_PT_KPI_Periode_Tahun_2024_2026.pdf', '1266981', 'application/pdf'),
(196, 63, 'admin', '016___SP_Tim_Task_Force_Risk_Survey_Asuransi_RU_II_PT_KPI_Periode_2024.pdf', '../document/016___SP_Tim_Task_Force_Risk_Survey_Asuransi_RU_II_PT_KPI_Periode_2024.pdf', '3831919', 'application/pdf'),
(231, 64, 'admin', '015___SP_Tim_Task_Force_Pengelolaan_Lingkungan_Terpadu_RU_II_Dumai_Periode_2024_PT_KPI.pdf', '../document/015___SP_Tim_Task_Force_Pengelolaan_Lingkungan_Terpadu_RU_II_Dumai_Periode_2024_PT_KPI.pdf', '4444862', 'application/pdf'),
(232, 64, 'admin', '047___SP_Anggota_Kepengurusan_Keberagaman_Dan_Inklusi_Perempuan_Pertamina_Tangguh_Inspiratif_Wibawa_Dan_Integritas__PERTIWI__RU_II_PT_KPI.pdf', '../document/047___SP_Anggota_Kepengurusan_Keberagaman_Dan_Inklusi_Perempuan_Pertamina_Tangguh_Inspiratif_Wibawa_Dan_Integritas__PERTIWI__RU_II_PT_KPI.', '1207841', 'application/pdf'),
(202, 64, 'admin', '025___SP_Tim_Implementasi_Pengelolaan_Sistem_Tata_Kerja__STK__RU_II.pdf', '../document/025___SP_Tim_Implementasi_Pengelolaan_Sistem_Tata_Kerja__STK__RU_II.pdf', '1573153', 'application/pdf'),
(199, 64, 'admin', '022___SP_Tim_Satuan_Tugas__SATGAS__Ramadhan_dan_Idul_Fitri_2024__RAFI_.pdf', '../document/022___SP_Tim_Satuan_Tugas__SATGAS__Ramadhan_dan_Idul_Fitri_2024__RAFI_.pdf', '1111648', 'application/pdf'),
(205, 64, 'admin', '023___SP_Panitia_Pembina_Keselamatan_dan_Kesehatan_Kerja__P2K3_.pdf', '../document/023___SP_Panitia_Pembina_Keselamatan_dan_Kesehatan_Kerja__P2K3_.pdf', '1433153', 'application/pdf'),
(203, 64, 'admin', '026___SP_Tim_Implementasi_Pengelolaan_Administrasi_Terpadu_Pertamina__PATP__RU_II.pdf', '../document/026___SP_Tim_Implementasi_Pengelolaan_Administrasi_Terpadu_Pertamina__PATP__RU_II.pdf', '1477049', 'application/pdf'),
(204, 64, 'admin', '027___SP_Tim_Pengelolaan_Lingkungan_Production_Spk_Thn._2024.pdf', '../document/027___SP_Tim_Pengelolaan_Lingkungan_Production_Spk_Thn._2024.pdf', '3907508', 'application/pdf'),
(206, 64, 'admin', '033___SP_Tim_Psychological_First_Aider__PFA__di_RU_II_Dumai_PT_KPI_Thn._2024.pdf', '../document/033___SP_Tim_Psychological_First_Aider__PFA__di_RU_II_Dumai_PT_KPI_Thn._2024.pdf', '1283133', 'application/pdf'),
(207, 64, 'admin', '034___SP_Team_Pelaksana_Team_Task_Force_Pembenahan_Lampu_Penerangan.pdf', '../document/034___SP_Team_Pelaksana_Team_Task_Force_Pembenahan_Lampu_Penerangan.pdf', '1469726', 'application/pdf'),
(208, 63, 'admin', '035__Kepengurusan_Putri_Tujuh_Golf_Club__PTGC__PT_Kilang_Pertamina_Internasional_RU_II_Periode_2024_2026.pdf', '../document/035__Kepengurusan_Putri_Tujuh_Golf_Club__PTGC__PT_Kilang_Pertamina_Internasional_RU_II_Periode_2024_2026.pdf', '1457827', 'application/pdf'),
(209, 63, 'admin', '035__Kepengurusan_Putri_Tujuh_Golf_Club__PTGC__PT_Kilang_Pertamina_Internasional_RU_II_Periode_2024_2026.pdf', '../document/035__Kepengurusan_Putri_Tujuh_Golf_Club__PTGC__PT_Kilang_Pertamina_Internasional_RU_II_Periode_2024_2026.pdf', '1457827', 'application/pdf'),
(210, 64, 'admin', '035___Kepengurusan_Putri_Tujuh_Golf_Club__PTGC__PT_Kilang_Pertamina_Internasional_RU_II_Periode_2024_2026.pdf', '../document/035___Kepengurusan_Putri_Tujuh_Golf_Club__PTGC__PT_Kilang_Pertamina_Internasional_RU_II_Periode_2024_2026.pdf', '1457827', 'application/pdf'),
(211, 18, 'admin', 'RIS___RU_II___PCP_ADO___APQA_2024.pdf', '../document/RIS___RU_II___PCP_ADO___APQA_2024.pdf', '9551140', 'application/pdf'),
(212, 18, 'admin', 'RIS___RU_II___PCP_ALL_FOR_ONE___APQA_2024.pdf', '../document/RIS___RU_II___PCP_ALL_FOR_ONE___APQA_2024.pdf', '6745028', 'application/pdf'),
(213, 18, 'admin', 'RIS___RU_II___PCP_ALLIEN___APQA_2024.pdf', '../document/RIS___RU_II___PCP_ALLIEN___APQA_2024.pdf', '17306309', 'application/pdf'),
(214, 18, 'admin', 'RIS___RU_II___PCP_BEST___APQA_2024.pdf', '../document/RIS___RU_II___PCP_BEST___APQA_2024.pdf', '19275122', 'application/pdf'),
(215, 18, 'admin', 'RIS___RU_II___PCP_GSPRING_2.0___APQA_2024.pdf', '../document/RIS___RU_II___PCP_GSPRING_2.0___APQA_2024.pdf', '2733149', 'application/pdf'),
(216, 18, 'admin', 'RIS___RU_II___PCP_INDAH_3.0___APQA_2024.pdf', '../document/RIS___RU_II___PCP_INDAH_3.0___APQA_2024.pdf', '17726011', 'application/pdf'),
(217, 18, 'admin', 'RIS___RU_II___PCP_MADCOM___APQA_2024.pdf', '../document/RIS___RU_II___PCP_MADCOM___APQA_2024.pdf', '19954172', 'application/pdf'),
(218, 18, 'admin', 'RIS___RU_II___PCP_SPECIAL_STOPPER___APQA_2024.pdf', '../document/RIS___RU_II___PCP_SPECIAL_STOPPER___APQA_2024.pdf', '17311247', 'application/pdf'),
(219, 18, 'admin', 'RIS___RU_II___RTP_NUSANTARA___APQA_2024.pdf', '../document/RIS___RU_II___RTP_NUSANTARA___APQA_2024.pdf', '10147334', 'application/pdf'),
(220, 18, 'admin', 'RIS___RU_II___RTP_ROCKER_3.0___APQA_2024.pdf', '../document/RIS___RU_II___RTP_ROCKER_3.0___APQA_2024.pdf', '15353171', 'application/pdf'),
(221, 64, 'admin', '036___SP_Data_Collection_Team_Refinery_Unit_II_Dumai_Untuk_SOLOMON_Benchmarking_Study_Tahun_2024___2026_PT_KPI.pdf', '../document/036___SP_Data_Collection_Team_Refinery_Unit_II_Dumai_Untuk_SOLOMON_Benchmarking_Study_Tahun_2024___2026_PT_KPI.pdf', '1365461', 'application/pdf'),
(222, 64, 'admin', '038___SP_Tim_Task_Force_Safety_Rangers_Sosialisasi_dan_Monitoring_Program_Risk_Assessment_BETUAH_RU_II_PT_KPI_Periode_2024.pdf', '../document/038___SP_Tim_Task_Force_Safety_Rangers_Sosialisasi_dan_Monitoring_Program_Risk_Assessment_BETUAH_RU_II_PT_KPI_Periode_2024.pdf', '1757516', 'application/pdf'),
(223, 64, 'admin', '039___SP_Perubahan_Susunan_Pengurus_Yayasan_Baituzzakah__BAZKA__RU_II_Dumai_PT_KPI_Periode_2024___2025.pdf', '../document/039___SP_Perubahan_Susunan_Pengurus_Yayasan_Baituzzakah__BAZKA__RU_II_Dumai_PT_KPI_Periode_2024___2025.pdf', '989225', 'application/pdf'),
(224, 64, 'admin', '040___SP_Tim_Implementasi_HSSE_Management_System_Refinery_Unit_II_Dumai_PT_Kilang_Pertamina_Internasional.pdf', '../document/040___SP_Tim_Implementasi_HSSE_Management_System_Refinery_Unit_II_Dumai_PT_Kilang_Pertamina_Internasional.pdf', '3670571', 'application/pdf'),
(225, 64, 'admin', '041___SP_Role_Model__Culture_Champion__Culture_Leader__Coordinator_Agent_Of_Change__Dan_Agent_of_Change_General_Manager__RU_II_Dumai_PT_KPI.pdf', '../document/041___SP_Role_Model__Culture_Champion__Culture_Leader__Coordinator_Agent_Of_Change__Dan_Agent_of_Change_General_Manager__RU_II_Dumai_PT_KP', '2535802', 'application/pdf'),
(226, 64, 'admin', '042___SP_Tim_Pembuatan_Dokumen_Pengendalian_Potensi_Bahaya_Besar_RU_II_PT_KPI_Tahun_2024.pdf', '../document/042___SP_Tim_Pembuatan_Dokumen_Pengendalian_Potensi_Bahaya_Besar_RU_II_PT_KPI_Tahun_2024.pdf', '1228985', 'application/pdf'),
(227, 64, 'admin', '043___SP_Susunan_Pengurus_Badan_Dakwah_Islam__BDI__RU_II_Dumai_PT_KPI_Periode_2024___2026.pdf', '../document/043___SP_Susunan_Pengurus_Badan_Dakwah_Islam__BDI__RU_II_Dumai_PT_KPI_Periode_2024___2026.pdf', '1048499', 'application/pdf'),
(228, 69, 'admin', '044___SP_Tim_Task_Force_Cost_Optimization_Tahun_2024_Di_RU_II_PT_KPI.pdf', '../document/044___SP_Tim_Task_Force_Cost_Optimization_Tahun_2024_Di_RU_II_PT_KPI.pdf', '3198487', 'application/pdf'),
(245, 63, 'admin', '044___SP_Tim_Task_Force_Cost_Optimization_Tahun_2024_Di_RU_II_PT_KPI.pdf', '../document/044___SP_Tim_Task_Force_Cost_Optimization_Tahun_2024_Di_RU_II_PT_KPI.pdf', '3045520', 'application/pdf'),
(229, 64, 'admin', '045___SP_Tim_Task_Force_Full_Risk_Survey_Asuransi_Periode_2024_Refinery_Unit_II_PT_Kilang_Pertamina_Internasional.pdf', '../document/045___SP_Tim_Task_Force_Full_Risk_Survey_Asuransi_Periode_2024_Refinery_Unit_II_PT_Kilang_Pertamina_Internasional.pdf', '4289855', 'application/pdf'),
(230, 64, 'admin', '046___SP_Tim_Task_Force_Program_Digitalisasi_Refinery_Unit_II_PT_Kilang_Pertamina_Internasional_Tahun_2024.pdf', '../document/046___SP_Tim_Task_Force_Program_Digitalisasi_Refinery_Unit_II_PT_Kilang_Pertamina_Internasional_Tahun_2024.pdf', '3104976', 'application/pdf'),
(234, 64, 'admin', '048___SP_Pengurus_Badan_Pembina_Olah_raga__BAPOR__Unit_II_Dumai_PT_KPI_Periode_2023_2025.pdf', '../document/048___SP_Pengurus_Badan_Pembina_Olah_raga__BAPOR__Unit_II_Dumai_PT_KPI_Periode_2023_2025.pdf', '1801732', 'application/pdf'),
(235, 64, 'admin', '052___SP_Tim_Kontinuitas_Pelaksanaan_Operator_Training_Simulator__OTS__RU_II_Dumai_PT_KPI.pdf', '../document/052___SP_Tim_Kontinuitas_Pelaksanaan_Operator_Training_Simulator__OTS__RU_II_Dumai_PT_KPI.pdf', '1872957', 'application/pdf'),
(233, 64, 'admin', '050___SP_Tim_Task_Force_Review_Stock_In_Process__SIP__Refinery_Unit_II_Dumai_PT_KPI.pdf', '../document/050___SP_Tim_Task_Force_Review_Stock_In_Process__SIP__Refinery_Unit_II_Dumai_PT_KPI.pdf', '840132', 'application/pdf'),
(236, 64, 'admin', '053___SP_Tim_Subject_Matter_Expert__SME__Peningkatan_Kapabilitas_Organisasi_Dab_Kompetensi_Pekerja_RU_II_PT_KPI.pdf', '../document/053___SP_Tim_Subject_Matter_Expert__SME__Peningkatan_Kapabilitas_Organisasi_Dab_Kompetensi_Pekerja_RU_II_PT_KPI.pdf', '2542749', 'application/pdf'),
(237, 64, 'admin', '054___SP_Tim_Improvement_SupplyDischarge_Loss_RU_II_Dumai_dan_Sei_Pakning_PT_KPI.pdf', '../document/054___SP_Tim_Improvement_SupplyDischarge_Loss_RU_II_Dumai_dan_Sei_Pakning_PT_KPI.pdf', '2034315', 'application/pdf'),
(238, 64, 'admin', '056___SP_Team_Task_Force_Pelaksana_Pekerjaan_Preventive_Maintenance_Order_PT03_Di_Sistem_ERP_MYSAP_RU_II_Dumai_PT_KPI.pdf', '../document/056___SP_Team_Task_Force_Pelaksana_Pekerjaan_Preventive_Maintenance_Order_PT03_Di_Sistem_ERP_MYSAP_RU_II_Dumai_PT_KPI.pdf', '1687117', 'application/pdf'),
(239, 64, 'admin', '058___SK_Petunjuk_Pelaksanaan_Pemberian_Tunjangan_Risiko_Kerja__TRK_.pdf', '../document/058___SK_Petunjuk_Pelaksanaan_Pemberian_Tunjangan_Risiko_Kerja__TRK_.pdf', '8348935', 'application/pdf'),
(240, 64, 'admin', '059___SP_Tim_Pemeriksaan_Fisik_Harta_Benda_Modal__HBM__dan_Persediaan_Material_Non_Hydro_RU_II_PT_KPI.pdf', '../document/059___SP_Tim_Pemeriksaan_Fisik_Harta_Benda_Modal__HBM__dan_Persediaan_Material_Non_Hydro_RU_II_PT_KPI.pdf', '2194849', 'application/pdf'),
(241, 64, 'admin', '061___SP_Tim_Identifikasi_Bahaya__Penilaian_Risiko_dan_Penentuan_Pengendalian__HIRADC__Refinery_Unit_II_PT_Kilang_Pertamina_Internasional_Tahun_2024_2', '../document/061___SP_Tim_Identifikasi_Bahaya__Penilaian_Risiko_dan_Penentuan_Pengendalian__HIRADC__Refinery_Unit_II_PT_Kilang_Pertamina_Internasional_', '1517998', 'application/pdf'),
(242, 64, 'admin', '063___SP_Tim_Penanggung_Jawab_Implementasi_PSPI__Process_Safety_Performance_Indicator__Phase_II_RU_II_Dumai.pdf', '../document/063___SP_Tim_Penanggung_Jawab_Implementasi_PSPI__Process_Safety_Performance_Indicator__Phase_II_RU_II_Dumai.pdf', '2053078', 'application/pdf'),
(287, 64, 'admin', '064___SP_Tim_Pelaksana_Implementasi_Audit_Sistem_Manajemen_Pengamanan__SMP_dan_Security_Risk_Assessment__SRA_.pdf', '../document/064___SP_Tim_Pelaksana_Implementasi_Audit_Sistem_Manajemen_Pengamanan__SMP_dan_Security_Risk_Assessment__SRA_.pdf', '2057729', 'application/pdf'),
(244, 64, 'admin', '066___SP_Panitia_Kegiatan_Annual_Employee_Award_RU_II_Dumai_PT_KPI_Tahun_2024.pdf', '../document/066___SP_Panitia_Kegiatan_Annual_Employee_Award_RU_II_Dumai_PT_KPI_Tahun_2024.pdf', '954495', 'application/pdf'),
(243, 64, 'admin', '067___SP_Tim_Pre_Start_Up_Safety_Review_RU_II_PT_KPI_Tahun_2024_2025.pdf', '../document/067___SP_Tim_Pre_Start_Up_Safety_Review_RU_II_PT_KPI_Tahun_2024_2025.pdf', '2119527', 'application/pdf'),
(246, 64, 'admin', '044___SP_Tim_Task_Force_Cost_Optimization_Tahun_2024_Di_RU_II_PT_KPI.pdf', '../document/044___SP_Tim_Task_Force_Cost_Optimization_Tahun_2024_Di_RU_II_PT_KPI.pdf', '3045520', 'application/pdf'),
(264, 64, 'admin', '072___SP_Tim_Task_Force_Pengelolaan_Produk_Green_Coke_Di_RU_II_PT_KPI.pdf', '../document/072___SP_Tim_Task_Force_Pengelolaan_Produk_Green_Coke_Di_RU_II_PT_KPI.pdf', '1717272', 'application/pdf'),
(247, 19, 'admin', 'RIS___RU_II___FTP_SALTSOV___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___FTP_SALTSOV___GFIM___PT_KPI_2024.pdf', '13451221', 'application/pdf'),
(248, 19, 'admin', 'RIS___RU_II___FTP_WORK_PRO___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___FTP_WORK_PRO___GFIM___PT_KPI_2024.pdf', '6922697', 'application/pdf'),
(249, 18, 'admin', 'RIS___RU_II___PCP_EFPRECOL___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_EFPRECOL___GFIM___PT_KPI_2024.pdf', '10262496', 'application/pdf'),
(250, 18, 'admin', 'RIS___RU_II___PCP_MARKICAB___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_MARKICAB___GFIM___PT_KPI_2024.pdf', '10886186', 'application/pdf'),
(262, 64, 'admin', '074___SP_Tim_Satgas_NATARU.pdf', '../document/074___SP_Tim_Satgas_NATARU.pdf', '906177', 'application/pdf'),
(251, 18, 'admin', 'RIS___RU_II___PCP_MARKSMAN_2.0___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_MARKSMAN_2.0___GFIM___PT_KPI_2024.pdf', '3685097', 'application/pdf'),
(252, 18, 'admin', 'RIS___RU_II___PCP_MIXMAX___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_MIXMAX___GFIM___PT_KPI_2024.pdf', '13748359', 'application/pdf'),
(253, 18, 'admin', 'RIS___RU_II___PCP_P2B_Dumai___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_P2B_Dumai___GFIM___PT_KPI_2024.pdf', '3979357', 'application/pdf'),
(254, 18, 'admin', 'RIS___RU_II___PCP_PROGUARD___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_PROGUARD___GFIM___PT_KPI_2024.pdf', '8640793', 'application/pdf'),
(255, 18, 'admin', 'RIS___RU_II___PCP_PROLITE___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_PROLITE___GFIM___PT_KPI_2024.pdf', '14045898', 'application/pdf'),
(256, 18, 'admin', 'RIS___RU_II___PCP_RETRO___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_RETRO___GFIM___PT_KPI_2024.pdf', '9950942', 'application/pdf'),
(257, 18, 'admin', 'RIS___RU_II___PCP_SEGA___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_SEGA___GFIM___PT_KPI_2024.pdf', '13391369', 'application/pdf'),
(258, 18, 'admin', 'RIS___RU_II___PCP_SUHU___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_SUHU___GFIM___PT_KPI_2024.pdf', '11144601', 'application/pdf'),
(259, 18, 'admin', 'RIS___RU_II___PCP_TANKER_2.0___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_TANKER_2.0___GFIM___PT_KPI_2024.pdf', '6624028', 'application/pdf'),
(260, 18, 'admin', 'RIS___RU_II___PCP_TUBE_MUST___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___PCP_TUBE_MUST___GFIM___PT_KPI_2024.pdf', '11764105', 'application/pdf'),
(261, 18, 'admin', 'RIS___RU_II___RTP_ROCKER_4.0___GFIM___PT_KPI_2024.pdf', '../document/RIS___RU_II___RTP_ROCKER_4.0___GFIM___PT_KPI_2024.pdf', '9519152', 'application/pdf'),
(263, 64, 'admin', '075___SP_Team_Task_Force_Penyusunan_Risk_Register_Tahun_2026.pdf', '../document/075___SP_Team_Task_Force_Penyusunan_Risk_Register_Tahun_2026.pdf', '1275508', 'application/pdf'),
(265, 63, 'admin', '058___SK_Petunjuk_Pelaksanaan_Pemberian_Tunjangan_Risiko_Kerja__TRK_.pdf', '../document/058___SK_Petunjuk_Pelaksanaan_Pemberian_Tunjangan_Risiko_Kerja__TRK_.pdf', '8348935', 'application/pdf'),
(266, 72, 'admin', 'SK_Kompensasi_Kegiatan_4_Pilar_CIP__SM__KOMET_dan_DKE.pdf', '../document/SK_Kompensasi_Kegiatan_4_Pilar_CIP__SM__KOMET_dan_DKE.pdf', '980940', 'application/pdf'),
(267, 70, 'admin', '058___SK_Petunjuk_Pelaksanaan_Pemberian_Tunjangan_Risiko_Kerja__TRK_.pdf', '../document/058___SK_Petunjuk_Pelaksanaan_Pemberian_Tunjangan_Risiko_Kerja__TRK_.pdf', '8348935', 'application/pdf'),
(268, 71, 'admin', '004___SP_Tim_Implementasi_Safety_Leadership_Program__SLP__4.0.pdf', '../document/004___SP_Tim_Implementasi_Safety_Leadership_Program__SLP__4.0.pdf', '1421567', 'application/pdf'),
(269, 71, 'admin', '006___SP_Panitia_Pencegahan_Dan_Penanggulangan_HIV_AIDS_Ditempat_Kerja.pdf', '../document/006___SP_Panitia_Pencegahan_Dan_Penanggulangan_HIV_AIDS_Ditempat_Kerja.pdf', '981373', 'application/pdf'),
(270, 71, 'admin', '008___SP_Panitia_Bulan_Keselamatan_Dan_Kesehatan_Kerja__K3__Tahun_2025.pdf', '../document/008___SP_Panitia_Bulan_Keselamatan_Dan_Kesehatan_Kerja__K3__Tahun_2025.pdf', '2329168', 'application/pdf'),
(271, 71, 'admin', '009___SP_Struktur_Organisasi_Tim_Task_Force_Eksekusi_TA_Mayor_2025_RU_II_Dumai_PT_KPI.pdf', '../document/009___SP_Struktur_Organisasi_Tim_Task_Force_Eksekusi_TA_Mayor_2025_RU_II_Dumai_PT_KPI.pdf', '4201210', 'application/pdf'),
(272, 71, 'admin', '014___SP_Tim_Pengelola_Knowledge_Management__KOMET__RU_II_PT_KPI_Tahun_2025.pdf', '../document/014___SP_Tim_Pengelola_Knowledge_Management__KOMET__RU_II_PT_KPI_Tahun_2025.pdf', '1867864', 'application/pdf'),
(273, 71, 'admin', '015___SP_Tim_Task_Force_Program_Digitalisasi_RU_II_PT_KPI_Tahun_2025.pdf', '../document/015___SP_Tim_Task_Force_Program_Digitalisasi_RU_II_PT_KPI_Tahun_2025.pdf', '1482189', 'application/pdf'),
(274, 71, 'admin', '016___SP_Dewan_Mutu_Dan_Produktivitas_RU_II_PT_KPI_Tahun_2025.pdf', '../document/016___SP_Dewan_Mutu_Dan_Produktivitas_RU_II_PT_KPI_Tahun_2025.pdf', '1694505', 'application/pdf'),
(275, 71, 'admin', '017___SP_Tim_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_Dan_Produk__Intermedia__BBM__NBBM__Di_Tangki_Dan_Green_Coke_Di_Yard_I___II_Periode_Triwulan_I_', '../document/017___SP_Tim_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_Dan_Produk__Intermedia__BBM__NBBM__Di_Tangki_Dan_Green_Coke_Di_Yard_I___II_Periode', '1636923', 'application/pdf'),
(283, 71, 'admin', '032___SP_Pengelolaan_Lingkungan_Terpadu.pdf', '../document/032___SP_Pengelolaan_Lingkungan_Terpadu.pdf', '1896428', 'application/pdf'),
(276, 71, 'admin', '020___SP_Tim_Penyususn_Business_Continuity_Plan__BCP__Dan_Business_Continuity_Management_System__BCMS__RU_II_Dumai_PT_KPI.pdf', '../document/020___SP_Tim_Penyususn_Business_Continuity_Plan__BCP__Dan_Business_Continuity_Management_System__BCMS__RU_II_Dumai_PT_KPI.pdf', '1644187', 'application/pdf'),
(277, 71, 'admin', '022___SP_Pengurus_Badan_Pembina_Olah_Raga__BAPOR__RU_II_PT_KPI_Periode_2025.pdf', '../document/022___SP_Pengurus_Badan_Pembina_Olah_Raga__BAPOR__RU_II_PT_KPI_Periode_2025.pdf', '2812178', 'application/pdf'),
(310, 71, 'admin', '062___SP_Tim_Task_Force_Follow_Up_Risk_Survey_Asuransi_Periode_2025_RU_II_Dumai_PT_KPI.pdf', '../document/062___SP_Tim_Task_Force_Follow_Up_Risk_Survey_Asuransi_Periode_2025_RU_II_Dumai_PT_KPI.pdf', '2049584', 'application/pdf'),
(284, 71, 'admin', '024___SP_Tim_Audit_Sistem_Tata_Kerja_Pertamina_RU_II_PT_KPI_Tahun_2025.pdf', '../document/024___SP_Tim_Audit_Sistem_Tata_Kerja_Pertamina_RU_II_PT_KPI_Tahun_2025.pdf', '945957', 'application/pdf'),
(278, 71, 'admin', '026___SP_Tim_Juri_Audit_Klinik_Dan_PIC_CIP_Fungsi_Bagian_RU_II_PT_KPI.pdf', '../document/026___SP_Tim_Juri_Audit_Klinik_Dan_PIC_CIP_Fungsi_Bagian_RU_II_PT_KPI.pdf', '1789758', 'application/pdf'),
(279, 71, 'admin', '027___SP_Tim_Implementasi_Sistem_Manajemen_Pengamanan_Tahun_2025_RU_II_Production_Spk_PT_KPI.pdf', '../document/027___SP_Tim_Implementasi_Sistem_Manajemen_Pengamanan_Tahun_2025_RU_II_Production_Spk_PT_KPI.pdf', '1255317', 'application/pdf'),
(281, 71, 'admin', '029___SP_Tim_Satuan_Tugas__SATGAS__Ramadhan_Dan_Idul_Fitri_2025__RAFI__RU_II_PT_KPI.pdf', '../document/029___SP_Tim_Satuan_Tugas__SATGAS__Ramadhan_Dan_Idul_Fitri_2025__RAFI__RU_II_PT_KPI.pdf', '1107812', 'application/pdf'),
(280, 71, 'admin', '028___SP_Tim_Quality__Health__Safety__Security___Environment__QHSSE__Committee_RU_II_PT_KPI.pdf', '../document/028___SP_Tim_Quality__Health__Safety__Security___Environment__QHSSE__Committee_RU_II_PT_KPI.pdf', '804709', 'application/pdf'),
(282, 71, 'admin', '033___SP_Tim_Bantuan_Keadaan_Darurat__TBKD__RU_II_Prod_Spk_Tahun_2025_2026_PT_KPI.pdf', '../document/033___SP_Tim_Bantuan_Keadaan_Darurat__TBKD__RU_II_Prod_Spk_Tahun_2025_2026_PT_KPI.pdf', '934972', 'application/pdf'),
(285, 71, 'admin', '035___SP_Tim_Implementasi_Pengelolaan_Sistem_tata_Kerja__STK__RU_II_PT_KPI.pdf', '../document/035___SP_Tim_Implementasi_Pengelolaan_Sistem_tata_Kerja__STK__RU_II_PT_KPI.pdf', '1475348', 'application/pdf'),
(286, 71, 'admin', '036___SP_Tim_Penyusun_Dokumen_Kinerja_Ekselen__DKE__RU_II_PT_KPI.pdf', '../document/036___SP_Tim_Penyusun_Dokumen_Kinerja_Ekselen__DKE__RU_II_PT_KPI.pdf', '1394096', 'application/pdf'),
(288, 71, 'admin', '038___SP_Tim_Pelaksana_Hearing_Conservation_Program_Di_RU_II_Dumai_PT_KPI_Tahun_2025___2026.pdf', '../document/038___SP_Tim_Pelaksana_Hearing_Conservation_Program_Di_RU_II_Dumai_PT_KPI_Tahun_2025___2026.pdf', '1141134', 'application/pdf'),
(289, 71, 'admin', '041___SP_Tim_Pelaksana_Pertolongan_Pertama_Pada_Kecelakaan__First_Aider__RU_Unit_II_PT_KPI_Tahun_2025.pdf', '../document/041___SP_Tim_Pelaksana_Pertolongan_Pertama_Pada_Kecelakaan__First_Aider__RU_Unit_II_PT_KPI_Tahun_2025.pdf', '2649136', 'application/pdf'),
(290, 71, 'admin', '042___Team_Task_Force_Focus_Group_Discussion_Critical_Job_TA_Mayor_Tahun_2025_RU_II_PT_KPI.pdf', '../document/042___Team_Task_Force_Focus_Group_Discussion_Critical_Job_TA_Mayor_Tahun_2025_RU_II_PT_KPI.pdf', '4080755', 'application/pdf'),
(320, 71, 'admin', '044___SP_Tim_Bantuan_Penanggulangan_Keadaan_darurat_RU_II_Dumai_PT_KPI_Periode_Tahun_2025.pdf', '../document/044___SP_Tim_Bantuan_Penanggulangan_Keadaan_darurat_RU_II_Dumai_PT_KPI_Periode_Tahun_2025.pdf', '1058457', 'application/pdf'),
(291, 71, 'admin', '048___SP_Tim_Penerapan_Dan_Sertifikasi_ISO_370012016_SMAP_RU_II_PT_KPI.pdf', '../document/048___SP_Tim_Penerapan_Dan_Sertifikasi_ISO_370012016_SMAP_RU_II_PT_KPI.pdf', '1744070', 'application/pdf'),
(292, 71, 'admin', '049___SP_Tim_Pelaksana_Internal_Audit_ISO_Series_dan_RTM_RU_II_PT_KPI.pdf', '../document/049___SP_Tim_Pelaksana_Internal_Audit_ISO_Series_dan_RTM_RU_II_PT_KPI.pdf', '1447266', 'application/pdf'),
(293, 71, 'admin', '050___SP_Tim_Implementasi_Safety_Leadership_Program__SLP__4.0_Berbasis_CLSR_PT_Kilang_Pertamina_Internasional_Zona_Sumatrera___Dumai.pdf', '../document/050___SP_Tim_Implementasi_Safety_Leadership_Program__SLP__4.0_Berbasis_CLSR_PT_Kilang_Pertamina_Internasional_Zona_Sumatrera___Dumai.pdf', '1651726', 'application/pdf'),
(294, 71, 'admin', '053___SP_Tim_Penyusun_Front_End_Engineering_Design_Flare_Gas_To_Power.pdf', '../document/053___SP_Tim_Penyusun_Front_End_Engineering_Design_Flare_Gas_To_Power.pdf', '893574', 'application/pdf');
INSERT INTO `tb_upload` (`upload_id`, `menu_id`, `creator`, `file_name`, `file_dir`, `size`, `type`) VALUES
(317, 0, 'admin', '054___SP_Tim_Pelaksana_Implementasi_Audit_Sistem_Manajemen_Pengamanan__SMP__Dan_Security_Risk_Assessment__SRA__RU_II_Tahun_2025_PT_KPI.pdf', '../document/054___SP_Tim_Pelaksana_Implementasi_Audit_Sistem_Manajemen_Pengamanan__SMP__Dan_Security_Risk_Assessment__SRA__RU_II_Tahun_2025_PT_KPI.pdf', '1705881', 'application/pdf'),
(304, 26, 'putriafrisya', '2024_Copy_Cert_9001_Kilang_Pertamina_Internasional_KAN.pdf', '../document/2024_Copy_Cert_9001_Kilang_Pertamina_Internasional_KAN.pdf', '4090686', 'application/pdf'),
(295, 19, 'putriafrisya', 'RIS___RU_II___FTP_WORK_PRO___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___FTP_WORK_PRO___PT_KPI___APQA_2025.pdf', '14035717', 'application/pdf'),
(296, 18, 'putriafrisya', 'RIS___RU_II___PCP_MIXMAX___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___PCP_MIXMAX___PT_KPI___APQA_2025.pdf', '14972845', 'application/pdf'),
(297, 18, 'putriafrisya', 'RIS___RU_II___PCP_P2B_DUMAI___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___PCP_P2B_DUMAI___PT_KPI___APQA_2025.pdf', '5381681', 'application/pdf'),
(298, 18, 'putriafrisya', 'RIS___RU_II___PCP_PRO_GUARD___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___PCP_PRO_GUARD___PT_KPI___APQA_2025.pdf', '10679440', 'application/pdf'),
(299, 18, 'putriafrisya', 'RIS___RU_II___PCP_PROLITE___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___PCP_PROLITE___PT_KPI___APQA_2025.pdf', '15916970', 'application/pdf'),
(300, 18, 'putriafrisya', 'RIS___RU_II___PCP_RETRO___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___PCP_RETRO___PT_KPI___APQA_2025.pdf', '9950009', 'application/pdf'),
(301, 18, 'putriafrisya', 'RIS___RU_II___PCP_SEGA___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___PCP_SEGA___PT_KPI___APQA_2025.pdf', '13897054', 'application/pdf'),
(302, 18, 'putriafrisya', 'RIS___RU_II___PCP_TUBE_MUST___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___PCP_TUBE_MUST___PT_KPI___APQA_2025.pdf', '13027263', 'application/pdf'),
(303, 18, 'putriafrisya', 'RIS___RU_II___RTP_ROCKER_4.0___PT_KPI___APQA_2025.pdf', '../document/RIS___RU_II___RTP_ROCKER_4.0___PT_KPI___APQA_2025.pdf', '12431136', 'application/pdf'),
(305, 27, 'putriafrisya', '2024_Copy_Cert_14001_Kilang_Pertamina_Internasional_KAN.pdf', '../document/2024_Copy_Cert_14001_Kilang_Pertamina_Internasional_KAN.pdf', '4087280', 'application/pdf'),
(306, 28, 'putriafrisya', '2024_Copy_Cert_45001_Kilang_Pertamina_Internasional_KAN.pdf', '../document/2024_Copy_Cert_45001_Kilang_Pertamina_Internasional_KAN.pdf', '3950986', 'application/pdf'),
(307, 25, 'putriafrisya', 'KEBIJAKAN_MUTU_RU_II_2025.pdf', '../document/KEBIJAKAN_MUTU_RU_II_2025.pdf', '788167', 'application/pdf'),
(308, 64, 'admin', '055___SP_Tim_Task_Force_Penyehatan_Open_Sewer_Dan_Closed_Sewer_Eksisting_RU_II_Dumai_PT_KPI_Tahun_2025.pdf', '../document/055___SP_Tim_Task_Force_Penyehatan_Open_Sewer_Dan_Closed_Sewer_Eksisting_RU_II_Dumai_PT_KPI_Tahun_2025.pdf', '1516854', 'application/pdf'),
(309, 71, 'admin', '055___SP_Tim_Task_Force_Penyehatan_Open_Sewer_Dan_Closed_Sewer_Eksisting_RU_II_Dumai_PT_KPI_Tahun_2025.pdf', '../document/055___SP_Tim_Task_Force_Penyehatan_Open_Sewer_Dan_Closed_Sewer_Eksisting_RU_II_Dumai_PT_KPI_Tahun_2025.pdf', '1516854', 'application/pdf'),
(311, 71, 'admin', '066___SP_Tim_Task_Force_Pengolahan_Used_Cooking__UCO__Menjadi_Sustainable_Aviation_Fuel__SAF_.pdf', '../document/066___SP_Tim_Task_Force_Pengolahan_Used_Cooking__UCO__Menjadi_Sustainable_Aviation_Fuel__SAF_.pdf', '1502090', 'application/pdf'),
(312, 64, 'admin', '069___SP_Tim_Pelaksana_Team_Focus_Group_Discussion_RKAP_2025_PT_Kilang_Pertamina_Internasional.pdf', '../document/069___SP_Tim_Pelaksana_Team_Focus_Group_Discussion_RKAP_2025_PT_Kilang_Pertamina_Internasional.pdf', '1222363', 'application/pdf'),
(313, 71, 'admin', '069___SP_Tim_Pelaksana_Team_Focus_Group_Discussion_RKAP_2025_PT_Kilang_Pertamina_Internasional.pdf', '../document/069___SP_Tim_Pelaksana_Team_Focus_Group_Discussion_RKAP_2025_PT_Kilang_Pertamina_Internasional.pdf', '1222363', 'application/pdf'),
(314, 71, 'admin', '073___SP_Susunan_Pengurus_Badan_Dakwah_Islam__BDI__RU_II_Dumai_PT_KPI_Periode_2025_2027.pdf', '../document/073___SP_Susunan_Pengurus_Badan_Dakwah_Islam__BDI__RU_II_Dumai_PT_KPI_Periode_2025_2027.pdf', '991578', 'application/pdf'),
(315, 71, 'admin', '075___SP_Tim_Implementasi_HSSE_Management_System_Refinery_Unit_II_PT_Kilang_Pertamina_Internasional.pdf', '../document/075___SP_Tim_Implementasi_HSSE_Management_System_Refinery_Unit_II_PT_Kilang_Pertamina_Internasional.pdf', '3713191', 'application/pdf'),
(316, 71, 'admin', '088___SP_Tim_Task_Force_Penyehatan_Cooling_Water_System_RU_II_Dumai_PT_KPI_Tahu_2025.pdf', '../document/088___SP_Tim_Task_Force_Penyehatan_Cooling_Water_System_RU_II_Dumai_PT_KPI_Tahu_2025.pdf', '918635', 'application/pdf'),
(318, 71, 'admin', '054___SP_Tim_Pelaksana_Implementasi_Audit_Sistem_Manajemen_Pengamanan__SMP__Dan_Security_Risk_Assessment__SRA__RU_II_Tahun_2025_PT_KPI.pdf', '../document/054___SP_Tim_Pelaksana_Implementasi_Audit_Sistem_Manajemen_Pengamanan__SMP__Dan_Security_Risk_Assessment__SRA__RU_II_Tahun_2025_PT_KPI.pdf', '1536917', 'application/pdf'),
(319, 71, 'admin', '089___SP_Tim_Bantuan_Penanggulangan_Keadaan_darurat__TBKD__Area_RDP_Bukit_Datuk_RU_II_Dumai_PT_KPI_Tahun_2025.pdf', '../document/089___SP_Tim_Bantuan_Penanggulangan_Keadaan_darurat__TBKD__Area_RDP_Bukit_Datuk_RU_II_Dumai_PT_KPI_Tahun_2025.pdf', '1242958', 'application/pdf'),
(321, 71, 'admin', '091___SP_Tim_Task_Force_Inspeksi_Material_Stock_On_Hand_TA_Mayor_RU_II_2026.pdf', '../document/091___SP_Tim_Task_Force_Inspeksi_Material_Stock_On_Hand_TA_Mayor_RU_II_2026.pdf', '1323793', 'application/pdf'),
(322, 71, 'admin', '092___SP_Tim_Pelaksana_Pengelolaan_Lingkungan_Tahun_2025_RU_II_Production_Spk_PT_KPI.pdf', '../document/092___SP_Tim_Pelaksana_Pengelolaan_Lingkungan_Tahun_2025_RU_II_Production_Spk_PT_KPI.pdf', '3512042', 'application/pdf'),
(323, 71, 'admin', '093___SP_Tim_Pemeriksaan_Fisik_Harta_Benda_Modal__HBM__Dan_Persediaan_Material_Non_Hydro_RU_II_PT_KPI_Tahun_2025.pdf', '../document/093___SP_Tim_Pemeriksaan_Fisik_Harta_Benda_Modal__HBM__Dan_Persediaan_Material_Non_Hydro_RU_II_PT_KPI_Tahun_2025.pdf', '1987253', 'application/pdf'),
(324, 71, 'admin', '110___SP_Tim_Tender_Pengadaan_Barang_Jasa_RU_II_PT_KPI.pdf', '../document/110___SP_Tim_Tender_Pengadaan_Barang_Jasa_RU_II_PT_KPI.pdf', '1590392', 'application/pdf'),
(325, 72, 'admin', '111___SK_Ketentuan_Dan_tarif_Pemakaian_Fasilitas_Perusahaan.pdf', '../document/111___SK_Ketentuan_Dan_tarif_Pemakaian_Fasilitas_Perusahaan.pdf', '1554320', 'application/pdf'),
(326, 64, 'admin', '112___SP_Tim_Identifikasi_Bahaya__Penilaian_Risiko_Dan_Penentuan_Pengendalian__HIRADC__RU_II_PT_KPI_Tahun_2025.pdf', '../document/112___SP_Tim_Identifikasi_Bahaya__Penilaian_Risiko_Dan_Penentuan_Pengendalian__HIRADC__RU_II_PT_KPI_Tahun_2025.pdf', '1629356', 'application/pdf'),
(327, 71, 'admin', '112___SP_Tim_Identifikasi_Bahaya__Penilaian_Risiko_Dan_Penentuan_Pengendalian__HIRADC__RU_II_PT_KPI_Tahun_2025.pdf', '../document/112___SP_Tim_Identifikasi_Bahaya__Penilaian_Risiko_Dan_Penentuan_Pengendalian__HIRADC__RU_II_PT_KPI_Tahun_2025.pdf', '1629356', 'application/pdf'),
(328, 71, 'admin', '115___SP_Tim_Task_Force_Pengukuran_Stock_Inventory_Green_Coke_Bulanan_Menggunakan_Alat_3D_Laser_Scanner_Tahun_2026_RU_II_PT_KPI.pdf', '../document/115___SP_Tim_Task_Force_Pengukuran_Stock_Inventory_Green_Coke_Bulanan_Menggunakan_Alat_3D_Laser_Scanner_Tahun_2026_RU_II_PT_KPI.pdf', '1043785', 'application/pdf'),
(331, 71, 'admin', '119___SP_Tim_Task_Force_Expediting_Material_Utama_Kebutuhan_TA_Mayor_Ru_II_PT_KPI_Tahun_2026.pdf', '../document/119___SP_Tim_Task_Force_Expediting_Material_Utama_Kebutuhan_TA_Mayor_Ru_II_PT_KPI_Tahun_2026.pdf', '1790812', 'application/pdf'),
(329, 71, 'admin', '130___SP_Task_Force_Cost_Optimization_Tahun_2025_Di_RU_II_PT_KPI.pdf', '../document/130___SP_Task_Force_Cost_Optimization_Tahun_2025_Di_RU_II_PT_KPI.pdf', '2990559', 'application/pdf'),
(330, 71, 'admin', '132___SP_Tim_Sosialisasi_Pemenuhan_Peraturan_Dan_Pengisian_I_RECOMS_RU_II_PT_KPI.pdf', '../document/132___SP_Tim_Sosialisasi_Pemenuhan_Peraturan_Dan_Pengisian_I_RECOMS_RU_II_PT_KPI.pdf', '1083393', 'application/pdf'),
(332, 71, 'admin', '138___SP_Management_Representatif_Sistem_Manajemen_Pengamanan__SMP__RU_II_PT_KPI.pdf', '../document/138___SP_Management_Representatif_Sistem_Manajemen_Pengamanan__SMP__RU_II_PT_KPI.pdf', '414830', 'application/pdf'),
(333, 64, 'admin', '139___SP_Petugas_Proteksi_Radioaktif__PPR__dan_Petugas_Keamanan_Sumber_Radioaktif__PKSR__Tahun_2025.pdf', '../document/139___SP_Petugas_Proteksi_Radioaktif__PPR__dan_Petugas_Keamanan_Sumber_Radioaktif__PKSR__Tahun_2025.pdf', '1575471', 'application/pdf'),
(334, 71, 'admin', '139___SP_Petugas_Proteksi_Radioaktif__PPR__dan_Petugas_Keamanan_Sumber_Radioaktif__PKSR__Tahun_2025.pdf', '../document/139___SP_Petugas_Proteksi_Radioaktif__PPR__dan_Petugas_Keamanan_Sumber_Radioaktif__PKSR__Tahun_2025.pdf', '1575471', 'application/pdf'),
(335, 71, 'admin', '141___SP_Tim_Task_Force_Aktifitas_Emergency_Recovery_110_H_1_RU_II_PT_KPI.pdf', '../document/141___SP_Tim_Task_Force_Aktifitas_Emergency_Recovery_110_H_1_RU_II_PT_KPI.pdf', '2928728', 'application/pdf'),
(336, 71, 'admin', '142___SP_Tim_Task_Force_Aktifitas_Emergency_Recovery_212_H_1_RU_II_PT_KPI.pdf', '../document/142___SP_Tim_Task_Force_Aktifitas_Emergency_Recovery_212_H_1_RU_II_PT_KPI.pdf', '2895672', 'application/pdf'),
(337, 71, 'admin', '149___SP_Team_Task_Force_Penyusunan_Risk_Register_Tahun_2027_RU_II_PT_KPI.pdf', '../document/149___SP_Team_Task_Force_Penyusunan_Risk_Register_Tahun_2027_RU_II_PT_KPI.pdf', '1260619', 'application/pdf'),
(338, 71, 'admin', '150___SP_Tim_Penanggung_Jawab_Implementasi_PSPI__Process_Safety_Performance_Indicator__Phase_III_RU_II_PT_KPI.pdf', '../document/150___SP_Tim_Penanggung_Jawab_Implementasi_PSPI__Process_Safety_Performance_Indicator__Phase_III_RU_II_PT_KPI.pdf', '2663929', 'application/pdf'),
(339, 71, 'admin', '156___SP_Tim_Task_Force_Follow_Up_Survey_Asuransi_Periode_2025___2026_RU_II_Production_S_Pakning_PT_KPI.pdf', '../document/156___SP_Tim_Task_Force_Follow_Up_Survey_Asuransi_Periode_2025___2026_RU_II_Production_S_Pakning_PT_KPI.pdf', '1238036', 'application/pdf'),
(340, 71, 'admin', '158___SP_Tim_Task_Force_Pengelolaan_Scrap_Dan_Limbah_Kemasan_B3_Di_RU_II_Dumai___Sei_Pakning_PT_KPI.pdf', '../document/158___SP_Tim_Task_Force_Pengelolaan_Scrap_Dan_Limbah_Kemasan_B3_Di_RU_II_Dumai___Sei_Pakning_PT_KPI.pdf', '1425513', 'application/pdf'),
(341, 71, 'admin', '159___SP_Tim_ISPS_Code_Fasilitas_Pelabuhan_Terminal_Untuk_Kepentingan_Sendiri__TUKS__RU_II_Dumai_PT_KPI.pdf', '../document/159___SP_Tim_ISPS_Code_Fasilitas_Pelabuhan_Terminal_Untuk_Kepentingan_Sendiri__TUKS__RU_II_Dumai_PT_KPI.pdf', '1722402', 'application/pdf'),
(342, 71, 'admin', '161___SP_Tim_ISPS_Code_Fasilitas_Pelabuhan_Terminal_Untuk_Kepentingan_Sendiri__TUKS__RU_II_Production_S_Pakning_PT_KPI.pdf', '../document/161___SP_Tim_ISPS_Code_Fasilitas_Pelabuhan_Terminal_Untuk_Kepentingan_Sendiri__TUKS__RU_II_Production_S_Pakning_PT_KPI.pdf', '1783524', 'application/pdf'),
(343, 73, 'admin', '001___SP_TBKD_RU_II_PT_KPI_Periode_2026_2027.pdf', '../document/001___SP_TBKD_RU_II_PT_KPI_Periode_2026_2027.pdf', '1534727', 'application/pdf'),
(344, 73, 'admin', '003___SP_Tim_Task_Force_Penyehatan_Open_Sewer_Dan_Closed_Sewer_RU_II_Dumai_PT_KPI_Tahun_2026.pdf', '../document/003___SP_Tim_Task_Force_Penyehatan_Open_Sewer_Dan_Closed_Sewer_RU_II_Dumai_PT_KPI_Tahun_2026.pdf', '3160636', 'application/pdf'),
(345, 73, 'admin', '004___SP_Tim_Analisa_Bahaya_Proses__ABP__RU_II_PT_KPI.pdf', '../document/004___SP_Tim_Analisa_Bahaya_Proses__ABP__RU_II_PT_KPI.pdf', '4483309', 'application/pdf'),
(346, 73, 'admin', '005___SP_Bulan_Keselamatan_Dan_Kesehatan_Kerja__K3__Tahun_2026_RU_II_PT_KPI.pdf', '../document/005___SP_Bulan_Keselamatan_Dan_Kesehatan_Kerja__K3__Tahun_2026_RU_II_PT_KPI.pdf', '6648674', 'application/pdf'),
(347, 71, 'admin', '008___SK_Pengadaan_Dan_Pembagian_Pakaian_Dinas_RU_II.pdf', '../document/008___SK_Pengadaan_Dan_Pembagian_Pakaian_Dinas_RU_II.pdf', '2773404', 'application/pdf'),
(348, 74, 'admin', '008___SK_Pengadaan_Dan_Pembagian_Pakaian_Dinas_RU_II.pdf', '../document/008___SK_Pengadaan_Dan_Pembagian_Pakaian_Dinas_RU_II.pdf', '2773404', 'application/pdf'),
(349, 73, 'admin', '009___SP_Tim_Pre_Start_Up_Safety_Review_RU_II_PT_KPI_Tahun_2026_2027.pdf', '../document/009___SP_Tim_Pre_Start_Up_Safety_Review_RU_II_PT_KPI_Tahun_2026_2027.pdf', '6056575', 'application/pdf'),
(350, 73, 'admin', '010___SP_Role_Model__Culture_Champion__Leader__Coordinator__Promotor___Agent_Of_Change_RU_II_PT_KPI.pdf', '../document/010___SP_Role_Model__Culture_Champion__Leader__Coordinator__Promotor___Agent_Of_Change_RU_II_PT_KPI.pdf', '9713819', 'application/pdf'),
(351, 18, 'admin', 'RIS___PC_FLIGHT_CODE___GF___RU_II___2025.pdf', '../document/RIS___PC_FLIGHT_CODE___GF___RU_II___2025.pdf', '6543598', 'application/pdf'),
(352, 18, 'admin', 'RIS___PCP_0SLO___GF___RU_II___2025.pdf', '../document/RIS___PCP_0SLO___GF___RU_II___2025.pdf', '20807471', 'application/pdf'),
(353, 18, 'admin', 'RIS___PCP_3D_OLOGIC___GF___RU_II___2025.pdf', '../document/RIS___PCP_3D_OLOGIC___GF___RU_II___2025.pdf', '6975363', 'application/pdf'),
(354, 18, 'admin', 'RIS___PCP_BLAST___GF___RU_II__2025_.pdf', '../document/RIS___PCP_BLAST___GF___RU_II__2025_.pdf', '4079903', 'application/pdf'),
(355, 18, 'admin', 'RIS___PCP_BLAST___GF___RU_II__2025_.pdf', '../document/RIS___PCP_BLAST___GF___RU_II__2025_.pdf', '4079903', 'application/pdf'),
(356, 18, 'admin', 'RIS___PCP_CAKRA___RU_II___2025.pdf', '../document/RIS___PCP_CAKRA___RU_II___2025.pdf', '6573819', 'application/pdf'),
(357, 18, 'admin', 'RIS___PCP_CAKRA___RU_II___2025.pdf', '../document/RIS___PCP_CAKRA___RU_II___2025.pdf', '6573819', 'application/pdf'),
(358, 18, 'admin', 'RIS___PCP_CECEPUH___GF___RU_II___2025.pdf', '../document/RIS___PCP_CECEPUH___GF___RU_II___2025.pdf', '4053438', 'application/pdf'),
(359, 18, 'admin', 'RIS___PCP_CUAN___GF___RU_II___2025.pdf', '../document/RIS___PCP_CUAN___GF___RU_II___2025.pdf', '5297108', 'application/pdf'),
(360, 18, 'admin', 'RIS___PCP_D_AMINE_BEDELAU_1.0___GF___RU_II___2025.pdf', '../document/RIS___PCP_D_AMINE_BEDELAU_1.0___GF___RU_II___2025.pdf', '7215867', 'application/pdf'),
(361, 18, 'admin', 'RIS___PCP_EXPATRIAT___GF___RU_II___2025.pdf', '../document/RIS___PCP_EXPATRIAT___GF___RU_II___2025.pdf', '12019565', 'application/pdf'),
(362, 18, 'admin', 'RIS___PCP_GASING___GF___RU_II___2025.pdf', '../document/RIS___PCP_GASING___GF___RU_II___2025.pdf', '10884101', 'application/pdf'),
(363, 18, 'admin', 'RIS___PCP_GASING___GF___RU_II___2025.pdf', '../document/RIS___PCP_GASING___GF___RU_II___2025.pdf', '10884101', 'application/pdf'),
(364, 18, 'admin', 'RIS___PCP_HOC____GF___RU_II___2025.pdf', '../document/RIS___PCP_HOC____GF___RU_II___2025.pdf', '64274647', 'application/pdf'),
(365, 18, 'admin', 'RIS___PCP_JALANI_AJA_DULU___GF___RU_II___2025.pdf', '../document/RIS___PCP_JALANI_AJA_DULU___GF___RU_II___2025.pdf', '71769445', 'application/pdf'),
(366, 18, 'admin', 'RIS___PCP_MANTEN___GF___RU_II___2025.pdf', '../document/RIS___PCP_MANTEN___GF___RU_II___2025.pdf', '10942589', 'application/pdf'),
(367, 73, 'admin', '016___SP_Tim_TF_Pengelolaan_Lingkungan_Terpadu_RU_II_Dumai.pdf', '../document/016___SP_Tim_TF_Pengelolaan_Lingkungan_Terpadu_RU_II_Dumai.pdf', '5691769', 'application/pdf'),
(368, 73, 'admin', '017___SP_Tim_Task_Force_Reinforcement_Process_Safety___Asset_Integrity_Management_System.pdf', '../document/017___SP_Tim_Task_Force_Reinforcement_Process_Safety___Asset_Integrity_Management_System.pdf', '9170770', 'application/pdf'),
(369, 73, 'admin', '019___SP_Tim_Juri_Audit_Klinik_dan_PIC_CIP_Fungsi_Bagian_RU_II_PT_PPN.pdf', '../document/019___SP_Tim_Juri_Audit_Klinik_dan_PIC_CIP_Fungsi_Bagian_RU_II_PT_PPN.pdf', '5459365', 'application/pdf'),
(370, 73, 'admin', '020___SP_Tim_Investigasi_Kebakaran_Rumah_Dinas_Perusahaan.pdf', '../document/020___SP_Tim_Investigasi_Kebakaran_Rumah_Dinas_Perusahaan.pdf', '2842713', 'application/pdf'),
(371, 73, 'admin', '021___SP_Tim_Sertifikasi_Internal_Control_Over_Finance_Reporting__ICOFR_.pdf', '../document/021___SP_Tim_Sertifikasi_Internal_Control_Over_Finance_Reporting__ICOFR_.pdf', '3476758', 'application/pdf'),
(372, 73, 'admin', '023___SP_Tim_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_Dan_Produk.pdf', '../document/023___SP_Tim_Pemeriksaan_Fisik_Persediaan_Minyak_Mentah_Dan_Produk.pdf', '3853188', 'application/pdf'),
(373, 73, 'admin', '024___SP_Tim_Task_Force_Review_Stock_In_Process__SIP__RU_II_Sei_Pakning_PT_PPN.pdf', '../document/024___SP_Tim_Task_Force_Review_Stock_In_Process__SIP__RU_II_Sei_Pakning_PT_PPN.pdf', '2575458', 'application/pdf'),
(374, 73, 'admin', '025___SP_Tim_Implementasi_Pengelolaan_Sistem_Tata_Kerja__STK__RU_II_PT_PPN.pdf', '../document/025___SP_Tim_Implementasi_Pengelolaan_Sistem_Tata_Kerja__STK__RU_II_PT_PPN.pdf', '4544022', 'application/pdf'),
(379, 73, 'admin', '026___SP_Tim_Task_Force_Full_Risk_Survey_Asuransi_PT_PPN_RU_II_Dumai.pdf', '../document/026___SP_Tim_Task_Force_Full_Risk_Survey_Asuransi_PT_PPN_RU_II_Dumai.pdf', '5654849', 'application/pdf'),
(375, 73, 'admin', '027___Dewan_Mutu_Dan_Produktivitas_RU_II_PT_Pertamina_Patra_Niaga_Tahun_2026.pdf', '../document/027___Dewan_Mutu_Dan_Produktivitas_RU_II_PT_Pertamina_Patra_Niaga_Tahun_2026.pdf', '5001227', 'application/pdf'),
(376, 73, 'admin', '028___Tim_Penyusun_Dokumen_Kinerja_Ekselen__DKE__RU_II_PT_Pertamina_Patra_Niaga.pdf', '../document/028___Tim_Penyusun_Dokumen_Kinerja_Ekselen__DKE__RU_II_PT_Pertamina_Patra_Niaga.pdf', '3994686', 'application/pdf'),
(377, 73, 'admin', '031___SP_Tim_SATGAS_RAFI_PT_PPN_RU_II_2026.pdf', '../document/031___SP_Tim_SATGAS_RAFI_PT_PPN_RU_II_2026.pdf', '5276829', 'application/pdf'),
(378, 73, 'admin', '033___SP_Tim_Penerapan_Dan_Sertifikasi_ISO_370012016___SMAP__PT_PPN_RU_II.pdf', '../document/033___SP_Tim_Penerapan_Dan_Sertifikasi_ISO_370012016___SMAP__PT_PPN_RU_II.pdf', '5106692', 'application/pdf'),
(382, 73, 'admin', '036___SP_Tim_Pelaksana_ISO_Series_dan_Rapat_Tinjauan_Manajemen_PT_PPN_RU_II.pdf', '../document/036___SP_Tim_Pelaksana_ISO_Series_dan_Rapat_Tinjauan_Manajemen_PT_PPN_RU_II.pdf', '4520478', 'application/pdf'),
(383, 73, 'admin', '037___SP_Tim_Audit_Sistem_Tata_Kerja_Pertamina_RU_II_PT_PPN_Tahun_2026.pdf', '../document/037___SP_Tim_Audit_Sistem_Tata_Kerja_Pertamina_RU_II_PT_PPN_Tahun_2026.pdf', '5325399', 'application/pdf'),
(380, 73, 'admin', '038___SP_Tim_ISPS_Code_Fasilitas_TUKS_PT_PPN_RU_II_Dumai.pdf', '../document/038___SP_Tim_ISPS_Code_Fasilitas_TUKS_PT_PPN_RU_II_Dumai.pdf', '4281591', 'application/pdf'),
(381, 73, 'admin', '039___SP_Tim_ISPS_Code_Fasilitas_TUKS_PT_PPN_RU_II_Production_Spk.pdf', '../document/039___SP_Tim_ISPS_Code_Fasilitas_TUKS_PT_PPN_RU_II_Production_Spk.pdf', '4714305', 'application/pdf'),
(384, 73, 'admin', '041___SP_Penugasan_Tim_Investigasi_Kejadian_Pekerja_Kontrak_Terkena_Pecahan_Regulator_Tabung_Gas_Oksigen.pdf', '../document/041___SP_Penugasan_Tim_Investigasi_Kejadian_Pekerja_Kontrak_Terkena_Pecahan_Regulator_Tabung_Gas_Oksigen.pdf', '3887934', 'application/pdf'),
(385, 73, 'admin', '043___SP_Tim_Pelaksana_Implementasi_SMP_dan_SRA_RU_II_Tahun_2026_PT_PPN.pdf', '../document/043___SP_Tim_Pelaksana_Implementasi_SMP_dan_SRA_RU_II_Tahun_2026_PT_PPN.pdf', '6306513', 'application/pdf'),
(386, 73, 'admin', '044___SP_Management_Representatif_SMP_PT_PPN_RU_II.pdf', '../document/044___SP_Management_Representatif_SMP_PT_PPN_RU_II.pdf', '2130786', 'application/pdf'),
(387, 73, 'admin', '047___SP_Tim_Task_Force_Program_Peningkatan_Efisiensi_Dan_Optimalisasi_Stock_Materoal_Non_Hydro_PT_PPN_RU_II.pdf', '../document/047___SP_Tim_Task_Force_Program_Peningkatan_Efisiensi_Dan_Optimalisasi_Stock_Materoal_Non_Hydro_PT_PPN_RU_II.pdf', '4417027', 'application/pdf'),
(388, 73, 'admin', '048___SP_Tim_Crisis_Center_PT_PPN_RU_II_Dumai_Untuk_Penanganan_Keadaan_Darurat_Dampak_Eskalasi_Konflik_Geopolitik_Timur_Tengah.pdf', '../document/048___SP_Tim_Crisis_Center_PT_PPN_RU_II_Dumai_Untuk_Penanganan_Keadaan_Darurat_Dampak_Eskalasi_Konflik_Geopolitik_Timur_Tengah.pdf', '6429263', 'application/pdf'),
(389, 73, 'admin', '049___SP_Susunan_Pengurus_Badan_Koordinasi_Umat_Kristen__BAKOR_UMKRIS__RU_II_Dumai_PT_PPN_Periode_Tahun_2026_2028.pdf', '../document/049___SP_Susunan_Pengurus_Badan_Koordinasi_Umat_Kristen__BAKOR_UMKRIS__RU_II_Dumai_PT_PPN_Periode_Tahun_2026_2028.pdf', '3170322', 'application/pdf'),
(390, 73, 'admin', '050___SP_Tim_Pengelola_Knowledge_Management__KOMET__PT_PPN_Tahun_2026_RU_II.pdf', '../document/050___SP_Tim_Pengelola_Knowledge_Management__KOMET__PT_PPN_Tahun_2026_RU_II.pdf', '5073962', 'application/pdf'),
(391, 73, 'admin', '055___SP_Tim_Pelaksana_Implementasi_Sistem_Manajemen_Pengamanan_Tahun_2026_PT_PPN_Spk.pdf', '../document/055___SP_Tim_Pelaksana_Implementasi_Sistem_Manajemen_Pengamanan_Tahun_2026_PT_PPN_Spk.pdf', '3486104', 'application/pdf'),
(393, 73, 'admin', '057___SP_Tim_Tender_Pengadaan_Baran_Jasa_PT_PPN_RU_II_Dumai.pdf', '../document/057___SP_Tim_Tender_Pengadaan_Baran_Jasa_PT_PPN_RU_II_Dumai.pdf', '3322384', 'application/pdf'),
(392, 73, 'admin', '056___SP_Pengurus_Badan_Pembina_Olah_Raga__BAPOR__PT_PPN_Unit_II_Spk.pdf', '../document/056___SP_Pengurus_Badan_Pembina_Olah_Raga__BAPOR__PT_PPN_Unit_II_Spk.pdf', '5185935', 'application/pdf'),
(394, 73, 'admin', '059___SP_Tim_Bantuan_Keadaan_Darurat__TBKD__Di_RU_II_Production_Spk_Tahun_2026___2028.pdf', '../document/059___SP_Tim_Bantuan_Keadaan_Darurat__TBKD__Di_RU_II_Production_Spk_Tahun_2026___2028.pdf', '1203446', 'application/pdf'),
(395, 73, 'admin', '062___SP_Tim_Task_Force_Fatigue_Management_PT_PPN_RU_II_Dumai_Tahun_2026.pdf', '../document/062___SP_Tim_Task_Force_Fatigue_Management_PT_PPN_RU_II_Dumai_Tahun_2026.pdf', '2046909', 'application/pdf'),
(396, 73, 'admin', '077___SP_Tim_Task_Force_Focus_Group_Discussion__TFGD__TA_Mayor_SPK.pdf', '../document/077___SP_Tim_Task_Force_Focus_Group_Discussion__TFGD__TA_Mayor_SPK.pdf', '3673432', 'application/pdf'),
(397, 74, 'admin', 'SK_EGM___Ketentuan_dan_Tarif_Pemakaian_Fasilitas_Perusahaan_RU_II_Production_Sungai_Pakning.pdf', '../document/SK_EGM___Ketentuan_dan_Tarif_Pemakaian_Fasilitas_Perusahaan_RU_II_Production_Sungai_Pakning.pdf', '2190481', 'application/pdf'),
(398, 73, 'admin', '082___SP_Tim_Pemeriksaan_Fisik_dan_Reviu_Umur_manfaat_Aset_Tetap.pdf', '../document/082___SP_Tim_Pemeriksaan_Fisik_dan_Reviu_Umur_manfaat_Aset_Tetap.pdf', '2191727', 'application/pdf'),
(399, 73, 'admin', 'SP___Tim_Task_Force_Kejadian_First_Aid.pdf', '../document/SP___Tim_Task_Force_Kejadian_First_Aid.pdf', '2061103', 'application/pdf'),
(400, 73, 'admin', 'SP___TIM_TASK_FORCE_EKSEKUSI_TA_MAYOR_2026_RU_II_DUMAI.pdf', '../document/SP___TIM_TASK_FORCE_EKSEKUSI_TA_MAYOR_2026_RU_II_DUMAI.pdf', '19023846', 'application/pdf'),
(401, 73, 'admin', 'SP___Tim_Task_Force_APR__Accelerated_Preventive_Response_.pdf', '../document/SP___Tim_Task_Force_APR__Accelerated_Preventive_Response_.pdf', '4317068', 'application/pdf'),
(402, 73, 'admin', 'SP___Pemeriksaan_Fisik_Persediaan_Material_Non_Hydro_PT_PPN_RU_Dumai.pdf', '../document/SP___Pemeriksaan_Fisik_Persediaan_Material_Non_Hydro_PT_PPN_RU_Dumai.pdf', '2635272', 'application/pdf'),
(403, 73, 'admin', '096___Tim_Penerapan_Dan_Sertifikasi_ISO_370012016_SMAP_PT_PPN_RU_II.pdf', '../document/096___Tim_Penerapan_Dan_Sertifikasi_ISO_370012016_SMAP_PT_PPN_RU_II.pdf', '3269658', 'application/pdf'),
(404, 73, 'admin', '098_Perubahan_Susunan_Pengurus_Yayasan_BAZMA_RU_Dumai_PT_Pertamina_Patra_Niaga_Periode_2026_s.d_2028.pdf', '../document/098_Perubahan_Susunan_Pengurus_Yayasan_BAZMA_RU_Dumai_PT_Pertamina_Patra_Niaga_Periode_2026_s.d_2028.pdf', '5622951', 'application/pdf'),
(522, 73, 'admin', '097___Team_Surveillance_dan_Implementasi_ISO_223012019_BCMS_PT_PPN_RU_II_2026_202__OK_.pdf', '../document/097___Team_Surveillance_dan_Implementasi_ISO_223012019_BCMS_PT_PPN_RU_II_2026_202__OK_.pdf', '6203583', 'application/pdf'),
(523, 45, 'admin', 'NR___ABSENSIN_RTM_RU_II__2025.pdf', '../document/NR___ABSENSIN_RTM_RU_II__2025.pdf', '10443069', 'application/pdf'),
(524, 45, 'admin', 'MATERI_RAPAT_TINJAUAN_MANAJEMEN_2025.pdf', '../document/MATERI_RAPAT_TINJAUAN_MANAJEMEN_2025.pdf', '19829317', 'application/pdf'),
(525, 31, 'admin', 'Nota_Dinas_057_KPI45100_2025_S8_LAPORAN_CFIA_RU_II_2025.pdf', '../document/Nota_Dinas_057_KPI45100_2025_S8_LAPORAN_CFIA_RU_II_2025.pdf', '289050', 'application/pdf'),
(526, 37, 'admin', 'Nota_Dinas_100_KPI45100_2025_S8_Laporan_Hasil_Audit.pdf', '../document/Nota_Dinas_100_KPI45100_2025_S8_Laporan_Hasil_Audit.pdf', '279328', 'application/pdf'),
(527, 73, 'admin', '102___Tim_Taskforce_Corrosion_Management_Program.pdf', '../document/102___Tim_Taskforce_Corrosion_Management_Program.pdf', '2070570', 'application/pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tb_uploadcip`
--

CREATE TABLE `tb_uploadcip` (
  `id_cip` int(11) NOT NULL,
  `no_peg_pengupload` varchar(15) DEFAULT NULL,
  `namapengupload` varchar(35) DEFAULT NULL,
  `file_dir` varchar(150) NOT NULL,
  `size` varchar(15) DEFAULT NULL,
  `filename` varchar(40) DEFAULT NULL,
  `type` varchar(40) DEFAULT NULL,
  `id_gugus` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_uploadcip`
--

INSERT INTO `tb_uploadcip` (`id_cip`, `no_peg_pengupload`, `namapengupload`, `file_dir`, `size`, `filename`, `type`, `id_gugus`) VALUES
(10, '123', 'Abrory Salman', '../document/1._HIRADC_ENVIRONMENT_HSE_Rev_1.pdf', '707671', '1._HIRADC_ENVIRONMENT_HSE_Rev_1.pdf', 'application/pdf', '15'),
(11, '123', 'Abrory Salman', '../document/modul_3_prak_11.docx', '57612', 'modul_3_prak_11.docx', 'application/octet-stream', '16');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(4) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`) VALUES
(5, 'adminqms', 'f5f13d5cfd9ccda5284d7fe00b85fec1'),
(1, 'idell', '81831d3ea94f770099b5e3c9df8338c7'),
(4, 'admin', 'f7c44857e5befdb48c3ab62762707ff5'),
(6, 'putriafrisya', '3704eaee410ccbe422dcb67fc623be9c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_comment`
--
ALTER TABLE `tb_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `tb_employee`
--
ALTER TABLE `tb_employee`
  ADD PRIMARY KEY (`no_peg`);

--
-- Indexes for table `tb_gugus`
--
ALTER TABLE `tb_gugus`
  ADD PRIMARY KEY (`id_gugus`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indexes for table `tb_menu`
--
ALTER TABLE `tb_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `tb_news`
--
ALTER TABLE `tb_news`
  ADD PRIMARY KEY (`id_news`);

--
-- Indexes for table `tb_upload`
--
ALTER TABLE `tb_upload`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `tb_uploadcip`
--
ALTER TABLE `tb_uploadcip`
  ADD PRIMARY KEY (`id_cip`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_comment`
--
ALTER TABLE `tb_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tb_employee`
--
ALTER TABLE `tb_employee`
  MODIFY `no_peg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `tb_gugus`
--
ALTER TABLE `tb_gugus`
  MODIFY `id_gugus` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tb_menu`
--
ALTER TABLE `tb_menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `tb_news`
--
ALTER TABLE `tb_news`
  MODIFY `id_news` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_upload`
--
ALTER TABLE `tb_upload`
  MODIFY `upload_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=528;

--
-- AUTO_INCREMENT for table `tb_uploadcip`
--
ALTER TABLE `tb_uploadcip`
  MODIFY `id_cip` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

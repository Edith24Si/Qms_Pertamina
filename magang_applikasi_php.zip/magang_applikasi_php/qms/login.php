<?php
session_start();

if (!empty($_SESSION['username'])) {
	header('location:login.php');
}
?>

<!DOCTYPE html>
<head>
  <title>Quality Management System - Pertamina Patra Niaga Refinery Unit Dumai</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="admin/assets/img/favicon.gif" type="image/gif">

  <link rel="stylesheet" href="admin/assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="admin/assets/js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.min.css">
  <link rel="stylesheet" href="admin/assets/css/bootstrap.min.css">

    <!-- App CSS -->
  <link rel="stylesheet" href="admin/assets/css/target-admin.css">


  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="admin/assets/js/libs/html5shiv.js"></script>
  <script src="admin/assets/js/libs/respond.js"></script>
  <![endif]-->
</head>

<body class="account-bg">

<div class="navbar">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <i class="fa fa-cogs"></i>
      </button>
      <a class="navbar-brand navbar-brand-image" href="http://intra-ru2.pertamina.com/"><img src="admin/assets/img/logo.jpg" alt="Site Logo"></a>
    </div> <!-- /.navbar-header -->

    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">   
        <li><a href="/qms/admin" id="back-header"><i class="fa fa-angle-double-left"></i> &nbsp;Only Admin</a></li> 
      </ul>
    </div> <!--/.navbar-collapse -->

  </div> <!-- /.container -->

</div> <!-- /.navbar -->

<hr class="account-header-divider">

<div class="account-wrapper">
    <div class="account-body">
      <h3 class="account-body-title">Sign In Employee</h3>
      <h4 class="account-body-subtitle">PT. Pertamina Patra Niaga Refinery Unit Dumai</h4>
      <div id="hr"></div>
      <h5 style={color:#fff;}><em><b>Silahkan gunakan user/password email Anda untuk Login</b></em></h5>
      <form name="login" action="include/otentikasi.php" class="form account-form" method="POST">
        <?php 
        //kode php ini kita gunakan untuk menampilkan pesan eror
        if (!empty($_GET['error'])) {
          if ($_GET['error'] == 1) {
            echo '<div class="alert alert-warning">
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Username dan Password belum diisi!</strong>
                  </div>';
          } else if ($_GET['error'] == 2) {
            echo '<div class="alert alert-warning">
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Username belum diisi!</strong>
                  </div>';
          } else if ($_GET['error'] == 3) {
            echo '<div class="alert alert-warning">
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Password belum diisi!</strong>
                  </div>';
          } else if ($_GET['error'] == 4) {
            echo '<div class="alert alert-danger"> 
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Username dan Password tidak terdaftar!</strong>
                  </div>';
          }
        }
        ?>
        <div class="form-group">
          <input type="text" name="username" class="form-control uname" id="login-username" placeholder="Username" tabindex="1">
        </div> <!-- /.form-group -->

        <div class="form-group">
          <input type="password" name="password" class="form-control pword" id="login-password" placeholder="Password" tabindex="2">
        </div> <!-- /.form-group -->

        <div class="form-group clearfix">
          <div class="pull-left">         
            <label class="checkbox-inline">
            <input type="checkbox" class="" value="" tabindex="3">Remember me
            </label>
          </div>

          <div class="pull-right">
            <a href="forgot.php">Forgot Your Password?</a>
          </div>
        </div> <!-- /.form-group -->

        <div class="form-group">
          <button type="submit" name="login" class="btn btn-primary btn-block btn-lg" tabindex="4">
            Signin &nbsp; <i class="fa fa-play-circle"></i>
          </button>
        </div> <!-- /.form-group -->
      </form>
    </div> <!-- /.account-body -->
  </div> <!-- /.account-wrapper -->

  <script src="admin/assets/js/libs/jquery-1.10.1.min.js"></script>
  <script src="admin/assets/js/libs/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="admin/assets/js/libs/bootstrap.min.js"></script>

  <!--[if lt IE 9]>
  <script src="admin/assets/js/libs/excanvas.compiled.js"></script>
  <![endif]-->
  <!-- App JS -->
  <script src="admin/assets/js/target-admin.js"></script>
  
  <!-- Plugin JS -->
  <script src="admin/assets/js/target-account.js"></script>

</body>
</html>
<?php
session_start();

if (!empty($_SESSION['username'])) {
	header('location:index.php');
}
?>

<!DOCTYPE html>
<head>
  <title>Quality Management System - Pertamina Refenery Unit II Dumai</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="admin/assets/img/favicon.gif" type="image/gif">

  <link rel="stylesheet" href="admin/assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="admin/assets/js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.min.css">
  <link rel="stylesheet" href="admin/assets/css/bootstrap.min.css">

    <!-- App CSS -->
  <link rel="stylesheet" href="admin/assets/css/target-admin.css">


  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="admin/assets/js/libs/html5shiv.js"></script>
  <script src="admin/assets/js/libs/respond.js"></script>
  <![endif]-->
</head>

<body class="account-bg">

<div class="navbar">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <i class="fa fa-cogs"></i>
      </button>
      <a class="navbar-brand navbar-brand-image" href="index.php"><img src="admin/assets/img/logo.png" alt="Site Logo"></a>
    </div> <!-- /.navbar-header -->

    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">   
        <li><a href="index.php" id="back-header"><i class="fa fa-angle-double-left"></i> &nbsp;Back to Homepage</a></li> 
      </ul>
    </div> <!--/.navbar-collapse -->

  </div> <!-- /.container -->

</div> <!-- /.navbar -->

<hr class="account-header-divider">

<div class="account-wrapper">
    <div class="account-body">
      <h3 class="account-body-title">Forgot Your Password</h3>
      <h5 class="account-body-subtitle">Confirm to reset your account password default.</h5>
      <form name="login" action="include/reset.php" class="form account-form" method="POST">
        <?php 
        if (!empty($_GET['error'])) {
          if ($_GET['error'] == 1) {
            echo '<div class="alert alert-warning">
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Nomor Pegawai dan Email belum diisi!</strong>
                  </div>';
          } else if ($_GET['error'] == 2) {
            echo '<div class="alert alert-warning">
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Nomor Pegawai belum diisi!</strong>
                  </div>';
          } else if ($_GET['error'] == 3) {
            echo '<div class="alert alert-warning">
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Email belum diisi!</strong>
                  </div>';
          } else if ($_GET['error'] == 4) {
            echo '<div class="alert alert-danger"> 
                  <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                  <strong>Nomor Pegawai tidak terdaftar!</strong>
                  </div>';
          }
        }
        ?>
        <div class="form-group">
          <input type="text" name="nopeg" class="form-control" id="login-username" placeholder="Nomor Pegawai" tabindex="1">
        </div> <!-- /.form-group -->

        <div class="form-group">
          <input type="mail" name="mail" class="form-control" id="login-password" placeholder="Your Email" tabindex="2">
        </div> <!-- /.form-group -->

        <div class="form-group">
          <button type="submit" name="login" class="btn btn-primary btn-block btn-lg" tabindex="4">
            Reset Password &nbsp; <i class="fa fa-refresh"></i>
          </button>
        </div> <!-- /.form-group -->

        <div class="form-group clearfix">
          <div class="pull-left">
            <a href="login.php"><i class="fa fa-angle-double-left"></i> &nbsp;Back to Login</a>
          </div>
        </div> <!-- /.form-group -->
      </form>
    </div> <!-- /.account-body -->
  </div> <!-- /.account-wrapper -->

  <script src="admin/assets/js/libs/jquery-1.10.1.min.js"></script>
  <script src="admin/assets/js/libs/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="admin/assets/js/libs/bootstrap.min.js"></script>

  <!--[if lt IE 9]>
  <script src="admin/assets/js/libs/excanvas.compiled.js"></script>
  <![endif]-->
  <!-- App JS -->
  <script src="admin/assets/js/target-admin.js"></script>
  
  <!-- Plugin JS -->
  <script src="admin/assets/js/target-account.js"></script>

</body>
</html>
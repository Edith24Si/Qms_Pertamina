<?
include('admin/include/config.php');
$id_gugus 	= $_GET[id];

if ($_GET[module]=='daftar'){?>
	
	<?php
  		$sql=mysql_query("select * from tb_gugus where id_gugus='$id_gugus'");
		while($dat=mysql_fetch_array($sql))
	{
  		
		$no_peg=$dat[creator];
		
  	?>

	<table width="356" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="93" class="posting">Nama Gugus</td>
        <td width="263" class="posting">: <? echo"$dat[nama_gugus]"; ?></td>
      </tr>
      <tr>
        <td class="posting">Kategori</td>
        <td class="posting">: <? echo"$dat[category_gugus]"; ?></td>
      </tr>
      <tr>
        <td class="posting">Judul</td>
        <td class="posting">: <? echo"$dat[title]"; ?></td>
      </tr>
      <tr>
        <td class="posting">No Telp.</td>
        <td class="posting">: <? echo"$dat[telp]"; ?></td>
      </tr>
    </table>
    <br />
    <? } ?>
    
    
	<table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true"><thead>
  	<tr>
    <th width="5%"><div align="center">NO</div></th>
    <th width="36%"><div align="center">Nama Lengkap </div></th>
    <th width="18%"><div align="center">No. Pekerja</div></th>
    <th width="26%"><div align="center">Bagian </div></th>
    <th width="15%"><div align="center">Status</div></th>
  </tr>
</thead>
<tbody>
	<?php
  		$sql=mysql_query("select * from tb_member where id_gugus='$id_gugus' order by id_member asc");
		while($data=mysql_fetch_array($sql))
	{
  		$no++;
  	?>
  <tr>
   	<td><div align="center"><?php echo"$no";?></div></td> 
    <td><?php echo"$data[fullname]";?></td>
    <td><?php echo"$data[no_peg]";?></td>
    <td><?php echo"$data[bagian]";?></td>
    <td><div align="center"><?php echo"$data[status]";?></div></td>
  </tr>
  <?php } ?></tbody>
</table>



 <br />
 <br />
 <br />
 <br />
<span >KLIK TOMBOL DOWNLOAD UNTUK MENDOWNLOAD FILE</span>
 

<table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
<?php
  	$sql=mysql_query("select * from tb_uploadcip where id_gugus='$id_gugus'");
	while($data=mysql_fetch_array($sql))
	{ 

	?>
 	
<thead></thead>
   <tbody>

  <tr>
    
    <td colspan="4" bgcolor="#B8D434" class="style1">Nama File : <?php echo"$data[filename]";?></td>
    </tr>
  <tr>
    <td width="265"><div align="left">Ukuran : <?php $size=$data[size]; echo" $size Bytes";?></div></td>
    <td width="247">
	<?php
	if ($data['type'] == 'application/msword') {
		print("<img src=admin/assets/img/doc.png>");
	} else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
		print("<img src=admin/assets/img/docx.png>");
	} else if ($data['type'] == 'application/octet-stream') {
		print("<img src=admin/assets/img/docx.png>");
	} else if ($data['type'] == 'application/pdf') {
		print("<img src=admin/assets/img/pdf.png>");
	}
	?>
	
	</td>
    <td width="311"><div align="left">Upload By : <?php echo"$data[namapengupload]";?></div></td>
    <td width="172">
	<a class="btn btn-xs btn-secondary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Download" href="include/download.php?id=<?php echo $data['id_cip']; ?>&module=cip"><i class="fa fa-download"></i></a>
	</td>
  </tr>
  </tbody>
   <? } ?>
</table>

<?php } 
elseif ($_GET[module]=='hapus'){
$query = "DELETE FROM tb_gugus WHERE id_gugus= '$id_gugus' ";
mysql_query($query);
echo '<script language="javascript">window.location = "masukgugus.php?page=acc"</script>';
}

elseif ($_GET[module]=='acc'){
$query = "update tb_gugus set acc = 'Y' where id_gugus= '$id_gugus' ";
mysql_query($query);
echo '<script language="javascript">window.location = "masukgugus?page=acc"</script>';
}
?>

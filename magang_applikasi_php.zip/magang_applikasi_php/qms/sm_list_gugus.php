<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-bar-chart-o"></i> Daftar Nama Gugus </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
         <div class="col-md-12">
              <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Gugus</th>
                      <th>Detail</th>
                      <th>No Tlpn</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php 
                  $query = mysql_query("select * from tb_gugus");
                  $no = 1;
                  while ($data = mysql_fetch_array($query)) {
                  ?>
                    <tr>
                     <td><?php echo $no; ?></td>
                      <td><?php echo "<a href='sm_view_gugus.php?id=".$data['id_gugus']."&module=daftar'> $data[nama_gugus] </a>"; ?></td>
                      <td class="file-info">
                        <span><strong>Kategori:</strong> <?php echo $data['category_gugus'];?></span> <br />
                        <span><strong>Pembuat:</strong> <?php echo $data['creator'];?></span> <br />
                        <span><strong>Judul:</strong> <?php echo $data['title'];?></span> <br />
                      </td>
                      <td><?php echo $data['telp']; ?></td>
                      <td><center><?php 
                      if ($data['acc']=='Y') {
                        echo ('<a type="button" class="btn btn-success btn-xs">Approved</a>');
                      } else if ($data['acc']=='N') {
                        echo ('<a type="button" class="btn btn-warning btn-xs">Pendding</a>');
                      }
                      ?></center></td>
                      <?php
                      $no++;
                      } 
                      ?>
                  </tbody>
                </table>    
              </div> <!-- /.table-responsive -->
              </div>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('template/side.php');
include('template/footer.php');
?>
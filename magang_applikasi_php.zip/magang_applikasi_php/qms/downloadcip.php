<?php
include('admin/include/config.php');

$id = $_GET['id'];

$query = mysql_query("SELECT * FROM tb_uploadcip WHERE id_gugus='$id'");

list($file_dir, $type, $size, $file_name) = mysql_fetch_array($query);
header("Content-Disposition: attachment; filename=$file_name");

$fp  = fopen("admin/data_cip/".$file_name, 'r');
$content = fread($fp, filesize("admin/data_cip/".$file_name));
fclose($fp);
echo $content;
?>

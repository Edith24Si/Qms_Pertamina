<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class='fa fa-tasks'></i> News </h3>
            <!-- <h3><i class="fa fa-bar-chart-o"></i> Dashboard - </h3> -->
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
            <?php
            include('include/html-dom.php');
			include('include/fatalerror.php');
			
            $link = $_GET['link'];
            $articles = getArticles('http://10.52.0.5'.$link);

            function getArticles($page) {
                global $articles;
             
                $html = new simple_html_dom();
                $html->load_file($page);
                // Load File Page
						
				foreach($html->find('a[rel=next]') as $link)
                        $link->href = 'http://10.52.0.17/qms/m_news_link.php?link='.$link->href;

                foreach($html->find('a[rel=prev]') as $link)
                        $link->href = 'http://10.52.0.17/qms/m_news_link.php?link='.$link->href;
				
				foreach($html->find('a[rel=nofollow]') as $link)
						$link->href = 'http://10.52.0.5'.$link->href;
						
				foreach($html->find('a[title=Email]') as $link)
						$link->href = 'http://10.52.0.5'.$link->href;
				
				foreach($html->find('h2 a') as $link)
						$link->href = '#';

                $result = $html->save();
                // Modify Link Page

                $targetString = 'TARGET STRING';
                $rows = $html->find('.span12');

                $count = 1;
                foreach($rows as $row) {
                    foreach($row->find('div[class=item column-1]') as $div) {
                        if ($div->innertext === $targetString) {
                            $count++;
                            break;
                        }
                    }
                }
                // Count Element

                $items = $html->find('div[class=item-page]'); 
             
                foreach($items as $post) {
                    # remember comments count as nodes
                    $articles[] = array(

                        $post->children(0)->outertext,
                        $post->children(1)->outertext,
                        $post->children(2)->outertext,
                        $post->children(3)->outertext,
                        $post->children(4)->outertext,
                        $post->children(5)->outertext,
                        $post->children(6)->outertext,
                        $post->children(7)->outertext,
                        $post->children(8)->outertext,
                        $post->children(9)->outertext,
                        $post->children(10)->outertext,
                        $post->children(11)->outertext,
                        $post->children(12)->outertext,
                        $post->children(13)->outertext,
                        $post->children(14)->outertext,
                        $post->children(15)->outertext,
                        $post->children(16)->outertext,
                        $post->children(17)->outertext,
                        $post->children(18)->outertext,
                        $post->children(19)->outertext,
                        $post->children(20)->outertext,
                        $post->children(21)->outertext,
                        $post->children(22)->outertext,
                        $post->children(23)->outertext,);
                }

                foreach($articles as $item) {
                    echo "<div class='parser'>";
                    echo $item[0];
                    echo $item[1];
                    echo $item[2];
                    echo $item[3];
                    echo $item[4];
                    echo $item[5];
                    echo $item[6];
                    echo $item[7];
                    echo $item[8];
                    echo $item[9];
                    echo $item[10];
                    echo $item[11];
                    echo $item[12];
                    echo $item[13];
                    echo $item[14];
                    echo $item[15];
                    echo $item[16];
                    echo $item[17];
                    echo $item[18];
                    echo $item[19];
                    echo $item[20];
                    echo $item[21];
                    echo $item[22];
                    echo $item[23];
                    echo "</div>";
                }
            }
            ?>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('template/side.php');
include('template/footer.php');
?>
<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
         	<h3><i class='fa fa-bar-chart-o'></i> Contact </h3>
            <!-- <h3><i class="fa fa-bar-chart-o"></i> Dashboard - </h3> -->
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
            <h4>Alamat Perusahaan:</h4>
            <p>
               Quality Management - PT PERTAMINA (Persero) RU-II Dumai <br>
               Head Office : Jalan Puteri Tujuh Dumai - Riau, 28813 <br>
               Telp. 2226, 2227, 2228, 2229 <br>
               Copyright © 2014 - Quality Management PERTAMINA RU II
            </p>
            <br><div id="hr"></div>
            <div class="alert alert-info"> 
               Kritik, Saran atau Pesan Anda Silahkan Kirimkan Kepada Kami Dengan Cara Mengisi Form Dibawah Ini:
            </div>
            <form class="form-horizontal" role="form" name="input_data" action="include/insert.php" method="post">
            <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'success') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully sending comment. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail') {
              echo '<div class="alert alert-danger"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Sorry!</strong> Sending comment failed. 
              </div>';
            }
            ?>
            <div class="form-group">
              <label class="col-md-3">Nama Pengirim</label>

              <div class="col-md-8">
                <?php
                if (!empty($_SESSION['username'])) {
                 echo "<input type='text' name='name_emp' class='form-control' required='required' placeholder='User Name' value='$_SESSION[username]' readonly>";
                } else {
                  echo ('<input type="text" name="name_emp" class="form-control" required="required" placeholder="User Name">');
                }
                ?>
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">No Pekerja</label>

              <div class="col-md-6">
                <?php
                if (!empty($_SESSION['username'])) {
                 echo "<input type='text' name='no_peg' class='form-control' required='required' placeholder='Employer Number' value='$_SESSION[no_peg]' readonly>";
                } else {
                  echo ('<input type="text" name="no_peg" class="form-control" required="required" placeholder="Employer Number">');
                }
                ?>
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Email</label>

              <div class="col-md-6">
                 <input type="mail" name="email" class="form-control" required="required" placeholder="Email User">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Judul</label>

              <div class="col-md-8">
                 <input type="text" name="title" class="form-control" required="required" placeholder="Title">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Pesan/Komentar</label>

              <div class="col-md-8">
                 <textarea id="as-ex-2" name="content" class="form-control" rows="3"></textarea>
               </div>
            </div> <!-- Form Group -->

            <div class="col-md-9"></div>
            <!-- <input type="submit" class="btn btn-primary col-md-2" name="submit" value="Add" /><span class="fa fa-plus-square"></span> -->
            <button type="submit" name="send-comment" class="btn btn-primary col-md-2"></span>Send&nbsp;&nbsp; <span class="fa fa-plus-square"></button>
          </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
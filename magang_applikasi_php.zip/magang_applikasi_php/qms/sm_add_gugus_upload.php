<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   header('location:error-404.php');
}
include('template/navbar.php');
?>

<body>
<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
          <h3><i class='fa fa-bar-chart-o'></i> Add Gugus </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
          <form class="form-horizontal" role="form" enctype="multipart/form-data"  name="upload_data" action="include/insert.php" method="post"><br>
            <div class="form-group">
              <label class="col-md-3">Pilih File</label>

              <div class="col-md-8">
                <div class="fileupload fileupload-new" data-provides="fileupload">
                  <div class="input-group">
                    <div class="form-control"><i class="fa fa-file fileupload-exists"></i> <span class="fileupload-preview"></span></div>
                    <div class="input-group-btn">
                      <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                      <span class="btn btn-default btn-file">
                        <span class="fileupload-new">Select file</span>
                        <span class="fileupload-exists">Change</span>
                        <input type="file" name="myfile"/>
                      </span>
                    </div>
                  </div>
                </div> 
              </div>
            </div> <!-- Form Group -->
            <br><div id="hr"></div>
            <div class="col-md-9"></div>
            <button type="submit" name="gugus-upload" class="btn btn-primary col-md-2">Upload&nbsp;&nbsp; <span class="fa fa-upload"></span></button>
          </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('template/side.php');
include('template/footer.php');
?>
<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
         	<P><h3><i class="fa fa-bullhorn"></i> Kata Pengantar</h3></P>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">

 
<p>Salam Sejahtera,</p>

<p align="justify">Mohon maaf website ini masih dalam tahap pengembangan, saran kritik dari Anda sangat berpengaruh untuk pengembangan Website ini ke arah yang lebih baik lagi. Terimakasih atas kerjasamanya.</p>


<p><br/><br/>Team Developer.<br>
Kerjasama Antara Quality Management dan<br>
IT RU II Area</p>

         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('template/side.php');
include('template/footer.php');
?>
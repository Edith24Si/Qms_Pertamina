<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   header('location:error-404.php');
}
include('template/navbar.php');
?>

<body>
<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
          <h3><i class='fa fa-user'></i> Profile - <?php echo "$_SESSION[username]"; ?> </h3>
         </div> <!-- /.portlet-header -->

         <?php 
         $id = $_SESSION['no_peg'];
         $query = mysql_query("select * from tb_employee where no_peg='$id'") or die(mysql_error());
         $data = mysql_fetch_array($query);
         ?>

         <div class="portlet-content">
          <form class="form-horizontal" role="form" enctype="multipart/form-data"  name="update_profile" action="include/update.php?id=<?php echo "$_SESSION[no_peg]"; ?>" method="post"><br>
            <div class="form-group">
              <label class="col-md-3">Nomor Pegawai</label>

              <div class="col-md-6">
                 <input type="text" name="no_peg" class="form-control" value="<?php echo $data['no_peg']; ?>" disabled>
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Username</label>

              <div class="col-md-8">
                 <input type="text" name="username" class="form-control" value="<?php echo $data['emp_name']; ?>">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Email</label>

              <div class="col-md-8">
                 <input type="email" name="mail" class="form-control" placeholder="Email Employee" value="<?php echo $data['email']; ?>">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">New Password</label>

              <div class="col-md-8">
                 <input type="password" name="password" class="form-control" placeholder="Change Password">
               </div>
            </div> <!-- Form Group -->
            <br><div id="hr"></div>
            <div class="col-md-9"></div>
            <button type="submit" name="gugus-upload" class="btn btn-primary col-md-2">Update&nbsp;&nbsp; <span class="fa fa-level-up"></span></button>
          </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<div class="row">

        <div class="col-md-12">

          <div class="error-container">

            <div class="error-code">
              404
            </div> <!-- /.error-code -->

            <div class="error-details">
              <h4>Oops, You're lost.</h4>
              <p>We can not find the page you're looking for. Is there a typo in the url? Or try the search bar below</p>

              <form action="http://preview.jumpstartthemes.com/target-admin/" class="form">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <span class="input-group-btn">
                      <button class="btn btn-primary" type="button">
                        <i class="fa fa-search"></i>
                      </button>
                    </span>
                  </div><!-- /input-group -->

              </form>
            </div> <!-- /.error-details -->

          </div> <!-- /.error -->

        </div> <!-- /.col-md-12 -->

      </div> <!-- /.row -->

      <br><br>

<?php
include('template/footer.php');
?>
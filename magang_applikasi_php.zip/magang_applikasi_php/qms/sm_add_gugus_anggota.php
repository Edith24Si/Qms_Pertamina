<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   header('location:error-404.php');
}
include('template/navbar.php');
?>

<body>
<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
          <h3><i class='fa fa-bar-chart-o'></i> Add Gugus </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
          <div class="alert alert-info"> 
            <b>2. </b>Pendaftaran Nama Anggota Gugus 
          </div>
          <form class="form-horizontal" role="form" action="include/insert.php" method="post"><br>
		  <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'success') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully Delete Anggota. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail') {
              echo '<div class="alert alert-danger"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Oh Snap!</strong> Failed to delete Anggota. 
              </div>';
            }
		  ?>
            <div class="form-group">
               <label class="col-md-3">Nama Lengkap</label>
               <div class="col-md-8">
                  <input type="text" name="fullname" class="form-control">
               </div>
            </div>
            <!-- Form Group -->

            <div class="form-group">
               <label class="col-md-3">No. Pekerja</label>
               <div class="col-md-8">
                  <input type="text" name="no_peg" class="form-control">
               </div>
            </div> <!-- Form Group -->

            <div class="form-group">
               <label class="col-md-3">Bagian</label>
               <div class="col-md-8">
                  <input type="text" name="divisi" class="form-control">
               </div>
            </div> <!-- Form Group -->

            <div class="form-group">
               <label class="col-md-3">Status</label>
               <div class="col-md-5">
                  <select id="s2_basic" name="status" class="form-control">
                     <option selected></option>
                     <option value="Ketua">Ketua</option>
                     <option value="Anggota">Anggota</option>
                  </select>
               </div>
               <button type="submit" name="gugus-member" class="btn btn-primary col-md-2">Add&nbsp;&nbsp; <span class="fa fa-plus-square"></span></button>
            </div> <!-- Form Group -->

            <!-- <br><div id="hr"></div><br> -->

            <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
               <thead>
                  <tr>
                     <th>No</th>
                     <th>Nama Lengkap</th>
                     <th>No Pekerja</th>
                     <th>Bagian</th>
                     <th>Status</th>
                     <th>Aksi</th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                  $query = "SELECT max(id_gugus) FROM tb_gugus";
                  $hasil = mysql_query($query);
                  $data  = mysql_fetch_array($hasil);
                  $id_gugus      = $data['max(id_gugus)'];

                  $query = mysql_query("select * from tb_member where id_gugus=$id_gugus ORDER BY id_member ASC");
                  $no = 1;
                  while ($data = mysql_fetch_array($query)) {
                  ?>
                  <tr>
                     <td><?php echo $no; ?></td>
                     <td><?php echo $data['fullname']; ?></td>
                     <td><?php echo $data['no_peg']; ?></td>
                     <td><?php echo $data['bagian']; ?></td>
                     <td>
                     <?php echo $data['status']; ?>
                     </td>
                     <td class="text-center">
                        <a class="btn btn-xs btn-primary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Delete" name="delete_data" href="include/delete.php?id=<?php echo $data['id_member']; ?>&module=member"><i class="fa fa-times"></i></a>
                     </td></tr>
                     <?php
                     $no++;
                     } 
                     ?>
                  </tbody>
               </table>
                
            <br><div id="hr"></div>
            <div class="col-md-10"></div>
            <a type="submit" class="btn btn-primary col-md-2" href="sm_add_gugus_upload.php">Next&nbsp;&nbsp; <span class="fa fa-arrow-right"></span></a>
            <!-- <button type="submit" class="btn btn-primary col-md-2"></span>Next&nbsp;&nbsp; <span class="fa fa-arrow-right"></button> -->
          </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('template/side.php');
include('template/footer.php');
?>
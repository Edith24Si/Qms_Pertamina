<?php
session_start();
include "inc/db.php";

if(isset($_POST['usrname']) && isset($_POST['passwd'])){

	//$adServer = "ldap://ptmjypad001";
	$adServer = "ldap://ptplkpad1";
	//$adServer = "ldap://pertamina.com";
	//$adServer = "ldap://ptmru2prod04";
	$ldap = ldap_connect($adServer);
	$name = $_POST['usrname'];
	$pass = $_POST['passwd'];
	$ldaprdn = 'pertamina' . "\\" . $name;

	ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
	ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

	$bind = @ldap_bind($ldap, $ldaprdn, $pass);

	if ($bind){
		$filter="(sAMAccountName=$name)";
		//$result = ldap_search($ldap,"OU=RU2 Dumai,dc=PERTAMINA,dc=COM",$filter);
		$result = ldap_search($ldap,"dc=PERTAMINA,dc=COM",$filter);
		ldap_sort($ldap,$result,"sn");
		$info = ldap_get_entries($ldap, $result);
		for ($i=0; $i<$info["count"]; $i++){
			if($info['count'] > 1)
			  break;
			$nopek=$info[$i]["employeeid"][0];
			$emp_name=$info[$i]["displayname"][0];
			$email=$info[$i]["mail"][0];
			$jabatan=$info[$i]["title"][0];
			$telpon=$info[$i]["telephonenumber"][0];
			$fungsi=$info[$i]["department"][0];
			if ($nopek=='713718'){$nopek='123456';}

				$emp = mysql_query("select * from employee where username='$name'");
				$data = mysql_fetch_array($emp);
				$numrows= mysql_num_rows($emp);
				$crypss=encrypss($pass);
				if ($numrows < 1){
					$exec = mysql_query("insert into employee (id,usertype,nopek,emp_name,username,password,email,jabatan, fungsi,telpon,online,onlinetime) values ('','1','$nopek','$emp_name','$name','$crypss','$email','$jabatan', '$fungsi','$telpon','1','".date('Y-m-d H:i:s')."')");
				}else{
					$exec = mysql_query("update employee set online=2,onlinetime='".date('Y-m-d H:i:s')."',password='$crypss' where username='$name'");
				}
				$status = "validbeneer";
				$_SESSION['sttrekomendasi'] = $status;
				$_SESSION['USR_IDM'] = $data['id'];
				$_SESSION['username'] = $data['username'];
				$_SESSION['USR_NPK'] = $data['nopek'];
				$_SESSION['USR_TYP'] = $data['usertype'];
				$_SESSION['USR_NAME'] = $data['emp_name'];
				if ($data[usertype]=='2')
					header('location:../index.php');
				else 
					header('location:../index.php');

		}
		if($info['count']<1){
			header('location:../login.php?error=4');
			//$msg = "email Anda tidak terdaftar di RU II Dumai..";
			//echo $msg;
		}
		@ldap_close($ldap);
	}else{
	header('location:../login.php?error=4');
	//$msg = "Invalid email address/password...";
	//echo $msg;
	}
}else{
	header('location:../login.php?error=4');
} 
?>

<?php
include('../admin/include/config.php');

session_start();

$nopeg = $_POST['nopeg'];
$mail = $_POST['mail'];

$nopeg = mysql_real_escape_string($nopeg);
$mail = mysql_real_escape_string($mail);

if (empty($nopeg) && empty($mail)) {
	header('location:../forgot.php?error=1');
	break;
} else if (empty($nopeg)) {
	header('location:../forgot.php?error=2');
	break;
} else if (empty($mail)) {
	header('location:../forgot.php?error=3');
	break;
}

$query = mysql_query("select * from tb_employee where no_peg='$nopeg'");
$data = mysql_fetch_array($query);
$emp_name = $data['emp_name'];
$no_peg = $data['no_peg'];

if (mysql_num_rows($query) == 1) {
	$query = mysql_query("insert into tb_comment values('', '$emp_name', '$no_peg', '$mail', '', 'Tolong reset kembali password dengan nomor pegawai : $no_peg, Terimakasih!', 'reset', 'N')");
    if ($query) {
        header('location:../forgot.php?message=success');
    } else {
        header('location:../forgot.php?message=fail');
    }
} else {
	header('location:../forgot.php?error=4');
}
?>
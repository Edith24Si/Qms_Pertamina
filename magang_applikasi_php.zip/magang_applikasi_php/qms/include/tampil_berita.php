<?php
include "../admin/include/config.php";
include "../admin/include/fungsi_indotgl.php";

// Modul detail berita
if ($_GET[module]=='detailberita'){
	$detail=mysql_query("SELECT * FROM tb_news   
                      WHERE id_news='$_GET[id]'");
	$d   = mysql_fetch_array($detail);
	$tgl = tgl_indo($d[date]);
	echo "<span class=date>$d[day] $tgl - $d[time] WIB</span><br />";
	echo "<span class=judul>$d[title]</span><br />";
	echo "<span class=posting>Diposting oleh : <b>$d[creator]</b> - Dibaca: <b>$d[read]</b> kali</span><br /><br />";
  // Apabila ada gambar dalam berita, tampilkan   
 	if ($d[pictures]!=''){  
		echo "<span class=image><img src='../admin/assets/img/news_dir/$d[file_name]' width=400 border=0 style='float:left;'></span>";
	}
 	$isi_berita=nl2br($d[content]); // membuat paragraf pada isi berita
	echo "<span class=posting> $isi_berita </span>";	 		  
  // Apabila detail berita dilihat, maka tambahkan berapa kali dibacanya
  mysql_query("UPDATE tb_news SET read=$d[read]+1 
              WHERE id_news='$_GET[id]'");
}




// Halaman utama (Home)
else{
  // Tampilkan 4 headline berita terbaru
 	$terkini= mysql_query("SELECT * FROM tb_news ORDER BY id_news DESC LIMIT 4");		 
	while($t=mysql_fetch_array($terkini)){
		$tgl = tgl_indo($t[date]);
		echo "<span class=date>$tgl - $t[time] WIB</span><br />";
		echo "<span class=judul2><a href=?page=berita&module=detailberita&id=$t[id_news]>$t[title]</a></span><br />";
 	
		// Apabila ada gambar dalam berita, tampilkan
    if ($t[pictures]!=''){
			echo "<span class=image><img src='../admin/assets/img/news_dir/$t[file_name]' width=110 border=0 style='float:left;'></span>";
		}
    // Tampilkan hanya sebagian isi berita
	$isi_berita = nl2br($t[content]); // membuat paragraf pada isi berita
    $isi = substr($isi_berita,0,300); // ambil sebanyak 300 karakter
    $isi = substr($isi_berita,0,strrpos($isi," ")); // potong per spasi kalimat
   

    echo "<span class=posting width=110>$isi ... <a href='?page=berita&module=detailberita&id=$t[id_news]'>Selengkapnya</a></span>
          <br />	<hr color=#6600CC noshade=noshade />";
	}
  
  // Tampilkan 5 judul berita sebelumnya (tampilkan judulnya aja)
  
}

?>

<?php
session_start();
include('../admin/include/config.php');

//tangkap data dari form login
$username = $_POST['username'];
$password = $_POST['password'];

//untuk mencegah sql injection
//kita gunakan mysql_real_escape_string
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

//cek data yang dikirim, apakah kosong atau tidak
if (empty($username) && empty($password)) {
	//kalau username dan password kosong
	header('location:../login.php?error=1');
	break;
} else if (empty($username)) {
	//kalau username saja yang kosong
	header('location:../login.php?error=2');
	break;
} else if (empty($password)) {
	//kalau password saja yang kosong
	header('location:../login.php?error=3');
	break;
}

//------------ditambahkan-------------
	$adServer = "ldap://ptplkpad1";
	$ldap = ldap_connect($adServer);
	$name = $_POST['username'];
	$pass = $_POST['password'];
	$ldaprdn = 'pertamina' . "\\" . $name;
		ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
		ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
	$bind = @ldap_bind($ldap, $ldaprdn, $pass);

if($bind ){
	$filter="(sAMAccountName=$name)";
	$result = ldap_search($ldap,"dc=PERTAMINA,dc=COM",$filter);
	ldap_sort($ldap,$result,"sn");
	$info = ldap_get_entries($ldap, $result);
	for ($i=0; $i<$info["count"]; $i++){
		if($info['count'] > 1)
		  break;
		$nopek=$info[$i]["employeeid"][0];
		$emp_name=$info[$i]["displayname"][0];
		$email=$info[$i]["mail"][0];
		$jabatan=$info[$i]["title"][0];
		$telpon=$info[$i]["telephonenumber"][0];
		$fungsi=$info[$i]["department"][0];
	}
ldap_close( $ldap['conn'] );

$qm = mysql_query("select * from tb_employee_baru where username='$username'");
$data = mysql_fetch_array($qm);
$numrows= mysql_num_rows($qm);
$crypss=encrypss($password);

if ($numrows < 1){
	//$exec = mysql_query("insert into tb_employee (no_peg, emp_name, username, password, reset_pswd, email, online, onlinetime) values ('','','$username','$crypqms','','$username@pertamina.com','1','".date('Y-m-d H:i:s')."')");
	$exec = mysql_query("insert into tb_employee_baru (id,usertype,nopek,emp_name,username,password,email,jabatan, fungsi,telpon,online,onlinetime) values ('','1','$nopek','$emp_name','$name','$crypss','$email','$jabatan', '$fungsi','$telpon','1','".date('Y-m-d H:i:s')."')");
}else{
	//$exec = mysql_query("update tb_employee set online=1, onlinetime='".date('Y-m-d H:i:s')."', password='rahasia' where username='$username'");
	$exec = mysql_query("update tb_employee_baru set online=2,onlinetime='".date('Y-m-d H:i:s')."',password='$crypss' where username='$username'");
}
	$_SESSION['username'] = $username;
	header('location:../index.php');
    } else {
	header('location:../login.php?error=4');
    }

?>
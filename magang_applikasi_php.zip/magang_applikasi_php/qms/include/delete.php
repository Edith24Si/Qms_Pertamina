<?php
include('../admin/include/config.php');

if($_GET['module']=='member') {
	$id = $_GET['id'];

	$query = mysql_query("delete from tb_member where id_member='$id'");
	$query = mysql_query("set @count:=0");
	$query = mysql_query("UPDATE tb_member SET id_member=@count:=@count+1 ORDER BY id_member");

	if ($query) {
		header('location:../sm_add_gugus_anggota.php?message=success');
	}
}
?>
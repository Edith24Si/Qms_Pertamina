<?php
include('../admin/include/config.php');
session_start();

if(isset($_POST['send-comment'])){
    $name_emp = $_POST['name_emp'];
    $no_peg = $_POST['no_peg'];
    $email = $_POST['email'];
    $content = $_POST['content'];
    $title = $_POST['title'];

    $query = mysql_query("insert into tb_comment values('', '$name_emp', '$no_peg', '$email', '$title', '$content', '', '')");
    if ($query) {
        header('location:../m_contact.php?message=success');
    } else {
        header('location:../m_contact.php?message=fail');
    }   
}

if(isset($_POST['gugus-add'])){
    $username = $_SESSION['username'];
    $category = $_POST['category'];
    $name = $_POST['name'];
    $title = $_POST['title'];
    $telp = $_POST['telp'];

    $query = mysql_query("insert into tb_gugus values('', '$username', '$category', '$name', '$title', '$telp', 'N')");
    if ($query) {
        header('location:../sm_add_gugus_anggota.php');
    } else {
        header('location:../sm_add_gugus.php');
    }   
}

$query = mysql_query("SELECT max(id_gugus) FROM tb_gugus");
$data  = mysql_fetch_array($query);
$id_gugus       = $data['max(id_gugus)'];

if(isset($_POST['gugus-member'])){
    $fullname = $_POST['fullname'];
    $no_peg = $_POST['no_peg'];
    $divisi = $_POST['divisi'];
    $status = $_POST['status'];

    $query = mysql_query("insert into tb_member values('', '$id_gugus', '$fullname', '$no_peg', '$divisi', '$status')");
    if ($query) {
        header('location:../sm_add_gugus_anggota.php');
    } else {
        header('location:../sm_add_gugus_anggota.php');
    }   
}

$query = mysql_query("SELECT max(id_gugus) FROM tb_gugus");
$data  = mysql_fetch_array($query);
$id_gugus = $data['max(id_gugus)'];

if(isset($_POST['gugus-upload'])){
    $username = $_SESSION['username'];
    $no_peg = $_SESSION['no_peg'];

    $name = $_FILES['myfile']['name'];
    $type = $_FILES['myfile']['type'];
    $size = $_FILES['myfile']['size'];
    $tmp  = $_FILES['myfile']['tmp_name'];
    $dir = "../document/";
	
	$pattern="/[^a-zA-Z0-9\.]/";
	$replace="_";
	$file = preg_replace($pattern,$replace,$name);

    if (!empty($tmp)) {
        if($type=="application/msword" || $type=="application/pdf" || $type=="application/vnd.openxmlformats-officedocument.wordprocessingml.document" || $type=="application/octet-stream") {
            $files = $dir . $file;
            if (move_uploaded_file($tmp, $files)) {
                $query = mysql_query("insert into tb_uploadcip values('', '$no_peg', '$username', '$files', '$size', '$file', '$type', '$id_gugus')");
                if ($query) {
                    header('location:../sm_list_gugus.php?');
                } else {
                    header('location:../sm_list_gugus.php?');
                }
            }
        } else {
            header('location:../sm_list_gugus.php?');
        }
    } else {
        header('location:../sm_list_gugus.php?');
    }
}
?>
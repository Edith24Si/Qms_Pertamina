<?php 
include('../admin/include/config.php');
session_start();

$id = $_GET['id'];
$name_emp = $_POST['username'];
$mail = $_POST['mail'];
$password = $_POST['password'];

if (empty($password)) {
	$query = mysql_query("UPDATE tb_employee SET emp_name='$name_emp', email='$mail' where no_peg='$id'");

	if ($query) {
		header('location:../m_profile.php?message=success');
	}
}

if (!empty($password)) {
	$query = mysql_query("UPDATE tb_employee SET emp_name='$name_emp', password=MD5('$password'), email='$mail' where no_peg='$id'");

	if ($query) {
		header('location:../m_profile.php?message=success');
	}
}
?>
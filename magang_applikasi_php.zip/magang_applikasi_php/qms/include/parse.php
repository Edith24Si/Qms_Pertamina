<?php
include('html-dom.php');
//include('fatalerror.php');

$articles = getArticles('http://10.52.0.5/index.php');

function getArticles($page) {
    global $articles;
 
    $html = new simple_html_dom();
    $html->load_file($page);
						
    foreach($html->find('h2 a') as $link)
            $link->href = 'http://10.52.0.17/qms/m_news_link.php?link='.$link->href;
			
	foreach($html->find('p[class=readmore] a') as $link)
            $link->href = 'http://10.52.0.17/qms/m_news_link.php?link='.$link->href;

    foreach($html->find('ul[class=pagination-list] li a') as $link)
            $link->href = 'http://10.52.0.17/qms/m_news_pag.php?link='.$link->href;
			
	foreach($html->find('a[rel=nofollow]') as $link)
            $link->href = 'http://10.52.0.5'.$link->href;
			
	foreach($html->find('a[title=Email]') as $link)
            $link->href = 'http://10.52.0.5'.$link->href;
	
	foreach($html->find('p a') as $link)
            $link->href = 'http://10.52.0.5'.$link->href;

    foreach($html->find('p a img') as $link)
            $link->src = 'http://10.52.0.5'.$link->src;

    $html->find('ul[class=pagination-list]', 0)->class = 'pagination';
	$html->find('p a img', 1)->width = '100%';
    $html->find('p a img', 1)->height = '';

    $html->find('a i[class=icon-first]', 0)->outertext = '<i class="fa fa-angle-double-left"></i>';
    $html->find('a i[class=icon-previous]', 0)->outertext = '<i class="fa fa-angle-left"></i>';
    $html->find('a i[class=icon-next]', 0)->outertext = '<i class="fa fa-angle-right"></i>';
    $html->find('a i[class=icon-last]', 0)->outertext = '<i class="fa fa-angle-double-right"></i>';
    
    $result = $html->save();
    
    $items = $html->find('div[class=blog]'); 
 
    foreach($items as $post) {
        # remember comments count as nodes
        $articles[] = array(
            $post->children(0)->outertext,
            $post->children(2)->outertext,
            $post->children(4)->outertext,
            $post->children(6)->outertext,
            $post->children(8)->outertext,
            $post->children(10)->outertext,
            $post->children(12)->outertext,
            $post->children(14)->outertext,);
    }

    foreach($articles as $item) {
        echo "<div class='parser'>";
        echo $item[0];
        echo $item[1];
        echo $item[2];
        echo $item[3];
        echo $item[4];
        echo $item[5];
        echo $item[6];
        echo "<center>";
        echo $item[7];
        echo "</center>";
        echo "</div>";
    }
}
?>
<body>
  <div class="navbar">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <i class="fa fa-cogs"></i>
      </button>      
      <a class="navbar-brand navbar-brand-image" href="index.php">
        <img src="admin/assets/img/logo.jpg" alt="Site Logo">
      </a>
    </div> <!-- /.navbar-header -->

    <div class="navbar-collapse collapse"> 
      <ul class="nav navbar-nav navbar-right">   
        <li><a href="m_kata_pengantar.php"> Kata Pengantar</a></li>    
        <!-- Kata Pengantar -->
        <li><a data-toggle="modal" data-target="#myModal" style="cursor:pointer;"> About</a></li>    
        <!-- About -->

        <?php 
        if (!empty($_SESSION['username'])) {
            echo "
            <li class='dropdown navbar-profile'><a class='dropdown-toggle' data-toggle='dropdown' href='javascript:;'>
              <img src='admin/assets/img/avatars/avatar.png' class='navbar-profile-avatar' alt=''><span class='navbar-profile-label'>rod@rod.me &nbsp;</span><i class='fa fa-caret-down'></i></a>

              <ul class='dropdown-menu' role='menu'>
                <li class='dropdown-header'><center>$_SESSION[username]</center></li>
                <li class='divider'></li>
                <li><a href='m_profile.php'><i class='fa fa-user'></i> &nbsp;&nbsp;My Profile</a></li>
                <li class='divider'></li>
                <li><a href='logout.php'><i class='fa fa-sign-out'></i> &nbsp;&nbsp;Logout</a></li>
              </ul>
            </li>";
          } else {
            print("<li id=login-header><a href=login.php> Sign In</a></li>");
          }  
        ?>        

      </ul>
    </div> <!-- navbar-collapse -->
  </div> <!-- /.container -->

</div> <!-- /.navbar -->
  <div class="mainbar">
  <div class="container">
    <button type="button" class="btn mainbar-toggle" data-toggle="collapse" data-target=".mainbar-collapse">
      <i class="fa fa-bars"></i>
    </button>

    <div class="mainbar-collapse collapse">
      <ul class="nav navbar-nav mainbar-nav">
        <li <?php if (selected("index") or selected(basename($_SERVER['REQUEST_URI']))) ?>><a href="index.php"><i class="fa fa-home"></i> &nbsp;&nbsp;Home&nbsp;&nbsp;</a></li>
        <!-- Home -->

        <?php
        if (!empty($_SESSION['username'])) {
        ?>
          <li class="dropdown <?php if (selectedSub("sm_panduan_cip") or selectedSub("sm_contoh_cip_pkm") or selectedSub("sm_contoh_cip_gkm") or selectedSub("sm_contoh_cip_ss") or selectedSub("sm_klinik_cip") or selectedSub("sm_coe") or selectedSub("sm_list_gugus") or selectedSub("sm_add_gugus")) ?>"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
            <i class="fa fa-align-left"></i> &nbsp;&nbsp;CIP&nbsp;<span class="caret"></span>&nbsp;</a>
            <ul class="dropdown-menu">   
              <li <?=selected("sm_panduan_cip")?>><a href="sm_panduan_cip.php"><i class="fa fa-user nav-icon"></i> Panduan CIP</a></li>
              <li class="dropdown-submenu <?php if (selectedSub("sm_contoh_cip_pkm") or selectedSub("sm_contoh_cip_gkm") or selectedSub("sm_contoh_cip_ss")) ?>"><a href="#"><i class="fa fa-bars nav-icon"></i> Contoh CIP</a>
                <ul class="dropdown-menu">
                  <li <?=selected("sm_contoh_cip_pkm")?>><a href="sm_contoh_cip_pkm.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;PKM</a></li>
                  <li <?=selected("sm_contoh_cip_gkm")?>><a href="sm_contoh_cip_gkm.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;GKM</a></li> 
                  <li <?=selected("sm_contoh_cip_ss")?>><a href="sm_contoh_cip_ss.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;SS</a></li> 
                </ul>
              </li>
              <li <?=selected("sm_klinik_cip")?>><a href="sm_klinik_cip.php"><i class="fa fa-asterisk nav-icon"></i> Klinik CIP</a></li>
              <li <?=selected("sm_coe")?>><a href="sm_coe.php"><i class="fa fa-tasks nav-icon"></i> Calender of Event</a></li>
              <li class="dropdown-submenu <?php if (selectedSub("sm_list_gugus") or selectedSub("sm_add_gugus")) ?>"><a href="#"><i class="fa fa-bars nav-icon"></i> Gugus</a>
                <ul class="dropdown-menu">
                  <li <?=selected("sm_list_gugus")?>><a href="sm_list_gugus.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;List Gugus</a></li>
                  <li <?=selected("sm_add_gugus")?>><a href="sm_add_gugus.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;Add Gugus CIP</a></li> 
                </ul>
              </li>
            </ul>
          </li>
          <!-- CIP -->
        <?php
        }
        ?>

        <li class="dropdown <?php if (selectedSub("sm_kebijakan_sm") or selectedSub("sm_requirement_9001") or selectedSub("sm_requirement_14001") or selectedSub("sm_requirement_18001") or selectedSub("sm_requirement_smp") or selectedSub("sm_requirement_mkp") or selectedSub("sm_ia_temuan_2012") or selectedSub("sm_ia_temuan_2013") or selectedSub("sm_ia_temuan_2014") or selectedSub("sm_ia_tl_2012") or selectedSub("sm_ia_tl_2013") or selectedSub("sm_ia_tl_2014") or selectedSub("sm_sa_temuan_2012") or selectedSub("sm_sa_temuan_2013") or selectedSub("sm_sa_temuan_2014") or selectedSub("sm_sa_tl_2012") or selectedSub("sm_sa_tl_2013") or selectedSub("sm_sa_tl_2014") or selectedSub("sm_hiradc") or selectedSub("sm_daftar_catatan") or selectedSub("sm_rtm") or selectedSub("sm_proses_bisnis")) ?>"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
          <i class="fa fa-archive"></i> Sistem Managemen&nbsp;<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <!-- <li <?=selected("sm_kebijakan_sm")?>><a href="sm_kebijakan_sm.php"><i class="fa fa-location-arrow nav-icon"></i> Kebijakan Sistem Management</a></li> -->
            <li <?=selected("sm_requirement")?>><a href="sm_requirement.php"><i class="fa fa-location-arrow nav-icon"></i> Requirement/Persyaratan </a></li>
            <?php 
            if (!empty($_SESSION['username'])) {
            ?>
            <li <?=selected("sm_ia")?>><a href='sm_ia.php'><i class='fa fa-bar-chart-o'></i> &nbsp;&nbsp;Internal Audit </a></li>
            <li <?=selected("sm_sa")?>><a href='sm_sa.php'><i class='fa fa-bar-chart-o'></i> &nbsp;&nbsp;Eksternal Audit </a></li>
            <?php
            }
            ?>
            <li <?=selected("sm_hiradc")?>><a href="sm_hiradc.php"><i class="fa fa-table"></i> &nbsp;&nbsp;HIRADC</a></li>
            <li <?=selected("sm_daftar_catatan")?>><a href="sm_daftar_catatan.php"><i class="fa fa-table"></i> &nbsp;&nbsp;Daftar Catatan/Rekaman Fungsi</a></li>
            <li <?=selected("sm_rtm")?>><a href="sm_rtm.php"><i class="fa fa-table"></i> &nbsp;&nbsp;Rapat Tinjauan Manajemen</a></li>
            <li <?=selected("sm_proses_bisnis")?>><a href="sm_proses_bisnis.php"><i class="fa fa-table"></i> &nbsp;&nbsp;Proses Bisnis</a></li>
          </ul>
        </li>
        <!-- Sistem Management -->
        <?php 
        if (!empty($_SESSION['username'])) {
        ?>
          <li class="dropdown <?php if (selectedSub("sm_fs_tki") or selectedSub("sm_fs_tko") or selectedSub("sm_fs_lain")) ?>"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
            <i class="fa fa-files-o"></i> &nbsp;&nbsp;STK&nbsp;<span class="caret"></span>&nbsp;</a>
            <ul class="dropdown-menu">
              <li><a href="http://ptmru2prod04.pertamina.com/stk" target="_blank"><i class="fa fa-question nav-icon"></i> STK Online</a></li>
              <li <?=selected("sm_fs_stkp")?>><a href="sm_fs_stkp.php"><i class="fa fa-user nav-icon"></i> Form Standar STKP</a></li>
              <li <?=selected("sm_fs_lain")?>><a href="sm_fs_lain.php"><i class="fa fa-dollar nav-icon"></i> Form Standar Lainnya</a></li>
            </ul>
          </li>
          <!-- STK -->
          <li class="dropdown <?php if (selectedSub("sm_kkep_2010") or selectedSub("sm_kkep_2012") or selectedSub("sm_kkep_2014")) ?>"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
            <i class="fa fa-bar-chart-o"></i> KKEP-PQA&nbsp;<span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li <?=selected("sm_kkep_OfiToAfi")?>><a href="sm_kkep_OfiToAfi.php"><i class="fa fa-bell"></i> OFI to AFI </a></li>
			  <li <?=selected("sm_kkep_evidence")?>><a href="sm_kkep_evidence.php"><i class="fa fa-smile-o"></i> Evidence</a></li> 
              <li <?=selected("sm_kkep_bukukkep")?>><a href="sm_kkep_bukukkep.php"><i class="fa fa-ban"></i> Buku KKEP </a></li>
			  <li <?=selected("sm_kkep_score")?>><a href="sm_kkep_score.php"><i class="fa fa-ban"></i> Score </a></li>
            </ul>
          </li>
          <!-- KKEP-PQA -->
        <?php
        }
        ?>
        <li class="dropdown <?php if (selectedSub("sm_contoh_komet") or selectedSub("sm_ef") or selectedSub("sm_df") or selectedSub("sm_cop") or selectedSub("sm_cei") or selectedSub("sm_ap")) ?>"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
          <i class="fa fa-tags"></i> KOMET&nbsp;<span class="caret"></span></a>
          <ul class="dropdown-menu">   
            <li <?=selected("sm_contoh_komet")?>><a href="sm_contoh_komet.php"><i class="fa fa-user nav-icon"></i> Contoh KOMET</a></li>
            <li <?=selected("sm_ef")?>><a href="sm_ef.php"><i class="fa fa-bars nav-icon"></i> Expert Forum</a></li>
            <li <?=selected("sm_df")?>><a href="sm_df.php"><i class="fa fa-asterisk nav-icon"></i>Forum</a></li>
            <li <?=selected("sm_cop")?>><a href="sm_cop.php"><i class="fa fa-tasks nav-icon"></i> CoP</a></li>
<!--            <li <?=selected("sm_cei")?>><a href="sm_cei.php"><i class="fa fa-tasks nav-icon"></i> Converence Expert Interview</a></li> -->
            <li <?=selected("sm_ap")?>><a href="http://intra.pertamina.com:83/"><i class="fa fa-tasks nav-icon"></i> Asset Pengetahuan</a></li>
          </ul>
        </li>
        <!-- KOMET -->
        <li class="dropdown <?php if (selectedSub("sm_sk") or selectedSub("sm_sp2020") or selectedSub("sm_sp2021") or selectedSub("sm_sp2022") or selectedSub("sm_sp2023") or selectedSub("sm_sp2024") or selectedSub("sm_sp2025") or selectedSub("sm_sp2026")) ?>"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
          <i class="fa fa-suitcase"></i> SP & SK&nbsp;<span class="caret"></span></a>
          <ul class="dropdown-menu">   
            <li class="dropdown-submenu"><a href="#"><i class="fa fa-user nav-icon"></i> SP</a>
              <ul class="dropdown-menu">
                <li <?=selected("sm_sp2020")?>><a href="sm_sp2020.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2020&nbsp;(+thn&nbsp;sebelumnya)</a></li>
                <li <?=selected("sm_sp2021")?>><a href="sm_sp2021.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2021</a></li> 
                <li <?=selected("sm_sp2022")?>><a href="sm_sp2022.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2022</a></li> 
                <li <?=selected("sm_sp2023")?>><a href="sm_sp2023.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2023</a></li> 
                <li <?=selected("sm_sp2024")?>><a href="sm_sp2024.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2024</a></li> 
                <li <?=selected("sm_sp2025")?>><a href="sm_sp2025.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2025</a></li> 
                <li <?=selected("sm_sp2026")?>><a href="sm_sp2026.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2026</a></li> 
              </ul>
            </li>
            <li class="dropdown-submenu"><a href="#"><i class="fa fa-user nav-icon"></i> SK</a>
              <ul class="dropdown-menu">
                <li <?=selected("sm_sk2020")?>><a href="sm_sk2020.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2020&nbsp;(+thn&nbsp;sebelumnya)</a></li>
                <li <?=selected("sm_sk2021")?>><a href="sm_sk2021.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2021</a></li> 
                <li <?=selected("sm_sk2022")?>><a href="sm_sk2022.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2022</a></li> 
                <li <?=selected("sm_sk2023")?>><a href="sm_sk2023.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2023</a></li> 
                <li <?=selected("sm_sk2024")?>><a href="sm_sk2024.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2024</a></li> 
                <li <?=selected("sm_sk2025")?>><a href="sm_sk2025.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2025</a></li> 
                <li <?=selected("sm_sk2026")?>><a href="sm_sk2026.php"><i class="fa fa-bar-chart-o"></i> &nbsp;&nbsp;2026</a></li> 
              </ul>
	    </li>
          </ul>
        </li>
        <!-- SP & SK -->
        <li class="dropdown <?php if (selectedSub("m_ppp") or selectedSub("sm_ppp_internal") or selectedSub("sm_ppp_eksternal")) ?>"><a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
          <i class="fa fa-suitcase"></i> Peraturan Perundangan&nbsp;<span class="caret"></span></a>
          <ul class="dropdown-menu">   
            <li <?=selected("sm_ppp_internal")?>><a href="sm_ppp_internal.php"><i class="fa fa-bar-chart-o"></i> Evaluasi Pematuhan Perundangan </a></li>
            <li <?=selected("sm_ppp_eksternal")?>><a href="sm_ppp_eksternal.php"><i class="fa fa-bar-chart-o"></i> Daftar Peraturan Perundangan </a></li> 
          </ul>
        </li>
        <!-- PPP -->
	<!--        <li <?=selected("m_news")?>><a href="m_news.php"><i class="fa fa-tasks"></i> Berita & Informasi</a></li> -->
        <!-- Berita & Informasi -->
        <li <?=selected("m_contact")?>><a href="m_contact.php"><i class="fa fa-phone"></i> Contact</a></li>
        <!-- Contact -->
      </ul>
    </div> <!-- /.navbar-collapse -->   
  </div> <!-- /.container --> 
</div> <!-- /.mainbar -->

<?php
function selected($requestUri){
    $file_name = basename($_SERVER['REQUEST_URI'], ".php");

    if ($file_name == $requestUri){
      echo 'class="active"';
    }
}
function selectedSub($requestUri){
    $file_name = basename($_SERVER['REQUEST_URI'], ".php");

    if ($file_name == $requestUri){
      echo 'active';
    }
}
?>

<div class="container">
  <div class="content">
    <div class="content-container">
      <div class="content-header">
        <h2 class="content-header-title">Quality Management</h2>
        <ol class="breadcrumb">
          <li><a href="index.php">Home</a></li>
          <?php if (breadcrumb("index") 
                 or breadcrumb(basename($_SERVER['REQUEST_URI']))
                 // Dashboard
                 or breadcrumb("sm_panduan_cip") 
                 or breadcrumb("sm_contoh_cip_pkm") 
                 or breadcrumb("sm_contoh_cip_gkm") 
                 or breadcrumb("sm_contoh_cip_ss") 
                 or breadcrumb("sm_klinik_cip") 
                 or breadcrumb("sm_coe") 
                 or breadcrumb("sm_list_gugus") 
                 or breadcrumb("sm_add_gugus")
                 // CIP
                 or breadcrumb("sm_kebijakan_sm") 
                 or breadcrumb("sm_requirement_9001") 
                 or breadcrumb("sm_requirement_14001") 
                 or breadcrumb("sm_requirement_18001") 
                 or breadcrumb("sm_requirement_smp") 
                 or breadcrumb("sm_requirement_mkp") 
                 or breadcrumb("sm_ia_temuan_2012") 
                 or breadcrumb("sm_ia_temuan_2013") 
                 or breadcrumb("sm_ia_temuan_2014") 
                 or breadcrumb("sm_ia_tl_2012") 
                 or breadcrumb("sm_ia_tl_2013") 
                 or breadcrumb("sm_ia_tl_2014") 
                 or breadcrumb("sm_sa_temuan_2012") 
                 or breadcrumb("sm_sa_temuan_2013") 
                 or breadcrumb("sm_sa_temuan_2014") 
                 or breadcrumb("sm_sa_tl_2012") 
                 or breadcrumb("sm_sa_tl_2013") 
                 or breadcrumb("sm_sa_tl_2014") 
                 or breadcrumb("sm_hiradc") 
                 or breadcrumb("sm_daftar_catatan") 
                 or breadcrumb("sm_rtm") 
                 or breadcrumb("sm_proses_bisnis")
                 // Sistem Managemen
                 or breadcrumb("sm_fs_tki") 
                 or breadcrumb("sm_fs_tko") 
                 or breadcrumb("sm_fs_lain")
                 // STK
                 or breadcrumb("sm_kkep_2010") 
                 or breadcrumb("sm_kkep_2012") 
                 or breadcrumb("sm_kkep_2014")
                 // KKEP-PQA
                 or breadcrumb("sm_contoh_komet") 
                 or breadcrumb("sm_ef") 
                 or breadcrumb("sm_df") 
                 or breadcrumb("sm_cop") 
                 or breadcrumb("sm_cei") 
                 or breadcrumb("sm_ap")
                 // Komet
                 or breadcrumb("sm_sp2020") 
                 or breadcrumb("sm_sp2021") 
                 or breadcrumb("sm_sp2022")
                 or breadcrumb("sm_sp2023")
                 or breadcrumb("sm_sp2024")
                 or breadcrumb("sm_sk2020") 
                 or breadcrumb("sm_sk2021") 
                 or breadcrumb("sm_sk2022")
                 or breadcrumb("sm_sk2023")
                 or breadcrumb("sm_sk2024")
                 or breadcrumb("sm_sp2025")
                 or breadcrumb("sm_sk2025")
                 or breadcrumb("sm_sp2026")
                 or breadcrumb("sm_sk2026")
                 // SP & SK
                 or breadcrumb("m_ppp") 
                 or breadcrumb("m_news") 
                 or breadcrumb("m_contact") 
                 or breadcrumb("m_profile") 
                 or breadcrumb("search")) 
                 // Additional
          ?>
        </ol>
      </div> <!-- /.content-header -->

<?php
function breadcrumb($requestUri){
    $file_name = basename($_SERVER['REQUEST_URI'], ".php");

    if ($file_name == $requestUri){
      if ($requestUri == 'index') {
        echo ('<li class="active">Kebijakan Sistem Managemen Terpadu (SMT) - PT. Pertamina Patra Niaga RU Dumai</li>');
      // Dashboard
      } else if ($requestUri == 'sm_panduan_cip') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active">Panduan CIP</li>');
      } else if ($requestUri == 'sm_contoh_cip_pkm') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active">Contoh CIP PKM</li>');
      } else if ($requestUri == 'sm_contoh_cip_gkm') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active">Contoh CIP GKM</li>');
      } else if ($requestUri == 'sm_contoh_cip_ss') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active">Contoh CIP SS</li>');
      } else if ($requestUri == 'sm_klinik_cip') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active"> Klini CIP</li>');
      } else if ($requestUri == 'sm_coe') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active">Calnder of Event</li>');
      } else if ($requestUri == 'sm_list_gugus') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active">List Gugus</li>');
      } else if ($requestUri == 'sm_add_gugus') {
        echo ('<li><a href="javascript:;">CIP</a></li><li class="active">Add Gugus</li>');
      // CIP
      } else if ($requestUri == 'sm_kebijakan_sm') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Kebijakan Sistem Managemen</li>');
      } else if ($requestUri == 'sm_requirement_9001') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Requirement 9001</li>');
      } else if ($requestUri == 'sm_requirement_14001') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Requirement 14001</li>');
      } else if ($requestUri == 'sm_requirement_18001') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Requirement 18001</li>');
      } else if ($requestUri == 'sm_requirement_smp') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Requirement SMP</li>');
      } else if ($requestUri == 'sm_requirement_mkp') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Requirement MKP</li>');
      } else if ($requestUri == 'sm_ia_temuan_2012') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Internal Audit</a></li><li class="active">Temuan 2012</li>');
      } else if ($requestUri == 'sm_ia_temuan_2013') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Internal Audit</a></li><li class="active">Temuan 2013</li>');
      } else if ($requestUri == 'sm_ia_temuan_2014') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Internal Audit</a></li><li class="active">Temuan 2014</li>');
      } else if ($requestUri == 'sm_ia_tl_2012') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Internal Audit</a></li><li class="active">Tindak Lanjut 2012</li>');
      } else if ($requestUri == 'sm_ia_tl_2013') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Internal Audit</a></li><li class="active">Tindak Lanjut 2013</li>');
      } else if ($requestUri == 'sm_ia_tl_2014') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Internal Audit</a></li><li class="active">Tindak Lanjut 2014</li>');
      } else if ($requestUri == 'sm_sa_temuan_2012') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Surveillance Audit</a></li><li class="active">Temuan 2012</li>');
      } else if ($requestUri == 'sm_sa_temuan_2013') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Surveillance Audit</a></li><li class="active">Temuan 2013</li>');
      } else if ($requestUri == 'sm_sa_temuan_2014') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Surveillance Audit</a></li><li class="active">Temuan 2014</li>');
      } else if ($requestUri == 'sm_sa_tl_2012') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Surveillance Audit</a></li><li class="active">Tindak Lanjut 2012</li>');
      } else if ($requestUri == 'sm_sa_tl_2013') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Surveillance Audit</a></li><li class="active">Tindak Lanjut 2013</li>');
      } else if ($requestUri == 'sm_sa_tl_2014') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li><a href="javascript:;">Surveillance Audit</a></li><li class="active">Tindak Lanjut 2014</li>');
      } else if ($requestUri == 'sm_hiradc') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">HIRADC</li>');
      } else if ($requestUri == 'sm_daftar_catatan') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Daftar Catatan & Rekaman Fungsi</li>');
      } else if ($requestUri == 'sm_rtm') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Rapat Tinjauan Managemen</li>');
      } else if ($requestUri == 'sm_proses_bisnis') {
        echo ('<li><a href="javascript:;">Sistem Managemen</a></li><li class="active">Proses Bisnis</li>');
      // Sistem Managemen
      } else if ($requestUri == 'sm_fs_tki') {
        echo ('<li><a href="javascript:;">STK</a></li><li class="active">Form Standar TKI</li>');
      } else if ($requestUri == 'sm_fs_tko') {
        echo ('<li><a href="javascript:;">STK</a></li><li class="active">Form Standar TKO</li>');
      } else if ($requestUri == 'sm_fs_lain') {
        echo ('<li><a href="javascript:;">STK</a></li><li class="active">Form Standar Lainnya</li>');
      // STK
      } else if ($requestUri == 'sm_kkep_2010') {
        echo ('<li><a href="javascript:;">KKEP-PQA</a></li><li class="active">2010</li>');
      } else if ($requestUri == 'sm_kkep_2012') {
        echo ('<li><a href="javascript:;">KKEP-PQA</a></li><li class="active">2012</li>');
      } else if ($requestUri == 'sm_kkep_2014') {
        echo ('<li><a href="javascript:;">KKEP-PQA</a></li><li class="active">2014</li>');
      // KKEP-PQA
      } else if ($requestUri == 'sm_contoh_komet') {
        echo ('<li><a href="javascript:;">Komet</a></li><li class="active">Contoh Komet</li>');
      } else if ($requestUri == 'sm_ef') {
        echo ('<li><a href="javascript:;">Komet</a></li><li class="active">Expert Form</li>');
      } else if ($requestUri == 'sm_df') {
        echo ('<li><a href="javascript:;">Komet</a></li><li class="active">Discussion Form</li>');
      } else if ($requestUri == 'sm_cop') {
        echo ('<li><a href="javascript:;">Komet</a></li><li class="active">CoP</li>');
      } else if ($requestUri == 'sm_cei') {
        echo ('<li><a href="javascript:;">Komet</a></li><li class="active">Converence Expert Interview</li>');
      } else if ($requestUri == 'sm_ap') {
        echo ('<li><a href="javascript:;">Komet</a></li><li class="active">Asset Pengetahuan</li>');
      // Komet
      } else if ($requestUri == 'sm_sp2020') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SP 2020</li>');
      } else if ($requestUri == 'sm_sp2021') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SP 2021</li>');
      } else if ($requestUri == 'sm_sp2022') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SP 2022</li>');
      } else if ($requestUri == 'sm_sp2023') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SP 2023</li>');
      } else if ($requestUri == 'sm_sp2024') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SP 2024</li>');
      } else if ($requestUri == 'sm_sp2025') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SP 2025</li>');
      } else if ($requestUri == 'sm_sp2026') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SP 2026</li>');
      } else if ($requestUri == 'sm_sk2020') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SK 2020</li>');
      } else if ($requestUri == 'sm_sk2021') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SK 2021</li>');
      } else if ($requestUri == 'sm_sk2022') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SK 2022</li>');
      } else if ($requestUri == 'sm_sk2023') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SK 2023</li>');
      } else if ($requestUri == 'sm_sk2024') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SK 2024</li>');
      } else if ($requestUri == 'sm_sk2025') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SK 2025</li>');
      } else if ($requestUri == 'sm_sk2026') {
        echo ('<li><a href="javascript:;">SP & SK</a></li><li class="active">SK 2026</li>');
      // SP & SK
      } else if ($requestUri == 'm_ppp') {
        echo ('<li class="active">PPP</li>');
      } else if ($requestUri == 'm_news') {
        echo ('<li class="active">Berita & Informasi</li>');
      } else if ($requestUri == 'm_contact') {
        echo ('<li class="active">Contact</li>');
      } else if ($requestUri == 'm_profile') {
        echo ('<li class="active">Profile</li>');
      } else if ($requestUri == 'search') {
        echo ('<li class="active">Search</li>');
      } else if ($requestUri == basename($_SERVER['REQUEST_URI'])) {
        echo ('<li class="active">Kebijakan Sistem Managemen Terpadu (SMT) - PT. Pertamina Patra Niaga RU Dumai</li>'); 
      // Additional
      }
    }
  }
?>
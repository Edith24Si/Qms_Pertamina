<?php
include('admin/include/config.php');
include('include/cek-login.php');
?>

<!DOCTYPE html>
<head>
  <title>Quality Management System - PT. PNN RU Dumai</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="admin/assets/img/favicon.gif" type="image/gif">

  <link rel="stylesheet" href="admin/assets/css/no__font-awesome.min.css">
  <link rel="stylesheet" href="admin/assets/css/bootstrap.min.css">

  <!-- Plugin CSS -->
  <link rel="stylesheet" href="admin/assets/js/plugins/icheck/skins/minimal/blue.css">
  <link rel="stylesheet" href="admin/assets/js/plugins/select2/select2.css">
  <link rel="stylesheet" href="admin/assets/js/plugins/morris/morris.css">
  <link rel="stylesheet" href="admin/assets/js/plugins/fileupload/bootstrap-fileupload.css">
  <link rel="stylesheet" href="admin/assets/js/plugins/magnific/magnific-popup.css">

  <!-- App CSS -->
  <link rel="stylesheet" href="admin/assets/css/target-admin.css">

  <!-- Plugin JS -->
  <script src="admin/assets/js/libs/jquery-1.10.1.min.js"></script>
  
  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="admin/assets/js/libs/html5shiv.js"></script>
  <script src="admin/assets/js/libs/respond.js"></script>
  <![endif]-->
</head>
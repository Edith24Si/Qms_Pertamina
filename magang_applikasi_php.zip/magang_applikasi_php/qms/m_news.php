<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
         	<h3><i class='fa fa-bar-chart-o'></i> News </h3>
            <!-- <h3><i class="fa fa-bar-chart-o"></i> Dashboard - </h3> -->
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
<!-- 
            <?php 
            $query = mysql_query("select * from tb_news");
            while ($data = mysql_fetch_array($query)) {
            ?>
            <h4><b><a href="#"><?php echo $data['title'];?></a></b></h4>
            <hr>
            <img src="admin/assets/img/news_dir/<?php echo $data['pictures'];?>" width="125" alt="Gallery Image" />
            <p>
               <?php echo $data['content'];?>
            </p>
            <?php
            }
            ?>
             -->
            
            <?php 
			   include('include/parse.php'); 
            ?>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('template/side.php');
include('template/footer.php');
?>
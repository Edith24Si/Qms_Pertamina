<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>
<div class="row">
   <?php 
   $query = mysql_query("select * from tb_upload");
   $rows = mysql_num_rows($query);
   echo ("
   <div class='col-sm-6 col-md-3'>
      <div class='row-stat dash'>
         <p class='row-stat-label'>Total Data List</p>
         <h3 class='row-stat-value'>$rows</h3>
         <a href='m_list.php' type='button' class='btn btn-success btn-xs'>Files</a>
      </div>
   </div>
   ");
   ?>

   <?php /*
   $query = mysql_query("select * from tb_comment");
   $com =  mysql_num_rows($query);
   $query = mysql_query("select * from tb_comment where ket='reset' and status='N'");
   $rows = mysql_num_rows($query);
   echo ("
   <div class='col-sm-6 col-md-3'>
      <div class='row-stat dash'>
         <p class='row-stat-label'>Total Comment</p>
         <h3 class='row-stat-value'>$com</h3>
         <a href='m_comment.php' type='button' class='btn btn-default btn-xs'>Comment</a>
         <h3 class='row-stat-value'> &nbsp;&nbsp;&&nbsp;&nbsp; </h3><br>
         <h3 class='row-stat-value'>$rows</h3>
         <a href='m_comment.php' type='button' class='btn btn-info btn-xs'>Reset</a>
      </div>
   </div>
   ");*/
   ?>

   <?php 
   $query = mysql_query("select * from tb_employee_baru");
   $rows =  mysql_num_rows($query);
   $query = mysql_query("select * from tb_user where username!='idell'");
   $admn = mysql_num_rows($query);
   echo ("
   <div class='col-sm-6 col-md-3'>
      <div class='row-stat dash'>
         <p class='row-stat-label'>Total Employee</p>
         <h3 class='row-stat-value'>$rows</h3>
         <a href='m_list_employee.php' type='button' class='btn btn-warning btn-xs'>Employee</a>
         <h3 class='row-stat-value'> &nbsp;&nbsp;&&nbsp;&nbsp; </h3><br>
         <h3 class='row-stat-value'>$admn</h3>
         <a href='m_comment.php' type='button' class='btn btn-info btn-xs'>Admin</a>
      </div>
   </div>
   ");
   ?>

   <?php 
   $query = mysql_query("select * from tb_gugus where acc = 'N'");
   $rows = mysql_num_rows($query);
   echo ("
   <div class='col-sm-6 col-md-3'>
      <div class='row-stat dash'>
         <p class='row-stat-label'>New Gugus</p>
         <h3 class='row-stat-value'>$rows</h3>
		 <a href='m_acc_gugus.php' type='button' class='btn btn-primary btn-xs'>New Gugus</a>
      </div>
   </div>
   ");
   ?>
</div> <!-- /.row -->
<hr>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
         	<?php echo "<h3><i class='fa fa-bar-chart-o'></i> Dashboard - ".$_SESSION['admin']."</h3>"; ?>
            <!-- <h3><i class="fa fa-bar-chart-o"></i> Dashboard - </h3> -->
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
			<br>
			<center><p>Selamat datang di Admin Page website Quality Management System</p></center>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->
<?php 
include('/template/side.php');
include('/template/footer.php');
?>
<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-upload"></i> Upload Data </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
         	<form class="form-horizontal" role="form" enctype="multipart/form-data"  name="upload_data" action="include/insert.php" method="post">
            <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'success') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully create news. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail') {
              echo '<div class="alert alert-danger"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Oh snap!</strong> Change a few things up and try submitting again.
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail-format') {
              echo '<div class="alert alert-warning"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Warning!</strong> Best check yo self, you are not looking too good. Format not accessible.
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail-null') {
              echo '<div class="alert alert-danger"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Oh snap!</strong> Change a few things up and try submitting again. File Empty!
              </div>';
            }
            ?>
            <div class="form-group">
              <label class="col-md-3">Pilih File</label>

              <div class="col-md-8">
                <div class="fileupload fileupload-new" data-provides="fileupload">
                  <div class="input-group">
                    <div class="form-control"><i class="fa fa-file fileupload-exists"></i> <span class="fileupload-preview"></span></div>
                    <div class="input-group-btn">
                      <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                      <span class="btn btn-default btn-file">
                        <span class="fileupload-new">Select file</span>
                        <span class="fileupload-exists">Change</span>
                        <input type="file" name="myfile"/>
                      </span>
                    </div>
                  </div>
                </div> 
              </div>

              <label class="col-md-3">Nama Folder</label>
              <div class="col-md-8">
                <select id="s2_basic" name="dir_id" class="form-control">
                  <option selected></option>
                <?php 
                  $query = mysql_query("select * from tb_menu order by menu asc, submenu asc");
                  while ($data = mysql_fetch_array($query)) {
                    print("<option value=$data[menu_id]>$data[menu]");
                    if ($data['submenu']!=null) {
                      print(" - $data[submenu] </option>");
                    } 
                  }
                ?>
	              </select>
	            </div>
            </div>

            <div class="col-md-9"></div>
            <button type="submit" name="upload-data" class="btn btn-primary col-md-2"></span>Upload&nbsp;&nbsp; <span class="fa fa-upload"></button>
          </form>
        </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
    </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
    </div> <!-- /.content-container -->      
  </div> <!-- /.content -->
</div> <!-- /.container -->

<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="footstr1">
          <p class="p-footstr1">
            <span class="fa fa-map-marker"></span>&nbsp;&nbsp;&nbsp;
            Head Office : Jalan Puteri Tujuh Dumai - Riau, 28813 <br>
            <span class="fa fa-phone"></span>&nbsp;
            Telp. (0765)31244 Fax. (0765)31532
          </p>
        </div>
        <div class="footstr2">
          <p class="p-footstr2">
            Copyright &copy; 2014 - PT. Pertamina Patra Niaga Refinery Unit Dumai
          </p>
        </div>
        <div class="footimg">
          <a href="index.php"><img src="assets/img/pertamina.png" alt="Site Logo"></a>
        </div>
      </div> <!-- /.col -->
    </div> <!-- /.row -->
  </div> <!-- /.container -->
  <div class="str2"></div>
</footer>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">About</h4>
      </div>
      <div class="modal-body">
        <p>Selamat datang di website Quality Management System V.2.0</p>
        <p>Semoga website ini dapat sedikit meringankan kerja anda. Mohon kritik dan saran demi kemajuan website ini. Terimakasih!</p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div><!-- modal-content -->
  </div><!-- modal-dialog -->
</div><!-- modal -->

  <script src="assets/js/libs/jquery-1.10.1.min.js"></script>
  <script src="assets/js/libs/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="assets/js/libs/bootstrap.min.js"></script>

  <!--[if lt IE 9]>
  <script src="assets/js/libs/excanvas.compiled.js"></script>
  <![endif]-->
  
  <!-- Plugin JS -->
  <script src="assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="assets/js/plugins/datatables/DT_bootstrap.js"></script>
  <script src="assets/js/plugins/tableCheckable/jquery.tableCheckable.js"></script>

  <script src="assets/js/plugins/datepicker/bootstrap-datepicker.js"></script>
  <script src="assets/js/plugins/timepicker/bootstrap-timepicker.js"></script>
  <script src="assets/js/plugins/simplecolorpicker/jquery.simplecolorpicker.js"></script>
  <script src="assets/js/plugins/autosize/jquery.autosize.min.js"></script>
  <script src="assets/js/plugins/textarea-counter/jquery.textarea-counter.js"></script>
  <script src="assets/js/plugins/icheck/jquery.icheck.js"></script>
  <script src="assets/js/plugins/select2/select2.js"></script>
  <script src="assets/js/libs/raphael-2.1.2.min.js"></script>
  <script src="assets/js/plugins/morris/morris.min.js"></script>
  <script src="assets/js/plugins/sparkline/jquery.sparkline.min.js"></script>
  <script src="assets/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="assets/js/plugins/fullcalendar/fullcalendar.min.js"></script>
  <script src="assets/js/plugins/fileupload/bootstrap-fileupload.js"></script>
  <script src="assets/js/plugins/magnific/jquery.magnific-popup.min.js"></script>

  <!-- App JS -->
  <script src="assets/js/target-admin.js"></script>
  
  <!-- Plugin JS -->
  <script src="assets/js/demos/dashboard.js"></script>
  <script src="assets/js/demos/form-extended.js"></script> 
  <script src="assets/js/demos/ui-notifications.js"></script>
</body>
</html>
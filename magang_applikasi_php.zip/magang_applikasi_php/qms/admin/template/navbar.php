<body>
  <div class="navbar">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <i class="fa fa-cogs"></i>
      </button>      
      <a class="navbar-brand navbar-brand-image" href="index.php">
        <img src="assets/img/logo.jpg" alt="Site Logo">
      </a>
    </div> <!-- /.navbar-header -->

    <div class="navbar-collapse collapse"> 
      <ul class="nav navbar-nav navbar-right">   
        <li><a data-toggle="modal" data-target="#myModal" style="cursor:pointer;"> About</a></li>    
        <!-- About -->

        <li class="dropdown navbar-profile"><a class="dropdown-toggle" data-toggle="dropdown" href="javascript:;">
            <img src="assets/img/avatars/avatar.png" class="navbar-profile-avatar" alt=""><span class="navbar-profile-label">rod@rod.me &nbsp;</span><i class="fa fa-caret-down"></i></a>

          <ul class="dropdown-menu" role="menu">
            <?php echo "<li class='dropdown-header'><center>".$_SESSION['admin']."</center></li>"; ?>
            <li class="divider"></li>
            <li><a href="m_profile.php"><i class="fa fa-user"></i> &nbsp;&nbsp;My Profile</a></li>
            <li class="divider"></li>
            <li><a href="logout.php"><i class="fa fa-sign-out"></i> &nbsp;&nbsp;Logout</a></li>
          </ul>
        </li>

      </ul>
    </div> <!-- navbar-collapse -->
  </div> <!-- /.container -->

</div> <!-- /.navbar -->
  <div class="mainbar">
  <div class="container">
    <button type="button" class="btn mainbar-toggle" data-toggle="collapse" data-target=".mainbar-collapse">
      <i class="fa fa-bars"></i>
    </button>

    <div class="mainbar-collapse collapse">
      <ul class="nav navbar-nav mainbar-nav">
        <li  <?php if (selected("index") or selected(basename($_SERVER['REQUEST_URI']))) ?>><a href="index.php"><i class="fa fa-home"></i> &nbsp;&nbsp;Home&nbsp;&nbsp;</a></li>
        <!-- Home -->
        <li <?=selected("m_upload")?>><a href="m_upload.php" ><i class="fa fa-upload"></i> Upload Data</a></li>
        <!-- Upload Data -->
        <li <?=selected("m_list")?>><a href="m_list.php" ><i class="fa fa-trash-o"></i> Data List</a></li>
        <!-- Hapus Data -->
<!--
        <li <?=selected("m_news")?>><a href="m_news.php"><i class="fa fa-tasks"></i> Berita </a></li>
-->        <!-- Berita -->
<!--
        <li <?=selected("m_comment")?>><a href="m_comment.php"><i class="fa fa-comment"></i> Komentar </a></li>
-->        <!-- Komentar -->
        <li <?=selected("m_add_user")?>><a href="m_add_user.php"><i class="fa fa-user"></i> Add Admin </a></li>
        <!-- Add Admin -->
        <li <?php if (selected("m_list_employee") or selected("m_employee")) ?>><a href="m_list_employee.php"><i class="fa fa-users"></i> Employee List </a></li>
        <!-- Employee List -->
        <li <?=selected("m_acc_gugus")?>><a href="m_acc_gugus.php"><i class="fa fa-check-square-o"></i> Acc Gugus </a></li>
        <!-- Acc Gugus -->
      </ul>
    </div> <!-- /.navbar-collapse -->   
  </div> <!-- /.container --> 
</div> <!-- /.mainbar -->

<?php
function selected($requestUri){
    $file_name = basename($_SERVER['REQUEST_URI'], ".php");

    if ($file_name == $requestUri){
      echo 'class="active"';
    }
}
?>

<div class="container">
  <div class="content">
    <div class="content-container">

      <div class="content-header">
        <h2 class="content-header-title">Quality Management</h2>
        <ol class="breadcrumb">
          <li><a href="index.php">Home</a></li>
          <?php if (breadcrumb("index") 
                 or breadcrumb(basename($_SERVER['REQUEST_URI']))
                 or breadcrumb("m_upload") 
                 or breadcrumb("m_list") 
/*                 or breadcrumb("m_news") */
                 or breadcrumb("m_comment") 
                 or breadcrumb("m_add_user") 
                 or breadcrumb("m_list_employee") 
                 or breadcrumb("m_employee") 
                 or breadcrumb("m_acc_gugus") 
                 or breadcrumb("m_profile") 
                 or breadcrumb("search")) 
          ?>
        </ol>
      </div> <!-- /.content-header -->

<?php
function breadcrumb($requestUri){
    $file_name = basename($_SERVER['REQUEST_URI'], ".php");

    if ($file_name == $requestUri){
      if ($requestUri == 'index') {
        echo ('<li class="active">Dashboard Quality Management System - PT. Pertamina Patra Niaga RU Dumai</li>');
      } else if ($requestUri == 'm_upload') {
        echo ('<li class="active">Upload Data</li>');
      } else if ($requestUri == 'm_list') {
        echo ('<li class="active">Data List</li>');
/*      } else if ($requestUri == 'm_news') {
        echo ('<li class="active">Berita</li>');	*/
      } else if ($requestUri == 'm_comment') {
        echo ('<li class="active">Komentar</li>');
      } else if ($requestUri == 'm_add_user') {
        echo ('<li class="active">Add Admin</li>');
      } else if ($requestUri == 'm_list_employee') {
        echo ('<li class="active">Employee List</li>');
      } else if ($requestUri == 'm_employee') {
        echo ('<li class="active">Add Employee</li>');
      } else if ($requestUri == 'm_acc_gugus') {
        echo ('<li class="active">ACC Gugus</li>');
      } else if ($requestUri == 'm_profile') {
        echo ('<li class="active">Profile</li>');
      } else if ($requestUri == 'search') {
        echo ('<li class="active">Search</li>');
      } else if ($requestUri == basename($_SERVER['REQUEST_URI'])) {
        echo ('<li class="active">Dashboard Quality Management System - PNN RU Dumai</li>');
      }
    }
  }
?>
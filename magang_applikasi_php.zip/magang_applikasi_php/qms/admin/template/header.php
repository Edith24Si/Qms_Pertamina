<?php
include('include/config.php');
include('include/cek-login.php');
?>

<!DOCTYPE html>
<head>
  <title>Quality Management System - PT. PNN RU Dumai</title>

  <meta charset="utf-8">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="assets/img/favicon.gif" type="image/gif">

  <link rel="stylesheet" href="assets/css/no__font-awesome.min.css">
  <link rel="stylesheet" href="assets/js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.min.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">

  <!-- Plugin CSS -->
  <link rel="stylesheet" href="assets/js/plugins/icheck/skins/minimal/blue.css">
  <link rel="stylesheet" href="assets/js/plugins/select2/select2.css">
  <link rel="stylesheet" href="assets/js/plugins/morris/morris.css">
  <link rel="stylesheet" href="assets/js/plugins/fileupload/bootstrap-fileupload.css">

  <!-- App CSS -->
  <link rel="stylesheet" href="assets/css/target-admin.css">
  
  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="assets/js/libs/html5shiv.js"></script>
  <script src="assets/js/libs/respond.js"></script>
  <![endif]-->

  <!-- Plugin JS -->
  <script type="text/javascript">
  function showUser(str) {
    if (str=="") {
      document.getElementById("txtHint").innerHTML="";
      return;
    }
    if (window.XMLHttpRequest) {
      // code for IE7+, Firefox, Chrome, Opera, Safari
      xmlhttp=new XMLHttpRequest();
    } else { // code for IE6, IE5
      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function() {
      if (xmlhttp.readyState==4 && xmlhttp.status==200) {
        document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
      }
    }
    xmlhttp.open("GET","include/filter.php?id="+str,true);
    xmlhttp.send();
  }
  </script>
</head>
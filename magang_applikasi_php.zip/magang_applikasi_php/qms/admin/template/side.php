   <div class="col-md-4">

   	  <form action="search.php" class="form" method="post">
        <div class="input-group">
          <input type="text" name="word" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
            <button class="btn btn-primary" type="submit">
              <i class="fa fa-search"></i><img src="assets/img/search.png">
            </button>
          </span>
        </div><!-- /input-group -->
      </form>
      <br>
      
      <div class="portlet">
        <div class="portlet-header">
          <h3><i class="fa fa-bar-chart-o"></i> Mutu Kerja </h3>
        </div> <!-- /.portlet-header -->

        <div class="portlet-content">
          <div id="mutukerja"></div>
        </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->
</div> <!-- /.row -->
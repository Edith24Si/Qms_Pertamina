<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-archive"></i> Data List</h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
         	<form class="form-horizontal" role="form">
			<?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'delete') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully Delete File Data. 
              </div>';
			}
			?>
			      <div class="form-group">
              <label class="col-md-3">Nama Folder</label>

              <div class="col-md-9">
	              <select id="s2_basic" name="menu_list" class="form-control" onchange="showUser(this.value)">
                  <option selected></option>
                <?php 
                  $query = mysql_query("select * from tb_menu");
                  while ($data = mysql_fetch_array($query)) {
                    print("<option value=$data[menu_id]>$data[menu]");
                    if ($data['submenu']!=null) {
                      print(" - $data[submenu] </option>");
                    } 
                  }
                ?>
                </select>
	            </div>
				      <br><br><div id="hr"></div>
        	  </div>
            <div id="txtHint">Data info will be listed here. Please select category!</div>
		      </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('/template/side.php');
include('/template/footer.php');
?>
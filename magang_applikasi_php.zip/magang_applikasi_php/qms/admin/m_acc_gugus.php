<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-check-square-o"></i> Acc Gugus </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
         	<div class="alert alert-info"> 
	            Klik nama gugus untuk melihat daftar anggota gugus!
	          </div>
         	<div class="col-md-12">
              <div class="table-responsive">

              <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Pembuat Gugus</th>
                      <th>Nama Gugus </th>
                      <th>Kategori</th>
                      <th>Judul</th>
                      <th>Telp</th>
                      <th>Option </th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $query = mysql_query("select * from tb_gugus where acc='N'");
                    $no = 1;
                    while ($data = mysql_fetch_array($query)) {
                    ?>
                    <tr>
                      <td><?php echo $no; ?></td>
                      <td><?php echo $data['creator']; ?></td>
                      <td><?php echo "<a href='sm_view_gugus.php?id=".$data['id_gugus']."&module=daftar'> $data[nama_gugus] </a>"; ?></td>
                      <td><?php echo $data['category_gugus']; ?></td>
                      <td><?php echo $data['title']; ?></td>
                      <td><?php echo $data['telp']; ?></td>
                      <td class="text-center" width="14%">					  
                        <a class="btn btn-xs btn-secondary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Acc Gugus" href="include/verify.php?id=<?php echo $data['id_gugus'].'&module=acc'; ?>"><i class="fa fa-check"></i><img src="assets/img/acc.png"></a>
                        &nbsp;
                        <a class="btn btn-xs btn-primary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Delete" href="include/verify.php?id=<?php echo $data['id_gugus'].'&module=delete'; ?>"><i class="fa fa-times"></i><img src="assets/img/delete.png"></a>
                      </td>
                      <?php
                      $no++;
                      } 
                      ?>
                    </tr>
                  </tbody>
                </table>    

              </div> <!-- /.table-responsive -->
              <br><div id="hr"></div>
              <div class="alert alert-info"> 
	             Nama Gugus yang telah disetujui!
	          </div>
              <div class="table-responsive">

              <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Pembuat Gugus</th>
                      <th>Nama Gugus </th>
                      <th>Kategori</th>
                      <th>Judul</th>
                      <th>Telp</th>
                      <th>Option </th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $query = mysql_query("select * from tb_gugus where acc='Y'");
                    $no = 1;
                    while ($data = mysql_fetch_array($query)) {
                    ?>
                    <tr>
                      <td><?php echo $no; ?></td>
                      <td><?php echo $data['creator']; ?></td>
                      <td><?php echo "<a href='sm_view_gugus.php?id=".$data['id_gugus']."&module=daftar'> $data[nama_gugus] </a>"; ?></td>
                      <td><?php echo $data['category_gugus']; ?></td>
                      <td><?php echo $data['title']; ?></td>
                      <td><?php echo $data['telp']; ?></td>
                      <td class="text-center" width="14%">					  
                        <a class="btn btn-xs btn-primary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Delete" href="include/verify.php?id=<?php echo $data['id_gugus'].'&module=delete'; ?>"><i class="fa fa-times"></i><img src="assets/img/delete.png"></a>
                      </td>
                      <?php
                      $no++;
                      } 
                      ?>
                    </tr>
                  </tbody>
                </table>    

              </div> <!-- /.table-responsive -->
              </div>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('/template/side.php');
include('/template/footer.php');
?>
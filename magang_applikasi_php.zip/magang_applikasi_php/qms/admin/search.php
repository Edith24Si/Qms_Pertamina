<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
  <div class="col-md-8">
    <div class="portlet">
      <div class="portlet-header">
        <h3><i class="fa fa-search"></i> Pencarian </h3>
      </div> <!-- /.portlet-header -->
      <div class="portlet-content">
        <div class="col-md-12">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="10" data-paginate="true" data-info="true">
              <thead>
                <tr>
                  <th><center>No</center></th>
                  <th><center>Title</center></th>
                  <th><center>Type</center></th>
                  <th><center>Detail</center></th>
                  <th><center>Opsi</center></th>
                </tr>
              </thead>
              <tbody>
                  <?php
                    $word = $_POST['word'];

                    $search = mysql_query("SELECT * FROM tb_upload WHERE file_name LIKE '%$word%'");
                    $result = mysql_num_rows($search);

                    if ($result > 0){
                      $no = 1;
                      while($data=mysql_fetch_array($search)){
                        $size=$data['size']/1000;
                  ?>
                <tr>
                  <td width="4%"><?php echo $no; ?></td>
                  <td><?php echo $data['file_name']; ?></td>
                  <td width="10%"><center> 
                    <?php
                      if ($data['type'] == 'application/msword') {
                        print("<img src=assets/img/doc.png>");
                      } else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                        print("<img src=assets/img/docx.png>");
                      } else if ($data['type'] == 'application/octet-stream') {
                        print("<img src=assets/img/docx.png>");
                      } else if ($data['type'] == 'application/pdf') {
                        print("<img src=assets/img/pdf.png>");
                      };
                    ?>
                  </center></td>
                  <td class="file-info" width="24%">
                    <span><strong>Size:</strong> <?php echo"$size";?> Kb</span> <br />
                    <span><strong>Format:</strong> 
                      <?php
                      if ($data['type'] == 'application/msword') {
                        print(".doc");
                      } else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                        print(".docx");
                      } else if ($data['type'] == 'application/octet-stream') {
                        print(".docx");
                      } else if ($data['type'] == 'application/pdf') {
                        print(".pdf");
                      };
                      ?>
                    </span> <br />
                    <span><strong>Uploader:</strong> <?php echo"$data[creator]";?></span>
                  </td>
                  <td width="8%">
                    <center><a class="btn btn-xs btn-success ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Download" href="include/download.php?id=<?php echo $data['upload_id']; ?>"><i class="fa fa-download"></i></a></center>
                  </td>
                  <?php
                  $no++;
                  } 
                  } else {
                    echo "<script language='javascript'>window.location = 'error-404.php'</script>";
                  }
                  ?>
                </tr>
              </tbody>
            </table>
          </div> <!-- /.table-responsive -->
        </div>
      </div> <!-- /.portlet-content -->
    </div> <!-- /.portlet -->
  </div> <!-- /.col -->

<?php 
include('template/side.php');
include('template/footer.php');
?>
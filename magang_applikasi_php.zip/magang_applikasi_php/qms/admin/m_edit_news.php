<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>
<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
          <h3><i class='fa fa-user'></i> Profile - <?php echo "$_SESSION[admin]"; ?> </h3>
         </div> <!-- /.portlet-header -->

         <?php 
         $id = $_GET['id'];
         $query = mysql_query("select * from tb_news where id_news='$id'") or die(mysql_error());
         $data = mysql_fetch_array($query);
         ?>

         <div class="portlet-content">
          <form class="form-horizontal" role="form" enctype="multipart/form-data"  name="update_profile" action="include/update.php?id=<?php echo "$_SESSION[admin_id]"; ?>" method="post"><br>
            <div class="form-group">
              <label class="col-md-3">Nomor Berita</label>

              <div class="col-md-6">
                 <input type="text" name="admin_id" class="form-control" value="<?php echo $data['id_news']; ?>" disabled>
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Judul</label>

              <div class="col-md-8">
                 <input type="text" name="title" class="form-control" value="<?php echo $data['title']; ?>">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Kategory</label>

              <div class="col-md-8">
                 <input type="text" name="category" class="form-control" value="<?php echo $data['category']; ?>" placeholder="News Category">
               </div>
            </div> <!-- Form Group -->
			<div class="form-group">
              <label class="col-md-3">Foto</label>

              <div class="col-md-4">
                 
                <div class="fileupload fileupload-new" data-provides="fileupload">
                  <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;"><img src="admin/<?php echo $data['pictures']; ?>" alt="Placeholder" /></div>
                  <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                  <div>
                    <span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input type="file" name="myfile"/></span>
                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                  </div>
                </div>

               </div>
            </div> <!-- Form Group -->
			<div class="form-group">
              <label class="col-md-3">Isi Berita</label>

              <div class="col-md-8">
                 <textarea id="as-ex-2" name="content" class="form-control" rows="3"><?php echo $data['content']; ?></textarea>
               </div>
            </div> <!-- Form Group -->
            <br><div id="hr"></div>
            <div class="col-md-9"></div>
            <button type="submit" name="gugus-upload" class="btn btn-primary col-md-2">Update&nbsp;&nbsp; <span class="fa fa-level-up"></span></button>
          </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
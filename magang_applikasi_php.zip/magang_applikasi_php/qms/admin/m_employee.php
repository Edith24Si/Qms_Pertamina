<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-users"></i> Add Employee </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
         	<form class="form-horizontal" role="form" name="input_data" action="include/insert.php" method="post">
            <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'success') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully adding data. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail') {
              echo '<div class="alert alert-warning"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Maaf</strong> Terjadi Kesalahan Dalam Membuat User. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'error') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Sorry!</strong> Employee Number was used!
              </div>';
            }
            ?>
			       <div class="form-group">
              <label class="col-md-3">Nomor Pegawai</label>

              <div class="col-md-5">
                 <input type="text" name="nopeg" class="form-control" required="required" placeholder="Employee Number">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Nama Pegawai</label>

              <div class="col-md-8">
                 <input type="text" name="emp_name" class="form-control" required="required" placeholder="Employee Name">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Password</label>

              <div class="col-md-8">
                 <input type="password" name="password" class="form-control" required="required" placeholder="Type Password">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Email</label>

              <div class="col-md-6">
                 <input type="email" name="mail" class="form-control" required="required" placeholder="">
               </div>
            </div> <!-- Form Group -->

            <div class="col-md-9"></div>
            <button type="submit" name="add-employee" class="btn btn-primary col-md-2"></span>Add&nbsp;&nbsp; <span class="fa fa-plus-square"></button>
          </form>

            <br><br><div id="hr"></div>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-user"></i> Add Admin </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
         	<form class="form-horizontal" role="form" name="input_data" action="include/insert.php" method="post">
            <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'success') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully adding data. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'delete') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully delete data. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail') {
              echo '<div class="alert alert-warning"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Maaf</strong> Terjadi Kesalahan Dalam Membuat User. 
              </div>';
            }
            ?>
			       <div class="form-group">
              <label class="col-md-3">Username</label>

              <div class="col-md-8">
                 <input type="text" name="username" class="form-control" required="required" placeholder="User Name">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Password</label>

              <div class="col-md-8">
                 <input type="text" name="password" class="form-control" required="required" placeholder="Password User">
               </div>
            </div> <!-- Form Group -->

            <div class="col-md-9"></div>
            <button type="submit" name="add-admin" class="btn btn-primary col-md-2"></span>Add&nbsp;&nbsp; <span class="fa fa-plus-square"></button>
          </form>

            <br><br><div id="hr"></div>
              <div class="col-md-12">
              <div class="table-responsive">

              <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Username</th>
                      <th>Option</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    //$query = mysql_query("select * from tb_user");
                    $query = mysql_query("select * from tb_user where username!='idell'");
                    $no = 1;
                    while ($data = mysql_fetch_array($query)) {
                    ?>
                    <tr>
                      <td width="12%"><?php echo $no; ?></td>
                      <td><?php echo $data['username']; ?></td>
                      <td class="text-center" width="12%">
                        <a class="btn btn-xs btn-primary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Delete" href="include/delete.php?id=<?php echo $data['id']; ?>&module=admin"><i class="fa fa-times"></i><img src="assets/img/delete.png"></a>
                      </td>
                      <?php
                      $no++;
                      } 
                      ?>
                    </tr>
                  </tbody>
                </table>    

              </div> <!-- /.table-responsive -->
              </div>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
<!DOCTYPE html>
<head>
  <title>Quality Management System - Pertamina Refenery Unit II Dumai</title>

  <meta charset="utf-8">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="assets/img/favicon.gif" type="image/gif">

  <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.min.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">

  <!-- Plugin CSS -->
  <link rel="stylesheet" href="assets/js/plugins/icheck/skins/minimal/blue.css">
  <link rel="stylesheet" href="assets/js/plugins/select2/select2.css">
  <link rel="stylesheet" href="assets/js/plugins/morris/morris.css">
  <link rel="stylesheet" href="assets/js/plugins/fileupload/bootstrap-fileupload.css">

  <!-- App CSS -->
  <link rel="stylesheet" href="assets/css/target-admin.css">
  
  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="assets/js/libs/html5shiv.js"></script>
  <script src="assets/js/libs/respond.js"></script>
  <![endif]-->

  <!-- Plugin JS -->
  <script type="text/javascript">
  function showUser(str) {
    if (str=="") {
      document.getElementById("txtHint").innerHTML="";
      return;
    }
    if (window.XMLHttpRequest) {
      // code for IE7+, Firefox, Chrome, Opera, Safari
      xmlhttp=new XMLHttpRequest();
    } else { // code for IE6, IE5
      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function() {
      if (xmlhttp.readyState==4 && xmlhttp.status==200) {
        document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
      }
    }
    xmlhttp.open("GET","include/filter.php?id="+str,true);
    xmlhttp.send();
  }
  </script>
</head>
<?php 
include('template/navbar.php');
?>
<div class="col-md-12">
  <div class="error-container">
    <div class="error-code">
      404
    </div> <!-- /.error-code -->

    <div class="error-details">
      <h4>Oops, You're lost.</h4>
      <p>We can not find the page you're looking for. Is there a typo in the url? Or try the search bar below</p>
      <form action="search.php" class="form" method="post">
        <div class="input-group">
          <input type="text" class="form-control" name="word" placeholder="Search...">
          <span class="input-group-btn">
            <button class="btn btn-primary" type="submit">
              <i class="fa fa-search"></i>
            </button>
          </span>
        </div><!-- /input-group -->
      </form>
    </div> <!-- /.error-details -->
  </div> <!-- /.error -->
</div> <!-- /.col-md-12 -->

<?php
include('template/footer.php');
?>
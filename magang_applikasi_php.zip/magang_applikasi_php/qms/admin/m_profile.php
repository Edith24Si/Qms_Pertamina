<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>
<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
          <h3><i class='fa fa-user'></i> Profile - <?php echo "$_SESSION[admin]"; ?> </h3>
         </div> <!-- /.portlet-header -->

         <?php 
         $id = $_SESSION['admin_id'];
         $query = mysql_query("select * from tb_user where id='$id'") or die(mysql_error());
         $data = mysql_fetch_array($query);
         ?>

         <div class="portlet-content">
          <form class="form-horizontal" role="form" enctype="multipart/form-data"  name="update_profile" action="include/update.php?id=<?php echo "$_SESSION[admin_id]"; ?>" method="post"><br>
            <div class="form-group">
              <label class="col-md-3">ID Admin</label>

              <div class="col-md-6">
                 <input type="text" name="admin_id" class="form-control" value="<?php echo $data['id']; ?>" disabled>
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Username</label>

              <div class="col-md-8">
                 <input type="text" name="username" class="form-control" value="<?php echo $data['username']; ?>">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">New Password</label>

              <div class="col-md-8">
                 <input type="password" name="password" class="form-control" placeholder="Change Password">
               </div>
            </div> <!-- Form Group -->
            <br><div id="hr"></div>
            <div class="col-md-9"></div>
            <button type="submit" name="gugus-upload" class="btn btn-primary col-md-2">Update&nbsp;&nbsp; <span class="fa fa-level-up"></span></button>
          </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
<?php 
include('template/header.php');
include('template/navbar.php');
include('include/fungsi_indotgl.php');
?>

<body>

<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-tasks"></i> Berita </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
         	<form class="form-horizontal" role="form" enctype="multipart/form-data"  name="input_berita" action="include/insert.php" method="post">
            <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'success') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully create news. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'delete') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully delete news. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail') {
              echo '<div class="alert alert-danger"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Oh snap!</strong> Change a few things up and try submitting again.
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail-format') {
              echo '<div class="alert alert-warning"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Warning!</strong> Best check yo self, you are not looking too good. Format not accessible.
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'fail-null') {
              echo '<div class="alert alert-danger"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Oh snap!</strong> Change a few things up and try submitting again. File Empty!
              </div>';
            }
            ?>
			      <div class="form-group">
              <label class="col-md-3">Judul Berita</label>

              <div class="col-md-8">
                 <input type="text" name="title" class="form-control" placeholder="Title">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Kategori</label>

              <div class="col-md-8">
                 <input type="text" name="category" class="form-control" placeholder="Category">
               </div>
            </div> <!-- Form Group -->
            <div class="form-group">
              <label class="col-md-3">Foto</label>

              <div class="col-md-4">
                 
                <div class="fileupload fileupload-new" data-provides="fileupload">
                  <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;"><img src="assets/img/no-img.gif" alt="Placeholder" /></div>
                  <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                  <div>
                    <span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span><input type="file" name="myfile"/></span>
                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                  </div>
                </div>

               </div>
            </div> <!-- Form Group -->
			<div class="form-group">
              <label class="col-md-3">Isi Berita</label>

              <div class="col-md-8">
                 <textarea id="as-ex-2" name="content" class="form-control" rows="3"></textarea>
               </div>
            </div> <!-- Form Group -->

            <div class="col-md-9"></div>
            <button type="submit" name="publish-news" class="btn btn-primary col-md-2"></span>Publish&nbsp;&nbsp; <span class="fa fa-share"></button>

            <br><br><div id="hr"></div>
	            <!-- <div class="col-md-12"> -->
              <div class="table-responsive">

              <table 
                class="table table-striped table-bordered table-hover" 
                data-provide="datatable" 
                data-display-rows="6"
                data-paginate="true"
                data-info="true"
              >
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Gambar</th>
                      <th>Judul & Isi</th>
                      <th>Tanggal</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $query = mysql_query("select * from tb_news");
                    $no = 1;
                    while ($data = mysql_fetch_array($query)) {
                    ?>
                    <tr>
                      <td><?php echo $no; ?></td>
                      <td>
                        <div class="thumbnail">
                          <div class="thumbnail-view">
                            <a class="thumbnail-view-hover ui-lightbox" href="qms/<?php echo $data['pictures']; ?>"></a>
                            <img src="qms/<?php echo $data['pictures']; ?>" width="125" alt="Gallery Image" />
                          </div>
                        </div> <!-- /.thumbnail -->
                      </td>
                      <td width="50%">
                        <a href="#" title=""><?php echo $data['title']; ?></a>
                        <p><?php echo $data['content']; ?></p>
                      </td>
                      <td width="14%"><center>
                        <p><b><?php echo $data['day'];?></b><br>
                        <?php echo  $tgl = tgl_indo($data['date']);?><br>
						            <?php echo $data['time'];?></p>
                      </center></td>
                      <td class="text-center" width="12%">			
                        <a class="btn btn-xs btn-secondary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Edit" href="m_edit_news.php?id=<?php echo $data['id_news']; ?>"><i class="fa fa-pencil"></i><img src="assets/img/edit.png"></a>
                        &nbsp;
                        <a class="btn btn-xs btn-primary ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Delete" href="include/delete.php?id=<?php echo $data['id_news']; ?>&module=news"><i class="fa fa-times"></i><img src="assets/img/delete.png"></a>
                      </td>
                      <?php
                      $no++;
                      } 
                      ?>
                    </tr>
                  </tbody>
                </table>
              </div> <!-- /.table-responsive -->
              <!-- </div> -->
        	</form>

         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('/template/side.php');
include('/template/footer.php');
?>
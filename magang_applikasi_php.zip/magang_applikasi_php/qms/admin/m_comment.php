<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-comment"></i> Komentar </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
          <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'delete') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully remove comment. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'reset') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully reset password to default. 
              </div>';
            }
          ?>
          <div class="table-responsive">
            <table class="table table-striped " data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
              <thead>
                <tr>
                  <th></th>
                </tr>
              </thead>
              <tbody>  
                <?php 
                $query = mysql_query("select * from tb_comment where comment_id  ORDER BY comment_id DESC");
                $no = 1;
                while ($data = mysql_fetch_array($query)) {
                ?>
                <tr>
                  <td>
                    <?php
                    if ($data['ket']=='reset' and $data['status']=='N') {
                      echo "<div class='feed-item feed-item-file'>
                      <div class='feed-icon'>
                      <i class='fa fa-bell'></i>";
                    } else if ($data['ket']=='reset' and $data['status']=='Y') {
                      echo "<div class='feed-item feed-item-bookmark'>
                      <div class='feed-icon'>
                      <i class='fa fa-check'></i>";
                    } else {
                      echo "<div class='feed-item feed-item-idea'>
                      <div class='feed-icon'>
                      <i class='fa fa-question'></i>";
                    }
                    ?>
                    </div> <!-- /.feed-icon -->

                    <div class="feed-subject">
                      <?php
                      if ($data['ket']=='reset' and $data['status']=='N') {
                       echo "<p><a href='javascript:;''>$data[username]</a> Confirm to : <a href='javascript:;'>Please reset my password to default</a></p>";
                      } else if ($data['ket']=='reset' and $data['status']=='Y') {
                       echo "<p>Successful to Reset <a href='javascript:;'>$data[username]'s</a> Password</p>";
                      } else {
                        echo "<p><a href='javascript:;'>$data[username]</a> posted the question: <a href='javascript:;'>$data[title]</a></p>";
                      }
                      ?>
                    </div> <!-- /.feed-subject -->

                    <div class="feed-content">
                      <ul class="icons-list">
                        <li>
                          <i class="icon-li fa fa-quote-left"></i>
                          <?php echo $data['comment']; ?>
                        </li>
                      </ul>
                    </div> <!-- /.feed-content -->

                    <div class="feed-actions">
                      <a href="javascript:;" class="pull-left"><i class="fa fa-envelope-o"></i> <?php echo $data['email'];?></a>
                      <?php 
                      if ($data['ket']=='reset' and $data['status']=='N') {
                        echo "<a href='include/reset.php?id=$data[comment_id]&nopeg=$data[no_peg]&module=comment' class='pull-left ui-tooltip' data-placement='top' data-toggle='tooltip' data-original-title='Reset Password'><i class='fa fa-refresh'></i></a>";
                      }
                      ?>
                      <a href="include/delete.php?id=<?php echo $data['comment_id']; ?>&module=comment" class="pull-left ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Remove Comment"><i class="fa fa-trash-o"></i></a>
                      <a href="javascript:;" class="pull-right"><i class="fa fa-clock-o"></i> 2 days ago</a>
                    </div> <!-- /.feed-actions -->
                </div> <!-- /.feed-item -->

                  </td>

                  <?php
                  $no++;
                  } 
                  ?>
                </tr>
              </tbody>
            </table>
          </div> <!-- /.table-responsive -->   

         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('/template/side.php');
include('/template/footer.php');
?>
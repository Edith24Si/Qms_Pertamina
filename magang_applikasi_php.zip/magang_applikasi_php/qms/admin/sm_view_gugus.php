<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
         	<P><h3> <i class='fa fa-users'></i>Masuk Gugus</h3></P>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
   		<?php
         $id_gugus=$_GET['id'];

         if ($_GET['module']=='daftar'){ 
            $query = mysql_query("select * from tb_gugus where id_gugus='$id_gugus'");
            $no = 0;
            while ($data = mysql_fetch_array($query)) {
               $no_peg=$data['creator'];
   		?>

         <table>
            <tr>
              <td>Nama Gugus&nbsp;&nbsp; </td>
              <td>: <?php echo $data['nama_gugus']; ?></td>
            </tr>
            <tr>
              <td>Kategori&nbsp;&nbsp; </td>
              <td>: <?php echo"$data[category_gugus]"; ?></td>
            </tr>
            <tr>
              <td>Judul&nbsp;&nbsp; </td>
              <td class="posting">: <?php echo"$data[title]"; ?></td>
            </tr>
            <tr>
              <td>No Telp.&nbsp;&nbsp; </td>
              <td>: <?php echo"$data[telp]"; ?></td>
            </tr>
          </table>
          <br />

         <?php
         } 
         ?>

         <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="6" data-paginate="true" data-info="true">
            <thead>
               <tr>
                <th width="5%"><div align="center">NO</div></th>
                <th width="36%"><div align="center">Nama Lengkap </div></th>
                <th width="18%"><div align="center">No. Pekerja</div></th>
                <th width="26%"><div align="center">Bagian </div></th>
                <th width="15%"><div align="center">Status</div></th>
              </tr>
            </thead>
            <tbody>
               <?php
                  $sql=mysql_query("select * from tb_member where id_gugus='$id_gugus' order by id_member asc");
                  while($data=mysql_fetch_array($sql))
               {
                  $no++;
               ?>
              <tr>
                  <td><div align="center"><?php echo"$no";?></div></td> 
                <td><?php echo"$data[fullname]";?></td>
                <td><?php echo"$data[no_peg]";?></td>
                <td><?php echo"$data[bagian]";?></td>
                <td><div align="center"><?php echo"$data[status]";?></div></td>
              </tr>
            <?php 
            } 
            ?>
            </tbody>
         </table>

         <br><br><br><br>
         <span >KLIK TOMBOL DOWNLOAD UNTUK MENDOWNLOAD FILE</span>
         <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="10" data-paginate="true" data-info="true">
            <thead>
               <tr>
                  <th><center>No</center></th>
                  <th><center>Title</center></th>
                  <th><center>Type</center></th>
                  <th><center>Detail</center></th>
                  <th><center>Opsi</center></th>
               </tr>
            </thead>
            <tbody>
               <?php
               $query = mysql_query("select * from tb_uploadcip where id_gugus='$id_gugus'");
               $no = 1;
               while ($data = mysql_fetch_array($query)) {
                  $size=$data['size']/1000;
               ?>
               <tr>
                  <td width="4%"><?php echo $no; ?></td>
                  <td><?php echo $data['filename']; ?></td>
                  <td width="10%"><center> 
                  <?php
                  if ($data['type'] == 'application/msword') {
                     print("<img src=admin/assets/img/doc.png>");
                     } else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                        print("<img src=admin/assets/img/docx.png>");
                     } else if ($data['type'] == 'application/octet-stream') {
                        print("<img src=admin/assets/img/docx.png>");
                     } else if ($data['type'] == 'application/pdf') {
                        print("<img src=admin/assets/img/pdf.png>");
                     };
                  ?>
                  </center></td>
                  <td class="file-info" width="24%">
                     <span><strong>Size:</strong> <?php echo"$size";?> Kb</span> <br />
                     <span><strong>Format:</strong> 
                     <?php
                     if ($data['type'] == 'application/msword') {
                        print(".doc");
                     } else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                        print(".docx");
                     } else if ($data['type'] == 'application/octet-stream') {
                        print(".docx");
                     } else if ($data['type'] == 'application/pdf') {
                        print(".pdf");
                     };
                     ?>
                     </span> <br />
                     <span><strong>Uploader:</strong> <?php echo"$data[namapengupload]";?></span>
                  </td>
                  <td width="8%">
                     <center><a class="btn btn-xs btn-success ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Download" href="include/download.php?id=<?php echo $data['id_cip']; ?>&module=cip"><i class="fa fa-download"></i></a></center>
                  </td>
                  <?php
                  $no++;
                  }
                  }
                  ?>
               </tr>
            </tbody>
         </table>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('template/side.php');
include('template/footer.php');
?>
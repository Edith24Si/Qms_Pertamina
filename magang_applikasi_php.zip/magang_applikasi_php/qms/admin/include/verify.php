<?php
include('config.php');
$id = $_GET['id'];

if ($_GET['module']=='acc'){
	$query = mysql_query("UPDATE tb_gugus SET acc='Y' WHERE id_gugus='$id'");
	header('location:../m_acc_gugus.php');
} else if ($_GET['module']=='delete'){
	$query = mysql_query("DELETE FROM tb_gugus WHERE id_gugus='$id'");
	$query = mysql_query("set @count:=0");
	$query = mysql_query("UPDATE tb_gugus SET id_gugus=@count:=@count+1 ORDER BY id_gugus;");
	header('location:../m_acc_gugus.php');
}
?>
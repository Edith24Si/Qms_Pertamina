<?php
include('config.php');

$id = $_GET['id'];

$query = mysql_query("SELECT * FROM tb_upload WHERE upload_id='$id'");

list($file_dir, $type, $size, $file_name) = mysql_fetch_array($query);
header("Content-Disposition: attachment; filename=$file_name");

$fp  = fopen("../admin/document/".$file_name, 'r');
$content = fread($fp, filesize("../admin/document/".$file_name));
fclose($fp);
echo $content;
?>

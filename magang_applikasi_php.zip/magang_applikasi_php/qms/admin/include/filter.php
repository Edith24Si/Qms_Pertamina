<?php
include('config.php');
include('cek-login.php');

$id = intval($_GET['id']);

$query = mysql_query("select * from tb_upload where menu_id=$id");
$no = 1;

echo "<div class='col-md-12'>
<div class='table-responsive'>
<table class='table table-striped table-bordered table-hover' data-provide='datatable' data-display-rows='6' data-paginate='true' data-info='true'>
<thead>
	<tr>
		<th>No</th>
		<th>Nama File</th>
        <th>Pengupload</th>
        <th>Ukuran</th>
        <th>Tipe</th>
        <th>Aksi</th>
    </tr>
</thead>
<tbody>";
while ($data = mysql_fetch_array($query)) {

echo "<tr>";
echo "<td>" . $no . "</td>";
echo "<td>" . $data['file_name'] . "</td>";
echo "<td>" . $data['creator'] . "</td>";
echo "<td>" . $data['size'] . "</td>";
echo "<td width=10%>";

if ($data['type'] == 'application/msword') {
	print("<img src=assets/img/doc.png>");
} else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
	print("<img src=assets/img/docx.png>");
} else if ($data['type'] == 'application/octet-stream') {
	print("<img src=assets/img/docx.png>");
} else if ($data['type'] == 'application/pdf') {
	print("<img src=assets/img/pdf.png>");
}

echo "</td>";
echo "<td class='text-center' width=14%>
	<a class='btn btn-xs btn-primary ui-tooltip' data-placement='top' data-toggle='tooltip' data-original-title='Delete' name='delete_data' href='include/delete.php?id=$data[upload_id]&module=file'><i class='fa fa-times'></i><img src='assets/img/delete.png'></a>
</td>";
$no++;
}
echo "</tr>
</tbody>
</table>
</div>
</div>";
?>
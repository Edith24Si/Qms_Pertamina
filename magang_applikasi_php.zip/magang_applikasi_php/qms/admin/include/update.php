<?php 
include('config.php');
session_start();

$id = $_GET['id'];
$uname = $_POST['username'];
$password = $_POST['password'];

if (empty($password)) {
	$query = mysql_query("UPDATE tb_user SET username='$uname' where id='$id'");

	if ($query) {
		header('location:../m_profile.php?message=success');
	}
}

if (!empty($password)) {
	$query = mysql_query("UPDATE tb_user SET username='$uname', password=MD5('$password') where id='$id'");

	if ($query) {
		header('location:../m_profile.php?message=success');
	}
}
?>
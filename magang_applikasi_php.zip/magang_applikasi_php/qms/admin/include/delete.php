<?php 
include('config.php');

if($_GET['module']=='admin') {
	$id = $_GET['id'];

	$query = mysql_query("delete from tb_user where id='$id'");
	$query = mysql_query("set @count:=0");
	$query = mysql_query("UPDATE tb_user SET id=@count:=@count+1 ORDER BY id");

	if ($query) {
		header('location:../m_add_user.php?message=delete');
	}
}

if($_GET['module']=='employee') {
	$id = $_GET['id'];

	$query = mysql_query("delete from tb_employee where no_peg='$id'");

	if ($query) {
		header('location:../m_add_employee.php?message=delete');
	}
}

if($_GET['module']=='news') {
	$id = $_GET['id'];  

	$query = mysql_query("delete from tb_news where id_news='$id'");
	$query = mysql_query("set @count:=0");
	$query = mysql_query("UPDATE tb_news SET id_news=@count:=@count+1 ORDER BY id_news");

	if ($query) {
		header('location:../m_news.php?message=delete');
	}
}

if($_GET['module']=='file') {
	$id = $_GET['id'];  

	$query = mysql_query("delete from tb_upload where upload_id='$id'");
	$query = mysql_query("set @count:=0");
	$query = mysql_query("UPDATE tb_upload SET upload_id=@count:=@count+1 ORDER BY upload_id");

	if ($query) {
		header('location:../m_list.php?message=delete');
	}
}

if($_GET['module']=='comment') {
	$id = $_GET['id'];  

	$query = mysql_query("delete from tb_comment where comment_id='$id'");
	$query = mysql_query("set @count:=0");
	$query = mysql_query("UPDATE tb_comment SET comment_id=@count:=@count+1 ORDER BY comment_id");

	if ($query) {
		header('location:../m_comment.php?message=delete');
	}
}
?>
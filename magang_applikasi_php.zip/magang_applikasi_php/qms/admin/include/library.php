<?php
$week = array("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu");
$day = date("w");
$day_now = $week[$day];

$date_now = date("Ymd");
$day     = date("d");
$mounth_now = date("m");
$year_now = date("Y");
$time_now = date("H:i:s");

$mounth_name=array(1=> "Januari", "Februari", "Maret", "April", "Mei", 
                    "Juni", "Juli", "Agustus", "September", 
                    "Oktober", "November", "Desember");
?>

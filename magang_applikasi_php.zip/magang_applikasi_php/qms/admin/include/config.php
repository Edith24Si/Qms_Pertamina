<?php
$host = 'localhost'; 
$user = 'root'; 
$pass = '';
$dbname = 'db_qms';

$connect = mysql_connect($host, $user, $pass) or die(mysql_error());
$dbselect = mysql_select_db($dbname);


function encrypss($str) { $key = '979a21436drt6ge6bnhy6234v98d47956c7';
    for ($i = 0; $i < strlen($str); $i++) {
        $cractr = substr($str, $i, 1);
        $keycractr = substr($key, ($i % strlen($key))-1, 1);
        $cractr = chr(ord($cractr)+ord($keycractr));
        $done .= $cractr; 
	} return urlencode(base64_encode($done)); 
}

?>
<?php 
include('config.php');

if($_GET['module']=='comment') {
	$id = $_GET['id'];  
	$nopeg = $_GET['nopeg'];  

	$query = mysql_query("UPDATE tb_employee SET password=reset_pswd where no_peg='$nopeg'") or die(mysql_error());

	if ($query) {
		$q = mysql_query("UPDATE tb_comment SET status='Y' where comment_id='$id'");
		if ($q) {
			header('location:../m_comment.php?message=reset');
		}
		header('location:../m_comment.php?message=reset');
	}
}

if($_GET['module']=='employee') {
	$id = $_GET['id'];
	$query = mysql_query("UPDATE tb_employee SET password=reset_pswd where no_peg='$id'") or die(mysql_error());

	if ($query) {
		header('location:../m_add_employee.php?message=reset');
	}
}
?>
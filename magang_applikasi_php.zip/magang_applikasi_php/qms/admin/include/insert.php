<?php
include('config.php');
include('library.php');
include('cek-login.php');

if(isset($_POST['add-admin'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysql_query("insert into tb_user values('', '$username', md5('$password'))") or die(mysql_error());

    if ($query) {
        header('location:../m_add_user.php?message=success');
    } else {
        header('location:../m_add_user.php?message=fail');
    }
} else if(isset($_POST['add-employee'])){
    $nopeg = $_POST['nopeg'];
    $emp_name = $_POST['emp_name'];
    $password = $_POST['password'];
    $mail = $_POST['mail'];

    $data = mysql_query("select * from tb_employee where no_peg='$nopeg'");
    if (mysql_num_rows($data) == 0) {
        $query = mysql_query("insert into tb_employee values('$nopeg', '$emp_name', md5('$password'), md5('$password'), '$mail')") or die(mysql_error());
        if ($query) {
            header('location:../m_employee.php?message=success');
        } else {
            header('location:../m_employee.php?message=fail');
        }
    } else {
        header('location:../m_employee.php?message=error');
    }
} else if(isset($_POST['publish-news'])){
	$title = $_POST['title'];
	$category = $_POST['category'];
	$content = $_POST['content'];
    $username = $_SESSION['admin'];

	$name = $_FILES['myfile']['name'];
    $type = $_FILES['myfile']['type'];
    $size = $_FILES['myfile']['size'];
    $tmp  = $_FILES['myfile']['tmp_name'];
    $dir = "../assets/img/news_dir/";
	
	$pattern="/[^a-zA-Z0-9\.]/";
	$replace="_";
	$file = preg_replace($pattern,$replace,$name);

	if (!empty($tmp)) {
        if($type=="image/jpeg" || $type=="image/jpg" || $type=="image/gif" || $type=="image/x-png" || $type=="image/png") {
            $pictures = $dir . $file;
        	if (move_uploaded_file($tmp, $pictures)) {
        		$query = mysql_query("insert into tb_news values('', '$category', '$username', '$title', '$content', '$day_now', '$date_now', '$time_now', '$pictures', '$file', '')");
        		if ($query) {
        			header('location:../m_news.php?message=success');
        		} else {
        			header('location:../m_news.php?message=fail');
        		}
        	}
        } else {
        	header('location:../m_news.php?message=fail-format');
        }
	} else {
		header('location:../m_news.php?message=fail-null');
	}
} else if(isset($_POST['upload-data'])){
    $dir_id = $_POST['dir_id'];
    $username = $_SESSION['admin'];

    $name = $_FILES['myfile']['name'];
    $type = $_FILES['myfile']['type'];
    $size = $_FILES['myfile']['size'];
    $tmp  = $_FILES['myfile']['tmp_name'];
    $dir = "../document/";
	
	$pattern="/[^a-zA-Z0-9\.]/";
	$replace="_";
	$file = preg_replace($pattern,$replace,$name);

    if (!empty($tmp)) {
        if($type=="application/msword" || $type=="application/vnd.ms-excel" || $type=="application/pdf" || $type=="application/vnd.openxmlformats-officedocument.wordprocessingml.document" || $type== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || $type=="application/octet-stream") {
            $files = $dir . $file;
            if (move_uploaded_file($tmp, $files)) {
                $query = mysql_query("insert into tb_upload values('', '$dir_id', '$username', '$file', '$files', '$size', '$type')");
                if ($query) {
                    header('location:../m_upload.php?message=success');
                } else {
                    header('location:../m_upload.php?message=fail');
                }
            }
        } else {
            header('location:../m_upload.php?message=fail-format');
        }
    } else {
        header('location:../m_upload.php?message=fail-null');
    }
} else {
    header('location:../index.php');
}
?>
<?php 
include('template/header.php');
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-users"></i> Employee List </h3>
            <ul class="portlet-tools pull-right">
              <li>
                <a href="m_employee.php" class="btn btn-sm btn-default">Add Employee</a>
              </li>
            </ul>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content" id="content-center">
            <?php 
            if (!empty($_GET['message']) && $_GET['message'] == 'success') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully adding data. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'delete') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully delete data. 
              </div>';
            } else if (!empty($_GET['message']) && $_GET['message'] == 'reset') {
              echo '<div class="alert alert-success"> 
              <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
              <strong>Well done!</strong> You successfully Reset Password. 
              </div>';
            }
            ?>

              <div class="col-md-12">
              <div class="table-responsive">

              <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="25" data-paginate="true" data-info="true" data-search="true" data-length-change="true">
                  <thead>
                    <tr>
                      <th>No. Pegawai</th>
                      <th>Nama Pegawai</th>
                      <th>Email</th>
                      <th>Telpon</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $query = mysql_query("select * from tb_employee_baru");
                    while ($data = mysql_fetch_array($query)) {
                    ?>
                    <tr>
                      <td><?php echo $data['nopek']; ?></td>
                      <td><?php echo $data['emp_name']; ?></td>
                      <td><?php echo $data['email']; ?></td>
                      <td><?php echo $data['telpon']; ?></td>
<!--                      <td class="text-center" width='16%'>
                        <a class="btn btn-xs btn-success ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Reset Password" href="include/reset.php?id=<?php echo $data['no_peg']; ?>&module=employee"><i class="fa fa-refresh"></i><img src="assets/img/reset.png"></a>
                        &nbsp;
                        <a class="btn btn-xs btn-primary ui-tooltip" data-placement="top" data-toggle="tooltip"data-original-title="Delete"  href="include/delete.php?id=<?php echo $data['no_peg']; ?>&module=employee"><i class="fa fa-times"></i><img src="assets/img/delete.png"></a>
                      </td>-->
                      <?php
                      } 
                      ?>
                    </tr>
                  </tbody>
                </table>    

              </div> <!-- /.table-responsive -->
              <br><br><div id="hr"></div>
              </div>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
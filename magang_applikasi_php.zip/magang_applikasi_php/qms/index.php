<?php 
session_start();

//if (!empty($_SESSION['username'])) {
  include('template/header.php');
//} else {
//  include('template/header_guest.php');
//}
include('template/navbar.php');
?>



<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
         	<h3><i class='fa fa-bar-chart-o'></i> KEBIJAKAN SISTEM MANAJEMEN REFINERY UNIT DUMAI</h3>
            <!-- <h3><i class="fa fa-bar-chart-o"></i> Dashboard - </h3> -->
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">

<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="admin/assets/img/KebijakanRUDumai_2026_1.JPEG">
      <div class="carousel-caption">
        Kebijakan Sistem Manajemen Anti Penyuapan (SMAP) 2026
      </div>
    </div>
    <div class="item">
      <img src="admin/assets/img/KebijakanRUDumai_2026_2.JPEG">
      <div class="carousel-caption">
        Kebijakan HSSE 2026 Refinery Unit Dumai
      </div>
    </div>
    <div class="item">
      <img src="admin/assets/img/KebijakanRUDumai_2026_3.JPEG">
      <div class="carousel-caption">
        Kebijakan HSSE 2026 Refinery Unit Dumai
      </div>
    </div>
    <div class="item">
      <img src="admin/assets/img/KebijakanRUDumai_2026_4.JPEG">
      <div class="carousel-caption">
        Kebijakan MUTU 2026 Refinery Unit Dumai
      </div>
    </div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

            <!-- <img src="admin/assets/img/KebijakanSMT2023.jpg" width="100%">	 -->		
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('/template/side.php');
include('/template/footer.php');
?>
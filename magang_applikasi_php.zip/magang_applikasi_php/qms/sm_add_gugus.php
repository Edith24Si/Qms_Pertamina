<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   header('location:error-404.php');
}
include('template/navbar.php');
?>

<body>
<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
          <h3><i class='fa fa-bar-chart-o'></i> Add Gugus </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
          <div class="alert alert-info"> 
            <b>1. </b>Pendaftaran Nama Gugus 
          </div>
          <form class="form-horizontal" role="form" action="include/insert.php" method="post"><br>
            <div class="form-group">
              <label class="col-md-3">Category</label>

              <div class="col-md-8">
                <select id="s2_basic" name="category" class="form-control">
                  <option selected></option>
                  <option value="PKM">PKM</option>
                  <option value="GKM">GKM</option>
                  <option value="SS">SS</option>
                </select>
              </div>
            </div><!-- Form Group -->

            <div class="form-group">
              <label class="col-md-3">Nama Gugus</label>

              <div class="col-md-8">
                <input type="text" name="name" class="form-control" required="required" placeholder="Gugus Name">
              </div>
            </div> <!-- Form Group -->

            <div class="form-group">
              <label class="col-md-3">Judul</label>

              <div class="col-md-8">
                <input type="text" name="title" class="form-control" required="required" placeholder="Title">
              </div>
            </div> <!-- Form Group -->

            <div class="form-group">
              <label class="col-md-3">No Telphone Ketua</label>

              <div class="col-md-8">
                <input type="text" name="telp" class="form-control" required="required" placeholder="Telphone">
              </div>
            </div> <!-- Form Group -->
            <br><div id="hr"></div>
            <div class="col-md-9"></div>
            <button type="submit" name="gugus-add" class="btn btn-primary col-md-2"></span>Add&nbsp;&nbsp; <span class="fa fa-plus-square"></button>
          </form>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('template/side.php');
include('template/footer.php');
?>
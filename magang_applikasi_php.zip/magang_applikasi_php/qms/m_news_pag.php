<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-8">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class='fa fa-tasks'></i> News </h3>
            <!-- <h3><i class="fa fa-bar-chart-o"></i> Dashboard - </h3> -->
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
            <?php
            include('include/html-dom.php');
			include('include/fatalerror.php');
			
            $link = $_GET['link'];
            $articles = getArticles('http://10.52.0.5'.$link);
            echo $articles;

            function getArticles($page) {
                global $articles;
             
                $html = new simple_html_dom();
                $html->load_file($page);
                // Load File Page

                foreach($html->find('h2 a') as $link)
                        $link->href = 'http://10.52.0.17/qms/m_news_link.php?link='.$link->href;
                        
                foreach($html->find('p[class=readmore] a') as $link)
                        $link->href = 'http://10.52.0.17/qms/m_news_link.php?link='.$link->href;

                foreach($html->find('ul[class=pagination-list] li a') as $link)
                        $link->href = 'http://10.52.0.17/qms/m_news_pag.php?link='.$link->href;
                        
                foreach($html->find('a[rel=nofollow]') as $link)
                        $link->href = 'http://10.52.0.5'.$link->href;
                        
                foreach($html->find('a[title=Email]') as $link)
                        $link->href = 'http://10.52.0.5'.$link->href;

                $html->find('ul[class=pagination-list]', 0)->class = 'pagination';

                $html->find('a i[class=icon-first]', 0)->outertext = '<i class="fa fa-angle-double-left"></i>';
                $html->find('a i[class=icon-previous]', 0)->outertext = '<i class="fa fa-angle-left"></i>';
                $html->find('a i[class=icon-next]', 0)->outertext = '<i class="fa fa-angle-right"></i>';
                $html->find('a i[class=icon-last]', 0)->outertext = '<i class="fa fa-angle-double-right"></i>';
				
				$html->find('div[id=aside]', 0)->outertext = '';
                
                $result = $html->save();

                $items = $html->find('div[class=blog]'); 
             
                foreach($items as $post) {
                    # remember comments count as nodes
                    $articles[] = array(

                        $post->children(0)->outertext,
                        $post->children(2)->outertext,
                        $post->children(4)->outertext,
                        $post->children(6)->outertext,
                        $post->children(8)->outertext,
                        $post->children(10)->outertext,
                        $post->children(12)->outertext,
                        $post->children(14)->outertext,);
                }

                foreach($articles as $item) {
                    echo "<div class='parser'>";
                    echo $item[0];
                    echo $item[1];
                    echo $item[2];
                    echo $item[3];
                    echo $item[4];
                    echo $item[5];
                    echo $item[6];
                    echo "<center>";
                    echo $item[7];
                    echo "</center>";
                    echo "</div>";
                }
            }
            ?>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
include('template/side.php');
include('template/footer.php');
?>
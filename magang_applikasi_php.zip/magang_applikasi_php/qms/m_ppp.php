<?php 
session_start();

if (!empty($_SESSION['username'])) {
   include('template/header.php');
} else {
   include('template/header_guest.php');
}
include('template/navbar.php');
?>

<body>

<div class="row">
   <div class="col-md-12">
      <div class="portlet">
         <div class="portlet-header">
            <h3><i class="fa fa-users"></i> PPP </h3>
         </div> <!-- /.portlet-header -->

         <div class="portlet-content">
          <div class="col-md-12">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover" data-provide="datatable" data-display-rows="10" data-paginate="true" data-info="true">
                <thead>
                  <tr>
                    <th><center>No</center></th>
                    <th><center>Title</center></th>
                    <th><center>Type</center></th>
                    <th><center>Detail</center></th>
                    <th><center>Opsi</center></th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                      $query = mysql_query("select * from tb_upload where menu_id=64");
                      $no = 1;
                      while ($data = mysql_fetch_array($query)) {
                          $size=$data['size']/1000;
                    ?>
                  <tr>
                    <td width="4%"><?php echo $no; ?></td>
                    <td><?php echo $data['file_name']; ?></td>
                    <td width="10%"><center> 
                      <?php
                        if ($data['type'] == 'application/msword') {
                          print("<img src=admin/assets/img/doc.png>");
                        } else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                          print("<img src=admin/assets/img/docx.png>");
                        } else if ($data['type'] == 'application/octet-stream') {
                          print("<img src=admin/assets/img/docx.png>");
                        } else if ($data['type'] == 'application/pdf') {
                          print("<img src=admin/assets/img/pdf.png>");
                        };
                      ?>
                    </center></td>
                    <td class="file-info" width="24%">
                      <span><strong>Size:</strong> <?php echo"$size";?> Kb</span> <br />
                      <span><strong>Format:</strong> 
                        <?php
                        if ($data['type'] == 'application/msword') {
                          print(".doc");
                        } else if ($data['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                          print(".docx");
                        } else if ($data['type'] == 'application/octet-stream') {
                          print(".docx");
                        } else if ($data['type'] == 'application/pdf') {
                          print(".pdf");
                        };
                        ?>
                      </span> <br />
                      <span><strong>Uploader:</strong> <?php echo"$data[creator]";?></span>
                    </td>
                    <td width="8%">
                      <center><a class="btn btn-xs btn-success ui-tooltip" data-placement="top" data-toggle="tooltip" data-original-title="Download" href="include/download.php?id=<?php echo $data['upload_id']; ?>"><i class="fa fa-download"></i><img src="admin/assets/img/dwload.png"></a></center>
                    </td>
                    <?php
                    $no++;
                    }
                    ?>
                  </tr>
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
         </div> <!-- /.portlet-content -->
      </div> <!-- /.portlet -->
   </div> <!-- /.col -->

<?php 
//include('/template/side.php');
include('/template/footer.php');
?>